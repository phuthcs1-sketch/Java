# Kịch bản Trình bày Dự án: CoffeeShop Management System

---

## Thông tin chung

| | |
|---|---|
| **Tên dự án** | CoffeeShop Management System |
| **Công nghệ** | Java 17 · JavaFX 21 · SQL Server 2022 · Maven |
| **Kiến trúc** | MVC (Model – View – Controller) |
| **Thời gian trình bày** | ~15–20 phút |

---

## Phần 1 — Giới thiệu dự án *(~2 phút)*

> *"Chúng em xin trình bày dự án CoffeeShop Management System — một phần mềm quản lý quán cà phê được xây dựng bằng Java và JavaFX."*

**Vấn đề thực tế:**
Các quán cà phê vừa và nhỏ thường quản lý bằng sổ tay hoặc phần mềm rời rạc, dẫn đến:
- Tốn thời gian xử lý đơn hàng thủ công
- Khó kiểm soát doanh thu, tồn kho
- Không phân quyền được nhân viên rõ ràng

**Giải pháp:**
Một ứng dụng desktop tập trung, hỗ trợ toàn bộ quy trình vận hành của quán — từ bán hàng đến báo cáo cuối ngày.

---

## Phần 2 — Kiến trúc & Công nghệ *(~3 phút)*

### Stack công nghệ

| Thành phần | Công nghệ | Vai trò |
|---|---|---|
| Ngôn ngữ | Java 17 | Logic nghiệp vụ |
| Giao diện | JavaFX 21 + FXML | UI desktop đa nền tảng |
| Cơ sở dữ liệu | SQL Server 2022 | Lưu trữ dữ liệu |
| Build tool | Apache Maven | Quản lý dependencies |
| CSS | JavaFX CSS | Tùy chỉnh giao diện |

### Kiến trúc MVC

```
┌─────────────────────────────────────────────┐
│              VIEW (FXML + CSS)              │
│   login · dashboard · pos · tables · ...   │
└────────────────────┬────────────────────────┘
                     │
┌────────────────────▼────────────────────────┐
│           CONTROLLER (Java)                 │
│  LoginController · POSController · ...     │
└────────────────────┬────────────────────────┘
                     │
┌────────────────────▼────────────────────────┐
│              DAO (Data Access)              │
│  ProductDAO · OrderDAO · CustomerDAO · ... │
└────────────────────┬────────────────────────┘
                     │
┌────────────────────▼────────────────────────┐
│           SQL Server Database               │
└─────────────────────────────────────────────┘
```

> *"Chúng em tách biệt rõ ràng 3 tầng: View chỉ hiển thị, Controller xử lý logic, DAO chịu trách nhiệm truy vấn database. Điều này giúp code dễ bảo trì và mở rộng."*

---

## Phần 3 — Phân quyền người dùng *(~1 phút)*

Hệ thống có **3 vai trò**, mỗi vai trò chỉ thấy các chức năng phù hợp:

| Vai trò | Quyền truy cập |
|---|---|
| **Admin** | Toàn bộ hệ thống, bao gồm Cài đặt |
| **Manager** | Quản lý hàng hóa, nhân sự, hóa đơn, báo cáo |
| **Employee** | Chỉ: Bán hàng (POS), Bàn ăn, Chấm công |

> *"Phân quyền được áp dụng ngay tại màn hình Dashboard — menu sidebar tự động ẩn/hiện theo role của người đăng nhập."*

---

## Phần 4 — Demo chức năng *(~10 phút)*

### 4.1 Đăng nhập

- Mở ứng dụng → Màn hình đăng nhập xuất hiện
- Đăng nhập tài khoản **admin / admin123**
- Hệ thống xác thực, chuyển sang Dashboard

> *"Có thể demo thêm: đăng nhập sai mật khẩu để thấy xử lý lỗi."*

---

### 4.2 Dashboard — Tổng quan

- Hiển thị **4 thẻ thống kê** nhanh: Tổng doanh thu · Tổng đơn hàng · Khách hàng · Nhân viên
- Sidebar menu đầy đủ (Admin)
- Trạng thái kết nối database hiển thị real-time

---

### 4.3 Bán hàng — POS *(chức năng cốt lõi)*

1. Chọn **Bàn** từ danh sách
2. Duyệt sản phẩm theo **danh mục** (bộ lọc nhanh)
3. Tìm kiếm sản phẩm bằng ô search
4. Click sản phẩm → thêm vào giỏ hàng
5. Điều chỉnh **% giảm giá** nếu cần
6. Nhập tiền khách trả → hệ thống tự tính **tiền thối**
7. Nhấn **Thanh toán** → tạo hóa đơn, cập nhật database

> *"Đây là màn hình nhân viên sẽ dùng nhiều nhất mỗi ngày."*

---

### 4.4 Quản lý Bàn

- Hiển thị danh sách bàn với trạng thái: **Trống / Có khách**
- Thêm / Sửa / Xóa bàn
- Bàn đang có đơn hàng sẽ hiển thị khác màu

---

### 4.5 Quản lý Sản phẩm & Danh mục

- CRUD đầy đủ: thêm, sửa, xóa, tìm kiếm
- Phân loại theo danh mục (Cà phê, Trà, Bánh, ...)
- Đặt giá, trạng thái còn bán / ngừng bán

---

### 4.6 Quản lý Nhân viên & Khách hàng

- Nhân viên: họ tên, chức vụ, ca làm, thông tin liên hệ
- Khách hàng: thông tin, lịch sử mua hàng
- Tìm kiếm, lọc, CRUD

---

### 4.7 Chấm công

- Nhân viên check-in / check-out theo ca
- Xem lịch sử chấm công theo ngày / tháng
- Manager có thể xem toàn bộ nhân viên

---

### 4.8 Hóa đơn

- Danh sách hóa đơn đã xuất
- Xem chi tiết từng hóa đơn: sản phẩm, số lượng, tổng tiền
- Lọc theo ngày / khoảng thời gian

---

### 4.9 Báo cáo Doanh thu

- Doanh thu **hôm nay / tháng này / năm nay**
- Bảng **7 ngày gần nhất**
- **Top sản phẩm** bán chạy
- Doanh thu theo **ca làm việc**
- Lọc theo tháng / năm tùy chọn

---

### 4.10 Thống kê

- Biểu đồ / bảng thống kê bán hàng tổng hợp
- Hỗ trợ ra quyết định kinh doanh

---

### 4.11 Cài đặt Hệ thống *(Admin only)*

- Tên quán, địa chỉ, số điện thoại, email
- % giảm giá mặc định
- Thời gian lưu hóa đơn
- Phiên bản & trạng thái hệ thống

---

## Phần 5 — Điểm nổi bật *(~2 phút)*

1. **Phân quyền thực tế** — Menu động, ẩn/hiện theo role ngay khi đăng nhập
2. **Kiến trúc tách lớp rõ ràng** — MVC + DAO pattern, dễ mở rộng thêm chức năng
3. **Giao diện trực quan** — JavaFX với CSS tùy chỉnh, responsive trong cửa sổ
4. **Dữ liệu real-time** — Dashboard và báo cáo kết nối trực tiếp từ SQL Server
5. **Xử lý lỗi đầy đủ** — Logger ghi log chi tiết, UI thông báo lỗi thân thiện

---

## Phần 6 — Hướng phát triển *(nếu được hỏi)*

- Xuất hóa đơn ra PDF
- Gửi báo cáo qua email tự động
- Ứng dụng mobile cho nhân viên (Android/iOS)
- Tích hợp thanh toán QR / ví điện tử
- Triển khai lên cloud thay vì desktop local

---

## Gợi ý Q&A thường gặp

**Q: Tại sao chọn JavaFX thay vì web?**
> JavaFX phù hợp với ứng dụng desktop cần hiệu năng cao, chạy offline không cần internet, và phù hợp phạm vi môn học Java.

**Q: Database có thể dùng MySQL được không?**
> Có. Chỉ cần đổi JDBC driver và connection string trong `DBConnection.java`, phần còn lại không thay đổi nhờ kiến trúc DAO.

**Q: Làm thế nào đảm bảo bảo mật mật khẩu?**
> Hiện tại lưu trực tiếp — đây là điểm cần cải thiện. Hướng phát triển sẽ dùng bcrypt để mã hóa mật khẩu.

**Q: Phần mềm có thể chạy trên máy không có internet không?**
> Có. Ứng dụng chạy hoàn toàn local, chỉ cần SQL Server chạy trên cùng máy hoặc mạng nội bộ.

---

*CoffeeShop Management System — v1.0.0 | Java 17 | JavaFX 21 | SQL Server 2022*

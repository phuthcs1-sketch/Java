-- Phải ở master mới drop được database khác
USE master;
GO

-- Xóa DB cũ nếu đã tồn tại (để chạy lại script từ đầu)
IF EXISTS (SELECT name FROM sys.databases WHERE name = N'COFFEESHOP')
BEGIN
    ALTER DATABASE COFFEESHOP SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
    DROP DATABASE COFFEESHOP;
END
GO

CREATE DATABASE COFFEESHOP;
GO
USE COFFEESHOP;
GO

-- ============================================================
-- THIẾT KẾ: 2 bảng tách biệt cho 2 mục đích khác nhau
--
--   USERS     → xác thực đăng nhập (username/password/role)
--   NhanVien  → hồ sơ nhân sự     (lương, ca làm, chấm công)
--
-- Khi đăng ký tài khoản mới, hệ thống tự động tạo cả 2 records.
-- Admin có thể cập nhật thông tin nhân sự (lương, SĐT) ở
-- màn hình Quản lý Nhân viên sau khi đăng ký.
-- ============================================================

-- Bảng xác thực đăng nhập
CREATE TABLE USERS (
    UserId   INT IDENTITY(1,1) PRIMARY KEY,
    FullName NVARCHAR(200) NULL,
    Username NVARCHAR(100) NOT NULL,
    Email    NVARCHAR(200) NULL,
    Password NVARCHAR(256) NOT NULL,
    Role     NVARCHAR(50)  DEFAULT 'employee'
);

CREATE TABLE NhanVien (
    MaNV      INT IDENTITY PRIMARY KEY,
    TenNV     NVARCHAR(100),
    ChucVu    NVARCHAR(50),
    DienThoai VARCHAR(15),
    Luong     DECIMAL(12,2),
    TrangThai NVARCHAR(20)
);

CREATE TABLE KhachHang (
    MaKH      INT IDENTITY PRIMARY KEY,
    TenKH     NVARCHAR(100),
    DienThoai VARCHAR(15),
    Email     NVARCHAR(200) NULL,
    DiaChi    NVARCHAR(300) NULL,
    DiemTich  INT DEFAULT 0
);

CREATE TABLE DanhMuc (
    MaDM  INT IDENTITY PRIMARY KEY,
    TenDM NVARCHAR(100) NOT NULL UNIQUE
);

CREATE TABLE SanPham (
    MaSP  INT IDENTITY PRIMARY KEY,
    TenSP NVARCHAR(100),
    Gia   DECIMAL(12,2),
    Loai  NVARCHAR(50)
);

CREATE TABLE Ban (
    MaBan     INT IDENTITY PRIMARY KEY,
    TenBan    NVARCHAR(50),
    KhuVuc    NVARCHAR(50),
    TrangThai NVARCHAR(20),
    SoCho     INT DEFAULT 4,
    GhiChu    NVARCHAR(255) NULL
);

CREATE TABLE CaLam (
    MaCa      INT IDENTITY PRIMARY KEY,
    TenCa     NVARCHAR(50),
    GioBatDau TIME,
    GioKetThuc TIME,
    TienCa    DECIMAL(12,2)
);

CREATE TABLE HoaDon (
    MaHD     INT IDENTITY PRIMARY KEY,
    MaNV     INT,
    MaKH     INT NULL,
    MaBan    INT NULL,      -- NULL khi là đơn mang về
    MaCa     INT NULL,
    NgayLap  DATETIME DEFAULT GETDATE(),
    TongTien DECIMAL(12,2),
    FOREIGN KEY (MaNV)  REFERENCES NhanVien(MaNV),
    FOREIGN KEY (MaKH)  REFERENCES KhachHang(MaKH),
    FOREIGN KEY (MaBan) REFERENCES Ban(MaBan),
    FOREIGN KEY (MaCa)  REFERENCES CaLam(MaCa)
);

-- Gia = đơn giá, ThanhTien = thành tiền (SoLuong * Gia)
CREATE TABLE ChiTietHoaDon (
    MaHD      INT,
    MaSP      INT,
    SoLuong   INT,
    Gia       DECIMAL(12,2),
    ThanhTien DECIMAL(12,2),
    PRIMARY KEY (MaHD, MaSP),
    FOREIGN KEY (MaHD) REFERENCES HoaDon(MaHD),
    FOREIGN KEY (MaSP) REFERENCES SanPham(MaSP)
);

CREATE TABLE DoanhThu (
    MaDT         INT IDENTITY PRIMARY KEY,
    Ngay         DATE,
    MaCa         INT,
    MaNV         INT,
    TongHoaDon   INT,
    TongDoanhThu DECIMAL(14,2),
    FOREIGN KEY (MaCa) REFERENCES CaLam(MaCa),
    FOREIGN KEY (MaNV) REFERENCES NhanVien(MaNV)
);

CREATE TABLE ChamCong (
    MaCC    INT IDENTITY PRIMARY KEY,
    MaNV    INT,
    MaCa    INT,
    NgayLam DATE,
    GioVao  TIME,
    GioRa   TIME,
    FOREIGN KEY (MaNV) REFERENCES NhanVien(MaNV),
    FOREIGN KEY (MaCa) REFERENCES CaLam(MaCa)
);

-- ============================================================
-- DỮ LIỆU MẪU
-- ============================================================

-- ── USERS (tài khoản đăng nhập) ──────────────────────────────
INSERT INTO USERS (FullName, Username, Email, Password, Role) VALUES
(N'Quản Trị Viên',   N'admin',     N'admin@coffeeshop.vn',  N'admin123', N'admin'),
(N'Nguyễn Văn An',   N'nva',       N'nva@coffeeshop.vn',    N'123456',   N'manager'),
(N'Trần Thị Bình',   N'ttb',       N'ttb@coffeeshop.vn',    N'123456',   N'employee'),
(N'Lê Văn Cường',    N'lvc',       N'lvc@coffeeshop.vn',    N'123456',   N'employee'),
(N'Phạm Thị Dung',   N'ptd',       N'ptd@coffeeshop.vn',    N'123456',   N'employee'),
(N'Hoàng Văn Em',    N'hve',       N'hve@coffeeshop.vn',    N'123456',   N'employee');

-- ── NHÂN VIÊN ────────────────────────────────────────────────
-- MaNV: 1-6
INSERT INTO NhanVien (TenNV, ChucVu, DienThoai, Luong, TrangThai) VALUES
(N'Nguyễn Văn An',   N'Quản lý',   '0901111111', 15000000, N'Dang lam'),
(N'Trần Thị Bình',   N'Thu ngân',  '0902222222',  9000000, N'Dang lam'),
(N'Lê Văn Cường',    N'Phục vụ',   '0903333333',  7500000, N'Dang lam'),
(N'Phạm Thị Dung',   N'Barista',   '0904444444',  8500000, N'Dang lam'),
(N'Hoàng Văn Em',    N'Phục vụ',   '0905555555',  7000000, N'Dang lam'),
(N'Nguyễn Thị Fà',   N'Thu ngân',  '0906666666',  8000000, N'Nghi phep');

-- ── KHÁCH HÀNG ───────────────────────────────────────────────
-- MaKH: 1-8
INSERT INTO KhachHang (TenKH, DienThoai, Email, DiaChi, DiemTich) VALUES
(N'Phạm Minh Hiếu',    '0911111111', N'pmh@gmail.com',  N'123 Nguyễn Huệ, Q.1',          80),
(N'Ngô Thị Kim',       '0912222222', N'ntk@gmail.com',  N'456 Lê Lợi, Q.1',              55),
(N'Khách lẻ',           NULL,         NULL,               NULL,                              0),
(N'Lê Minh Tú',        '0913333333', N'lmt@gmail.com',  N'789 Hai Bà Trưng, Q.3',        120),
(N'Trần Thị Lan',      '0914444444', N'ttl@gmail.com',  N'321 Đinh Tiên Hoàng, Q.1',      40),
(N'Nguyễn Hữu Nam',    '0915555555', N'nhn@gmail.com',  N'654 CMT8, Q.10',                95),
(N'Bùi Thị Hoa',       '0916666666', N'bth@gmail.com',  N'111 Pasteur, Q.3',              30),
(N'Vũ Anh Khoa',       '0917777777', N'vak@gmail.com',  N'222 Nam Kỳ Khởi Nghĩa, Q.3',   15);

-- ── DANH MỤC ─────────────────────────────────────────────────
-- MaDM: 1-5
INSERT INTO DanhMuc (TenDM) VALUES
(N'Ca phe'),
(N'Tra'),
(N'Sinh to'),
(N'Nuoc ngot'),
(N'Do an nhe');

-- ── SẢN PHẨM ─────────────────────────────────────────────────
-- MaSP: 1-8  → Ca phe
-- MaSP: 9-13 → Tra
-- MaSP: 14-17→ Sinh to
-- MaSP: 18-21→ Nuoc ngot
-- MaSP: 22-25→ Do an nhe
INSERT INTO SanPham (TenSP, Gia, Loai) VALUES
(N'Cà phê Đen',          20000, N'Ca phe'),
(N'Cà phê Sữa',          25000, N'Ca phe'),
(N'Bạc Xỉu',             30000, N'Ca phe'),
(N'Cappuccino',           45000, N'Ca phe'),
(N'Latte',                50000, N'Ca phe'),
(N'Americano',            40000, N'Ca phe'),
(N'Cold Brew',            45000, N'Ca phe'),
(N'Cà phê Trứng',        38000, N'Ca phe'),
(N'Trà Đào',              30000, N'Tra'),
(N'Trà Lài Mật Ong',     28000, N'Tra'),
(N'Trà Sữa Trân Châu',   40000, N'Tra'),
(N'Trà Chanh',            25000, N'Tra'),
(N'Trà Ô Long',           35000, N'Tra'),
(N'Sinh Tố Bơ',           40000, N'Sinh to'),
(N'Sinh Tố Dâu',          35000, N'Sinh to'),
(N'Sinh Tố Xoài',         35000, N'Sinh to'),
(N'Sinh Tố Chuối',        30000, N'Sinh to'),
(N'Coca Cola',             20000, N'Nuoc ngot'),
(N'Pepsi',                 20000, N'Nuoc ngot'),
(N'Nước Cam Ép',           30000, N'Nuoc ngot'),
(N'Nước Suối',             15000, N'Nuoc ngot'),
(N'Bánh Croissant',        30000, N'Do an nhe'),
(N'Tiramisu',              45000, N'Do an nhe'),
(N'Cheesecake',            50000, N'Do an nhe'),
(N'Bánh Mì Thịt',          25000, N'Do an nhe');

-- ── BÀN ──────────────────────────────────────────────────────
-- MaBan: 1-10
INSERT INTO Ban (TenBan, KhuVuc, TrangThai, SoCho) VALUES
(N'Bàn 1',   N'Tầng 1',    N'Trống',          4),
(N'Bàn 2',   N'Tầng 1',    N'Trống',          4),
(N'Bàn 3',   N'Tầng 1',    N'Trống',          4),
(N'Bàn 4',   N'Tầng 1',    N'Trống',          4),
(N'Bàn 5',   N'Ngoài Trời',N'Trống',          2),
(N'Bàn 6',   N'Ngoài Trời',N'Đang sử dụng',   4),
(N'Bàn 7',   N'Ngoài Trời',N'Trống',          2),
(N'Bàn 8',   N'Tầng 2',    N'Trống',          6),
(N'Bàn 9',   N'Tầng 2',    N'Trống',          6),
(N'Bàn VIP', N'Phòng VIP', N'Trống',          8);

-- ── CA LÀM ───────────────────────────────────────────────────
-- MaCa: 1-3
INSERT INTO CaLam (TenCa, GioBatDau, GioKetThuc, TienCa) VALUES
(N'Ca sáng',  '07:00', '12:00', 100000),
(N'Ca chiều', '12:00', '17:00', 100000),
(N'Ca tối',   '17:00', '22:00', 120000);

-- ── HÓA ĐƠN (20 hóa đơn trải dài 2 tuần) ────────────────────
INSERT INTO HoaDon (MaNV, MaKH, MaBan, MaCa, NgayLap, TongTien) VALUES
-- 14 ngày trước
(1, 1, 3, 1, DATEADD(DAY,-14,GETDATE()), 110000),
(2, 2, 5, 2, DATEADD(DAY,-14,GETDATE()), 130000),
-- 10 ngày trước
(4, 4, 1, 1, DATEADD(DAY,-10,GETDATE()), 135000),
(3, 3, NULL,2, DATEADD(DAY,-10,GETDATE()), 135000),   -- mang về
-- 7 ngày trước
(1, 6, 4, 1, DATEADD(DAY,-7,GETDATE()), 135000),
(2, 7, 7, 2, DATEADD(DAY,-7,GETDATE()), 115000),
(5, 5, 2, 3, DATEADD(DAY,-7,GETDATE()), 171000),
-- 5 ngày trước
(4, 8, 6, 1, DATEADD(DAY,-5,GETDATE()), 125000),
(3, 1, 8, 2, DATEADD(DAY,-5,GETDATE()), 191000),
-- 3 ngày trước
(1, 2, 1, 1, DATEADD(DAY,-3,GETDATE()), 105000),
(2, 4, 3, 2, DATEADD(DAY,-3,GETDATE()), 165000),
(5, 6, 5, 3, DATEADD(DAY,-3,GETDATE()), 155000),
-- 2 ngày trước
(4, 3, NULL,1, DATEADD(DAY,-2,GETDATE()), 105000),    -- mang về
(3, 7, 2, 2, DATEADD(DAY,-2,GETDATE()), 125000),
-- Hôm qua
(1, 8, 9, 1, DATEADD(DAY,-1,GETDATE()), 138000),
(2, 5, 4, 2, DATEADD(DAY,-1,GETDATE()), 225000),
(5, 1, 6, 3, DATEADD(DAY,-1,GETDATE()), 175000),
-- Hôm nay
(4, 4, 2, 1, GETDATE(), 70000),
(2, 3, 1, 2, GETDATE(), 40000),
(1, 6, 3, 1, GETDATE(), 155000);

-- ── CHI TIẾT HÓA ĐƠN ─────────────────────────────────────────
INSERT INTO ChiTietHoaDon (MaHD, MaSP, SoLuong, Gia, ThanhTien) VALUES
-- HD 1  (110000): Cà phê Sữa x2, Trà Đào x1, Bánh Croissant x1
(1,  2, 2, 25000,  50000),
(1,  9, 1, 30000,  30000),
(1, 22, 1, 30000,  30000),
-- HD 2  (130000): Latte x1, Sinh Tố Bơ x2
(2,  5, 1, 50000,  50000),
(2, 14, 2, 40000,  80000),
-- HD 3  (135000): Cà phê Đen x3, Cà phê Sữa x1, Bánh Mì Thịt x2
(3,  1, 3, 20000,  60000),
(3,  2, 1, 25000,  25000),
(3, 25, 2, 25000,  50000),
-- HD 4  (135000): Cappuccino x2, Tiramisu x1
(4,  4, 2, 45000,  90000),
(4, 23, 1, 45000,  45000),
-- HD 5  (135000): Americano x1, Cold Brew x1, Cheesecake x1
(5,  6, 1, 40000,  40000),
(5,  7, 1, 45000,  45000),
(5, 24, 1, 50000,  50000),
-- HD 6  (115000): Trà Sữa Trân Châu x2, Sinh Tố Dâu x1
(6, 11, 2, 40000,  80000),
(6, 15, 1, 35000,  35000),
-- HD 7  (171000): Cà phê Trứng x2, Trà Ô Long x1, Bánh Croissant x2
(7,  8, 2, 38000,  76000),
(7, 13, 1, 35000,  35000),
(7, 22, 2, 30000,  60000),
-- HD 8  (125000): Latte x2, Bánh Mì Thịt x1
(8,  5, 2, 50000, 100000),
(8, 25, 1, 25000,  25000),
-- HD 9  (191000): Bạc Xỉu x3, Trà Lài Mật Ong x2, Tiramisu x1
(9,  3, 3, 30000,  90000),
(9, 10, 2, 28000,  56000),
(9, 23, 1, 45000,  45000),
-- HD 10 (105000): Cà phê Đen x2, Cà phê Sữa x1, Coca Cola x2
(10, 1, 2, 20000,  40000),
(10, 2, 1, 25000,  25000),
(10,18, 2, 20000,  40000),
-- HD 11 (165000): Cappuccino x1, Sinh Tố Xoài x2, Cheesecake x1
(11, 4, 1, 45000,  45000),
(11,16, 2, 35000,  70000),
(11,24, 1, 50000,  50000),
-- HD 12 (155000): Americano x2, Trà Chanh x3
(12, 6, 2, 40000,  80000),
(12,12, 3, 25000,  75000),
-- HD 13 (105000): Cold Brew x1, Bánh Croissant x2
(13, 7, 1, 45000,  45000),
(13,22, 2, 30000,  60000),
-- HD 14 (125000): Trà Sữa Trân Châu x1, Sinh Tố Chuối x2, Bánh Mì Thịt x1
(14,11, 1, 40000,  40000),
(14,17, 2, 30000,  60000),
(14,25, 1, 25000,  25000),
-- HD 15 (138000): Latte x2, Cà phê Trứng x1
(15, 5, 2, 50000, 100000),
(15, 8, 1, 38000,  38000),
-- HD 16 (225000): Cappuccino x2, Trà Ô Long x1, Cheesecake x2
(16, 4, 2, 45000,  90000),
(16,13, 1, 35000,  35000),
(16,24, 2, 50000, 100000),
-- HD 17 (175000): Americano x1, Cold Brew x2, Tiramisu x1
(17, 6, 1, 40000,  40000),
(17, 7, 2, 45000,  90000),
(17,23, 1, 45000,  45000),
-- HD 18 (70000): Cà phê Đen x2, Trà Đào x1
(18, 1, 2, 20000,  40000),
(18, 9, 1, 30000,  30000),
-- HD 19 (40000): Sinh Tố Bơ x1
(19,14, 1, 40000,  40000),
-- HD 20 (155000): Latte x1, Cappuccino x1, Bánh Croissant x2
(20, 5, 1, 50000,  50000),
(20, 4, 1, 45000,  45000),
(20,22, 2, 30000,  60000);

-- ── CHẤM CÔNG (10 ngày gần nhất + hôm nay, MaNV 1-5) ────────
INSERT INTO ChamCong (MaNV, MaCa, NgayLam, GioVao, GioRa) VALUES
-- MaNV 1 (Quản lý) – Ca sáng
(1,1, CAST(DATEADD(DAY,-10,GETDATE()) AS DATE), '07:00','12:00'),
(1,1, CAST(DATEADD(DAY, -9,GETDATE()) AS DATE), '07:05','12:00'),
(1,1, CAST(DATEADD(DAY, -8,GETDATE()) AS DATE), '07:00','12:00'),
(1,1, CAST(DATEADD(DAY, -7,GETDATE()) AS DATE), '06:58','12:00'),
(1,1, CAST(DATEADD(DAY, -6,GETDATE()) AS DATE), '07:00','12:00'),
(1,1, CAST(DATEADD(DAY, -5,GETDATE()) AS DATE), '07:05','12:00'),
(1,1, CAST(DATEADD(DAY, -4,GETDATE()) AS DATE), '07:00','12:05'),
(1,1, CAST(DATEADD(DAY, -3,GETDATE()) AS DATE), '06:55','12:00'),
(1,1, CAST(DATEADD(DAY, -2,GETDATE()) AS DATE), '07:10','12:00'),
(1,1, CAST(DATEADD(DAY, -1,GETDATE()) AS DATE), '07:00','12:00'),
(1,1, CAST(GETDATE() AS DATE),                   '07:02', NULL),  -- hôm nay chưa ra

-- MaNV 2 (Thu ngân) – Ca chiều
(2,2, CAST(DATEADD(DAY,-10,GETDATE()) AS DATE), '12:00','17:00'),
(2,2, CAST(DATEADD(DAY, -9,GETDATE()) AS DATE), '12:00','17:00'),
(2,2, CAST(DATEADD(DAY, -8,GETDATE()) AS DATE), '12:05','17:10'),
(2,2, CAST(DATEADD(DAY, -7,GETDATE()) AS DATE), '12:00','17:00'),
(2,2, CAST(DATEADD(DAY, -6,GETDATE()) AS DATE), '11:58','17:00'),
(2,2, CAST(DATEADD(DAY, -5,GETDATE()) AS DATE), '12:00','17:00'),
(2,2, CAST(DATEADD(DAY, -4,GETDATE()) AS DATE), '12:05','17:10'),
(2,2, CAST(DATEADD(DAY, -3,GETDATE()) AS DATE), '11:55','17:00'),
(2,2, CAST(DATEADD(DAY, -2,GETDATE()) AS DATE), '12:00','17:05'),
(2,2, CAST(DATEADD(DAY, -1,GETDATE()) AS DATE), '12:00','17:00'),
(2,2, CAST(GETDATE() AS DATE),                   '12:00', NULL),  -- hôm nay chưa ra

-- MaNV 3 (Phục vụ) – Ca chiều
(3,2, CAST(DATEADD(DAY,-10,GETDATE()) AS DATE), '12:00','17:00'),
(3,2, CAST(DATEADD(DAY, -9,GETDATE()) AS DATE), '12:10','17:00'),
(3,2, CAST(DATEADD(DAY, -8,GETDATE()) AS DATE), '12:00','17:00'),
(3,2, CAST(DATEADD(DAY, -7,GETDATE()) AS DATE), '12:00','17:00'),
(3,2, CAST(DATEADD(DAY, -6,GETDATE()) AS DATE), '12:20','17:00'),  -- đi muộn
(3,2, CAST(DATEADD(DAY, -5,GETDATE()) AS DATE), '12:10','17:00'),
(3,2, CAST(DATEADD(DAY, -4,GETDATE()) AS DATE), '12:00','17:00'),
(3,2, CAST(DATEADD(DAY, -3,GETDATE()) AS DATE), '12:00','17:00'),
(3,2, CAST(DATEADD(DAY, -2,GETDATE()) AS DATE), '12:15','17:00'),
(3,2, CAST(DATEADD(DAY, -1,GETDATE()) AS DATE), '12:00','17:00'),
(3,2, CAST(GETDATE() AS DATE),                   '12:05', NULL),

-- MaNV 4 (Barista) – Ca sáng
(4,1, CAST(DATEADD(DAY,-10,GETDATE()) AS DATE), '07:00','12:00'),
(4,1, CAST(DATEADD(DAY, -9,GETDATE()) AS DATE), '07:00','12:00'),
(4,1, CAST(DATEADD(DAY, -8,GETDATE()) AS DATE), '06:50','12:00'),
(4,1, CAST(DATEADD(DAY, -7,GETDATE()) AS DATE), '07:00','12:00'),
(4,1, CAST(DATEADD(DAY, -6,GETDATE()) AS DATE), '07:00','12:00'),
(4,1, CAST(DATEADD(DAY, -5,GETDATE()) AS DATE), '07:00','12:00'),
(4,1, CAST(DATEADD(DAY, -4,GETDATE()) AS DATE), '07:00','12:00'),
(4,1, CAST(DATEADD(DAY, -3,GETDATE()) AS DATE), '07:05','12:00'),
(4,1, CAST(DATEADD(DAY, -2,GETDATE()) AS DATE), '07:00','12:00'),
(4,1, CAST(DATEADD(DAY, -1,GETDATE()) AS DATE), '06:50','12:00'),
(4,1, CAST(GETDATE() AS DATE),                   '07:00', NULL),

-- MaNV 5 (Phục vụ) – Ca tối
(5,3, CAST(DATEADD(DAY,-10,GETDATE()) AS DATE), '17:00','22:00'),
(5,3, CAST(DATEADD(DAY, -9,GETDATE()) AS DATE), '17:00','22:00'),
(5,3, CAST(DATEADD(DAY, -8,GETDATE()) AS DATE), '17:05','22:00'),
(5,3, CAST(DATEADD(DAY, -7,GETDATE()) AS DATE), '17:00','22:00'),
(5,3, CAST(DATEADD(DAY, -6,GETDATE()) AS DATE), '17:00','22:00'),
(5,3, CAST(DATEADD(DAY, -5,GETDATE()) AS DATE), '17:00','22:00'),
(5,3, CAST(DATEADD(DAY, -4,GETDATE()) AS DATE), '17:05','22:00'),
(5,3, CAST(DATEADD(DAY, -3,GETDATE()) AS DATE), '17:00','22:00'),
(5,3, CAST(DATEADD(DAY, -2,GETDATE()) AS DATE), '17:10','22:00'),
(5,3, CAST(DATEADD(DAY, -1,GETDATE()) AS DATE), '17:00','22:00'),
(5,3, CAST(GETDATE() AS DATE),                   '17:00', NULL);

-- ── CÀI ĐẶT HỆ THỐNG ─────────────────────────────────────────
CREATE TABLE Settings (
    SettingId    INT IDENTITY PRIMARY KEY,
    SettingKey   NVARCHAR(100) NOT NULL UNIQUE,
    SettingValue NVARCHAR(500) NULL,
    UpdatedAt    DATETIME DEFAULT GETDATE()
);

INSERT INTO Settings (SettingKey, SettingValue) VALUES
(N'SHOP_NAME',              N'The Morning Brew'),
(N'SHOP_ADDRESS',           N'123 Nguyễn Huệ, Phường Bến Nghé, Quận 1, TP.HCM'),
(N'SHOP_PHONE',             N'028-3823-4567'),
(N'SHOP_EMAIL',             N'hello@morningbrew.vn'),
(N'DEFAULT_DISCOUNT',       N'0'),
(N'INVOICE_RETENTION_DAYS', N'365'),
(N'DEBUG_MODE',             N'false'),
(N'APP_VERSION',            N'1.0.0');

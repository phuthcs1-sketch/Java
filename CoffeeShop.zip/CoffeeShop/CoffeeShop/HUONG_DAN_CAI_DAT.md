# ☕ Hướng dẫn Cài đặt & Chạy CoffeeShop Management System (Windows)

## Mục lục
1. [Yêu cầu hệ thống](#1-yêu-cầu-hệ-thống)
2. [Cài đặt Java JDK 17](#2-cài-đặt-java-jdk-17)
3. [Cài đặt Apache Maven](#3-cài-đặt-apache-maven)
4. [Cài đặt SQL Server](#4-cài-đặt-sql-server)
5. [Tạo Database](#5-tạo-database)
6. [Cấu hình kết nối DB](#6-cấu-hình-kết-nối-db)
7. [Chạy ứng dụng](#7-chạy-ứng-dụng)
8. [Tài khoản mặc định](#8-tài-khoản-mặc-định)
9. [Xử lý lỗi thường gặp](#9-xử-lý-lỗi-thường-gặp)

---

## 1. Yêu cầu hệ thống

| Thành phần | Phiên bản | Ghi chú |
|---|---|---|
| Java JDK | **17** hoặc cao hơn | Bắt buộc |
| Apache Maven | **3.6+** | Bắt buộc |
| SQL Server | **2019 / 2022** | Express (miễn phí) đủ dùng |
| RAM | Tối thiểu **4 GB** | Khuyến nghị 8 GB |

---

## 2. Cài đặt Java JDK 17

1. Truy cập: https://adoptium.net/temurin/releases/?version=17
2. Tải file `.msi` cho Windows x64
3. Chạy installer, **tích chọn** "Set JAVA_HOME variable" và "Add to PATH"
4. Kiểm tra cài đặt — mở **Command Prompt**:
   ```cmd
   java -version
   ```
   Kết quả mong đợi:
   ```
   openjdk version "17.x.x" ...
   ```

---

## 3. Cài đặt Apache Maven

**Cách 1 — Chocolatey (khuyến nghị, chạy PowerShell as Admin):**
```powershell
# Cài Chocolatey nếu chưa có
Set-ExecutionPolicy Bypass -Scope Process -Force
[System.Net.ServicePointManager]::SecurityProtocol = [System.Net.ServicePointManager]::SecurityProtocol -bor 3072
iex ((New-Object System.Net.WebClient).DownloadString('https://community.chocolatey.org/install.ps1'))

# Cài Maven
choco install maven -y
```

**Cách 2 — Thủ công:**
1. Tải tại: https://maven.apache.org/download.cgi → chọn `apache-maven-3.x.x-bin.zip`
2. Giải nén vào `C:\Program Files\Apache\maven`
3. Thêm biến môi trường:
   - `MAVEN_HOME` = `C:\Program Files\Apache\maven`
   - Thêm `%MAVEN_HOME%\bin` vào `PATH`
4. Mở Command Prompt mới, kiểm tra:
   ```cmd
   mvn -version
   ```

Kết quả mong đợi:
```
Apache Maven 3.x.x
Java version: 17.x.x
```

---

## 4. Cài đặt SQL Server

### SQL Server Express 2022 (miễn phí)

1. Tải tại: https://www.microsoft.com/en-us/sql-server/sql-server-downloads
2. Chọn **Express** → tải file `SQL2022-SSEI-Expr.exe`
3. Chạy installer → chọn **"Basic"** (đơn giản nhất)
4. Ghi nhớ tên instance (mặc định: `SQLEXPRESS`)
5. Sau khi cài xong, tải thêm **SQL Server Management Studio (SSMS)**:
   https://aka.ms/ssmsfullsetup

6. Bật **SQL Server Authentication**:
   - Mở SSMS → Connect tới server
   - Chuột phải vào server → Properties → Security
   - Chọn **"SQL Server and Windows Authentication mode"**
   - Restart SQL Server service

7. Tạo user `sa`:
   - Security → Logins → `sa` → chuột phải → Properties
   - Đặt password: `Admin123!`
   - Status → Login: **Enabled**

8. Đảm bảo SQL Server chạy trên **port 1433**:
   - Mở **SQL Server Configuration Manager**
   - SQL Server Network Configuration → Protocols for SQLEXPRESS
   - **TCP/IP** → Enable → Properties → IP Addresses → IPAll → TCP Port = `1433`
   - Restart SQL Server service

---

## 5. Tạo Database

### Dùng SSMS

1. Mở SSMS, kết nối tới SQL Server
2. File → Open → File → chọn `COFFEESHOP.sql`
3. Nhấn **F5** hoặc nút **Execute**

### Dùng sqlcmd (Command Line)

```cmd
sqlcmd -S localhost,1433 -U sa -P Admin123! -i COFFEESHOP.sql
```

**Kiểm tra database đã tạo:**
```sql
USE COFFEESHOP;
SELECT COUNT(*) as SoNhanVien FROM NhanVien;
-- Kết quả mong đợi: 6
```

---

## 6. Cấu hình kết nối DB

File kết nối: `src/main/java/CoffeeShop/DBConnection.java`

```java
private static final String URL =
    "jdbc:sqlserver://localhost:1433;databaseName=COFFEESHOP;encrypt=false;loginTimeout=5;";
private static final String USER = "sa";
private static final String PASS = "Admin123!";
```

> Nếu bạn dùng tên instance khác (ví dụ `SQLEXPRESS`), đổi URL thành:
> ```
> jdbc:sqlserver://localhost\SQLEXPRESS;databaseName=COFFEESHOP;encrypt=false;
> ```

---

## 7. Chạy ứng dụng

### Cài dependencies và build

Mở **Command Prompt** tại thư mục dự án (`CoffeeShop/`):

```cmd
mvn clean install -DskipTests
```

### Chạy ứng dụng

```cmd
mvn javafx:run
```

### Chạy từ IntelliJ IDEA

1. File → Open → chọn thư mục `CoffeeShop`
2. Chờ Maven sync xong
3. Mở `src/main/java/CoffeeShop/CoffeeShopApplication.java`
4. Nhấn nút ▶️ bên cạnh `main()`

### Chạy từ VS Code

1. Cài extensions: **Extension Pack for Java**
2. Mở thư mục `CoffeeShop`
3. Nhấn **F5** hoặc mở `CoffeeShopApplication.java` → Run

---

## 8. Tài khoản mặc định

| Tên đăng nhập | Mật khẩu | Quyền | Ghi chú |
|---|---|---|---|
| `admin` | `admin123` | **Admin** — toàn quyền | Cài đặt hệ thống |
| `nva` | `123456` | **Manager** — quản lý | Không có Cài đặt |
| `ttb` | `123456` | **Employee** — nhân viên | Chỉ POS, Bàn, CC |
| `lvc` | `123456` | **Employee** | |
| `ptd` | `123456` | **Employee** | |
| `hve` | `123456` | **Employee** | |

---

## 9. Xử lý lỗi thường gặp

### ❌ `Connection failed!` khi khởi động

**Nguyên nhân**: SQL Server chưa chạy hoặc sai thông tin kết nối.

**Kiểm tra:**
- Mở *Services* (`Win+R` → `services.msc`) → tìm `SQL Server (SQLEXPRESS)` → Start
- Đảm bảo port 1433 không bị firewall chặn

---

### ❌ `Error resolving onAction='#handler'`

**Nguyên nhân**: Ứng dụng đang dùng file FXML cũ từ `target/`.

**Cách sửa:**
```cmd
mvn clean javafx:run
```

---

### ❌ `ClassNotFoundException: com.microsoft.sqlserver.jdbc.SQLServerDriver`

**Nguyên nhân**: Dependency JDBC chưa được tải.

**Cách sửa:**
```cmd
mvn clean install -DskipTests
mvn javafx:run
```

---

### ❌ Màn hình trắng / không hiển thị JavaFX

**Nguyên nhân**: Java version không khớp hoặc thiếu JavaFX modules.

**Kiểm tra:**
```cmd
java -version   # Phải là 17+
mvn -version    # Phải thấy Java version: 17
```

Nếu máy có nhiều JDK, đặt `JAVA_HOME` trỏ đúng vào JDK 17.

---

## Cấu trúc dự án

```
CoffeeShop/
├── src/
│   └── main/
│       ├── java/CoffeeShop/
│       │   ├── controller/      # Xử lý logic UI
│       │   ├── dao/             # Truy vấn database
│       │   ├── util/            # Tiện ích (Logger, SceneManager...)
│       │   └── CoffeeShopApplication.java
│       └── resources/CoffeeShop/
│           ├── view/            # File FXML (giao diện)
│           └── style/           # CSS
├── COFFEESHOP.sql               # Script tạo & nhập dữ liệu DB
├── pom.xml                      # Cấu hình Maven & dependencies
└── HUONG_DAN_CAI_DAT.md         # File này
```

---

*Phiên bản hệ thống: v1.0.0 | Java 17 | JavaFX 21 | SQL Server 2019/2022*

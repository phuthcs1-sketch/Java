package CoffeeShop;

import java.sql.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class Customer {
    public static void hienThiKhachHangGui(Frame parent) {
        try (Connection con = DBConnection.getConnection();
             PreparedStatement p = con.prepareStatement("SELECT MaKH, TenKH, DienThoai, DiemTich FROM KhachHang ORDER BY MaKH");
             ResultSet r = p.executeQuery()) {
            DefaultTableModel model = new DefaultTableModel();
            model.addColumn("MaKH"); model.addColumn("TenKH"); model.addColumn("DienThoai"); model.addColumn("DiemTich");
            while (r.next()) model.addRow(new Object[] { 
                r.getInt("MaKH"), 
                r.getString("TenKH"), 
                r.getString("DienThoai"), 
                r.getInt("DiemTich") 
            });
            JTable table = new JTable(model);
            JOptionPane.showMessageDialog(parent, new JScrollPane(table), "Danh sách khách hàng", JOptionPane.INFORMATION_MESSAGE);
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(parent, "Lỗi: " + e.getMessage(), "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void themKhachHang(String ten, String sdt) {
        try (Connection con = DBConnection.getConnection();
             PreparedStatement p = con.prepareStatement("INSERT INTO KhachHang(TenKH,DienThoai,DiemTich) VALUES(?,?,0)")) {
            p.setString(1, ten); 
            p.setString(2, sdt); 
            p.executeUpdate();
            JOptionPane.showMessageDialog(null, "Thêm khách hàng OK");
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Lỗi thêm KH: " + e.getMessage());
        }
    }

    public static void xoaKhachHang(int id) {
        try (Connection con = DBConnection.getConnection();
             PreparedStatement p = con.prepareStatement("DELETE FROM KhachHang WHERE MaKH=?")) {
            p.setInt(1, id); 
            int n = p.executeUpdate();
            JOptionPane.showMessageDialog(null, n>0 ? "Xóa thành công" : "Không tìm thấy");
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Lỗi xóa KH: " + e.getMessage());
        }
    }
    
    // Thêm điểm tích lũy cho khách hàng
    public static void themDiemTichLuy(int maKH, int diemThem) {
        try (Connection con = DBConnection.getConnection();
             PreparedStatement p = con.prepareStatement(
                 "UPDATE KhachHang SET DiemTich = DiemTich + ? WHERE MaKH = ?")) {
            p.setInt(1, diemThem);
            p.setInt(2, maKH);
            p.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    // Giảm điểm khi đổi thưởng
    public static boolean giamDiemTichLuy(int maKH, int diemGiam) {
        try (Connection con = DBConnection.getConnection();
             PreparedStatement p = con.prepareStatement(
                 "UPDATE KhachHang SET DiemTich = DiemTich - ? WHERE MaKH = ? AND DiemTich >= ?")) {
            p.setInt(1, diemGiam);
            p.setInt(2, maKH);
            p.setInt(3, diemGiam);
            int updated = p.executeUpdate();
            return updated > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
    
    // Xem điểm tích lũy
    public static int xemDiemTichLuy(int maKH) {
        try (Connection con = DBConnection.getConnection();
             PreparedStatement p = con.prepareStatement(
                 "SELECT DiemTich FROM KhachHang WHERE MaKH = ?")) {
            p.setInt(1, maKH);
            try (ResultSet r = p.executeQuery()) {
                if (r.next()) {
                    return r.getInt("DiemTich");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }
}
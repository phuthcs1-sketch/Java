package CoffeeShop.controller;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.beans.property.SimpleStringProperty;
import CoffeeShop.util.LoggerUtil;
import CoffeeShop.util.SceneManager;
import CoffeeShop.dao.CategoryDAO;
import java.util.logging.Logger;
import java.util.List;
import java.util.Map;

public class CategoryController {

    private static final Logger logger = LoggerUtil.getLogger(CategoryController.class.getName());

    @FXML private TableView<Map<String, Object>> categoriesTable;
    @FXML private TextField searchField;
    @FXML private Label totalCategoriesLabel;

    private ObservableList<Map<String, Object>> allCategories = FXCollections.observableArrayList();
    private CategoryDAO categoryDAO = new CategoryDAO();

    @FXML
    private void initialize() {
        logger.info("📂 Khởi tạo CategoryController");
        setupCategoryTable();
        loadCategories();
        setupEventListeners();
        logger.info("✅ CategoryController sẵn sàng");
    }

    private void setupCategoryTable() {
        TableColumn<Map<String, Object>, String> idCol = new TableColumn<>("ID");
        idCol.setCellValueFactory(cellData ->
            new SimpleStringProperty(cellData.getValue().get("id").toString()));
        idCol.setPrefWidth(60);

        TableColumn<Map<String, Object>, String> nameCol = new TableColumn<>("Tên danh mục");
        nameCol.setCellValueFactory(cellData ->
            new SimpleStringProperty((String) cellData.getValue().get("name")));
        nameCol.setPrefWidth(250);

        TableColumn<Map<String, Object>, String> countCol = new TableColumn<>("Số sản phẩm");
        countCol.setCellValueFactory(cellData -> {
            String categoryName = (String) cellData.getValue().get("name");
            int count = categoryDAO.getProductCountInCategory(categoryName);
            return new SimpleStringProperty(String.valueOf(count));
        });
        countCol.setPrefWidth(120);

        TableColumn<Map<String, Object>, Void> actionCol = new TableColumn<>("Hành động");
        actionCol.setCellFactory(param -> new TableCell<Map<String, Object>, Void>() {
            private final Button editBtn = new Button("✎ Sửa");
            private final Button deleteBtn = new Button("✕ Xóa");

            {
                editBtn.setStyle("-fx-font-size: 11px; -fx-padding: 4px 8px; -fx-background-color: #3498db; -fx-text-fill: white;");
                deleteBtn.setStyle("-fx-font-size: 11px; -fx-padding: 4px 8px; -fx-background-color: #e74c3c; -fx-text-fill: white;");

                editBtn.setOnAction(e -> {
                    Map<String, Object> cat = getTableView().getItems().get(getIndex());
                    handleEditCategory(cat);
                });

                deleteBtn.setOnAction(e -> {
                    Map<String, Object> cat = getTableView().getItems().get(getIndex());
                    handleDeleteCategory(cat);
                });
            }

            @Override
            protected void updateItem(Void item, boolean empty) {
                super.updateItem(item, empty);
                if (empty) {
                    setGraphic(null);
                } else {
                    HBox box = new HBox(5, editBtn, deleteBtn);
                    setGraphic(box);
                }
            }
        });
        actionCol.setPrefWidth(150);

        categoriesTable.getColumns().add(idCol);
        categoriesTable.getColumns().add(nameCol);
        categoriesTable.getColumns().add(countCol);
        categoriesTable.getColumns().add(actionCol);
    }

    private void loadCategories() {
        logger.info("📥 Đang tải danh sách danh mục...");
        List<Map<String, Object>> categories = categoryDAO.getAllCategories();
        allCategories.clear();
        allCategories.addAll(categories);
        categoriesTable.setItems(allCategories);
        totalCategoriesLabel.setText(String.valueOf(categories.size()));
        logger.info("✅ Tải " + categories.size() + " danh mục");
    }

    private void setupEventListeners() {
        searchField.textProperty().addListener((obs, old, newValue) -> filterCategories());
    }

    private void filterCategories() {
        String searchText = searchField.getText().toLowerCase();
        ObservableList<Map<String, Object>> filtered = FXCollections.observableArrayList();

        for (Map<String, Object> cat : allCategories) {
            String name = ((String) cat.get("name")).toLowerCase();
            if (name.contains(searchText)) {
                filtered.add(cat);
            }
        }

        categoriesTable.setItems(filtered);
    }

    @FXML
    private void handleAddCategory() {
        TextInputDialog dialog = new TextInputDialog();
        dialog.setTitle("Thêm danh mục");
        dialog.setHeaderText("Nhập tên danh mục mới");
        dialog.setContentText("Tên danh mục:");

        dialog.showAndWait().ifPresent(name -> {
            name = name.trim();
            if (name.isEmpty()) {
                showAlert(Alert.AlertType.ERROR, "Lỗi", "❌ Tên danh mục không được để trống!");
                return;
            }

            if (categoryDAO.categoryExists(name)) {
                showAlert(Alert.AlertType.ERROR, "Lỗi", "❌ Danh mục '" + name + "' đã tồn tại!");
                return;
            }

            if (categoryDAO.addCategory(name)) {
                showAlert(Alert.AlertType.INFORMATION, "Thành công", "✅ Đã thêm danh mục '" + name + "'!");
                loadCategories();
                logger.info("✅ Thêm danh mục: " + name);
            } else {
                showAlert(Alert.AlertType.ERROR, "Lỗi", "❌ Không thể thêm danh mục. Vui lòng thử lại.");
            }
        });
    }

    private void handleEditCategory(Map<String, Object> cat) {
        String currentName = (String) cat.get("name");
        int id = (Integer) cat.get("id");

        TextInputDialog dialog = new TextInputDialog(currentName);
        dialog.setTitle("Sửa danh mục");
        dialog.setHeaderText("Sửa tên danh mục");
        dialog.setContentText("Tên mới:");

        dialog.showAndWait().ifPresent(newName -> {
            newName = newName.trim();
            if (newName.isEmpty()) {
                showAlert(Alert.AlertType.ERROR, "Lỗi", "❌ Tên danh mục không được để trống!");
                return;
            }

            if (newName.equals(currentName)) return;

            if (categoryDAO.categoryExists(newName)) {
                showAlert(Alert.AlertType.ERROR, "Lỗi", "❌ Danh mục '" + newName + "' đã tồn tại!");
                return;
            }

            if (categoryDAO.updateCategory(id, newName)) {
                showAlert(Alert.AlertType.INFORMATION, "Thành công", "✅ Đã cập nhật danh mục thành '" + newName + "'!");
                loadCategories();
                logger.info("✅ Sửa danh mục #" + id + ": " + currentName + " → " + newName);
            } else {
                showAlert(Alert.AlertType.ERROR, "Lỗi", "❌ Không thể cập nhật danh mục.");
            }
        });
    }

    private void handleDeleteCategory(Map<String, Object> cat) {
        String name = (String) cat.get("name");
        int id = (Integer) cat.get("id");
        int productCount = categoryDAO.getProductCountInCategory(name);

        String confirmMsg = "Bạn có chắc muốn xóa danh mục '" + name + "'?";
        if (productCount > 0) {
            confirmMsg += "\n\n⚠️ Danh mục này đang có " + productCount + " sản phẩm liên quan.";
        }

        Alert confirm = new Alert(Alert.AlertType.CONFIRMATION);
        confirm.setTitle("Xác nhận xóa");
        confirm.setHeaderText("Xóa danh mục");
        confirm.setContentText(confirmMsg);

        confirm.showAndWait().ifPresent(response -> {
            if (response == ButtonType.OK) {
                if (categoryDAO.deleteCategory(id)) {
                    showAlert(Alert.AlertType.INFORMATION, "Thành công", "✅ Đã xóa danh mục '" + name + "'!");
                    loadCategories();
                    logger.info("✅ Xóa danh mục #" + id + ": " + name);
                } else {
                    showAlert(Alert.AlertType.ERROR, "Lỗi", "❌ Không thể xóa danh mục.");
                }
            }
        });
    }

    @FXML
    private void handleRefresh() {
        logger.info("🔄 Làm mới dữ liệu");
        loadCategories();
    }

    @FXML
    private void handleBack() {
        logger.info("🔙 Quay lại Dashboard");
        SceneManager.switchScene(
            "/CoffeeShop/view/dashboard.fxml",
            "☕ Dashboard - Hệ thống quản lý quán cà phê",
            1200, 700
        );
    }

    private void showAlert(Alert.AlertType type, String title, String message) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(title);
        alert.setContentText(message);
        alert.showAndWait();
    }
}

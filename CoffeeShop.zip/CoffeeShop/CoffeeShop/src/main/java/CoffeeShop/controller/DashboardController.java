package CoffeeShop.controller;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.scene.layout.HBox;
import CoffeeShop.util.LoggerUtil;
import CoffeeShop.util.SceneManager;
import CoffeeShop.dao.ProductDAO;
import CoffeeShop.dao.UserDAO;
import CoffeeShop.dao.OrderDAO;
import CoffeeShop.dao.CustomerDAO;
import java.util.logging.Logger;

/**
 * Controller cho Dashboard
 * Hiển thị tổng quan và điều hướng đến các module khác
 * Code sạch, dễ đọc, dễ bảo trì
 */
public class DashboardController {
    
    private static final Logger logger = LoggerUtil.getLogger(DashboardController.class.getName());
    
    // Header
    @FXML private Label userInfoLabel;

    // Stats
    @FXML private Label totalRevenueLabel;
    @FXML private Label totalOrdersLabel;
    @FXML private Label totalCustomersLabel;
    @FXML private Label staffCountLabel;
    @FXML private Label statusLabel;

    // Tables
    @FXML private TableView recentOrdersTable;

    // Sidebar menu
    @FXML private VBox sidebarMenu;

    // Sidebar items cần ẩn/hiện theo role
    @FXML private Label    sectionGoods;
    @FXML private Button   btnProducts;
    @FXML private Button   btnCategories;
    @FXML private Separator sepHr;
    @FXML private Button   btnEmployees;
    @FXML private Button   btnCustomers;
    @FXML private Button   btnInvoices;
    @FXML private Separator sepReports;
    @FXML private Label    sectionReports;
    @FXML private Button   btnRevenue;
    @FXML private Button   btnStatistics;
    @FXML private Separator sepSettings;
    @FXML private Label    sectionSettings;
    @FXML private Button   btnSettings;

    @FXML
    private void initialize() {
        logger.info("📊 Khởi tạo Dashboard");

        String username = LoginController.getCurrentUsername();
        String role     = LoginController.getCurrentRole();

        String roleLabel = switch (role == null ? "" : role) {
            case "admin"    -> "Quản trị viên";
            case "manager"  -> "Quản lý";
            default         -> "Nhân viên";
        };
        userInfoLabel.setText("🙋 Xin chào " + username + "  |  " + roleLabel);

        applyRolePermissions(role);
        loadDashboardData();

        logger.info("✅ Dashboard đã sẵn sàng (role=" + role + ")");
    }

    /**
     * Ẩn/hiện menu theo role:
     *   admin    → toàn quyền
     *   manager  → không có Cài đặt hệ thống
     *   employee → chỉ POS, Bàn ăn, Chấm công
     */
    private void applyRolePermissions(String role) {
        if (role == null) role = "employee";

        boolean isAdmin   = "admin".equals(role);
        boolean isManager = isAdmin || "manager".equals(role);

        // Quản lý hàng: manager+
        setVisible(sectionGoods,  isManager);
        setVisible(btnProducts,   isManager);
        setVisible(btnCategories, isManager);

        // Nhân sự: manager+
        setVisible(sepHr,         isManager);
        setVisible(btnEmployees,  isManager);
        setVisible(btnCustomers,  isManager);

        // Hóa đơn: manager+
        setVisible(btnInvoices,   isManager);

        // Báo cáo: manager+
        setVisible(sepReports,    isManager);
        setVisible(sectionReports,isManager);
        setVisible(btnRevenue,    isManager);
        setVisible(btnStatistics, isManager);

        // Cài đặt: admin only
        setVisible(sepSettings,    isAdmin);
        setVisible(sectionSettings,isAdmin);
        setVisible(btnSettings,    isAdmin);
    }

    private void setVisible(javafx.scene.Node node, boolean visible) {
        node.setVisible(visible);
        node.setManaged(visible); // khi ẩn không chiếm không gian layout
    }
    
    /**
     * Tải dữ liệu cho dashboard
     */
    private void loadDashboardData() {
        logger.info("📥 Đang tải dữ liệu dashboard từ database...");
        
        try {
            ProductDAO productDAO = new ProductDAO();
            UserDAO userDAO = new UserDAO();
            OrderDAO orderDAO = new OrderDAO();
            CustomerDAO customerDAO = new CustomerDAO();
            
            // Lấy số lượng sản phẩm
            int totalProducts = productDAO.getTotalProducts();
            
            // Lấy số nhân viên
            int staffCount = userDAO.getTotalUsers();
            
            // Lấy doanh thu, đơn hàng, khách hàng từ database
            double totalRevenue = orderDAO.getTotalRevenue();
            int totalOrders = orderDAO.getTotalOrders();
            int totalCustomers = customerDAO.getTotalCustomers();
            
            // Cập nhật UI
            totalRevenueLabel.setText(String.format("%.0f ₫", totalRevenue));
            totalOrdersLabel.setText(totalOrders + "");
            totalCustomersLabel.setText(totalCustomers + "");
            staffCountLabel.setText(staffCount + "");
            statusLabel.setText("✅ Trạng thái: Kết nối");
            
            logger.info("✅ Tải dashboard OK: " + staffCount + " nhân viên, " + totalProducts + " sản phẩm, " + totalOrders + " đơn hàng");
            
        } catch (Exception e) {
            logger.severe("❌ Lỗi tải dữ liệu: " + e.getMessage());
            statusLabel.setText("❌ Lỗi: Không thể kết nối database");
            
            // Fallback: Gán giá trị mẫu
            totalRevenueLabel.setText("0 ₫");
            totalOrdersLabel.setText("0");
            totalCustomersLabel.setText("0");
            staffCountLabel.setText("0");
        }
    }
    
    // ============ MENU NAVIGATION ============
    
    @FXML
    private void showDashboard() {
        logger.info("🏠 Hiển thị Dashboard");
    }
    
    @FXML
    private void showProducts() {
        logger.info("📦 Chuyển sang quản lý sản phẩm");
        SceneManager.switchScene("/CoffeeShop/view/products.fxml", "Quản lý sản phẩm", 1200, 700);
    }
    
    @FXML
    private void showCategories() {
        logger.info("📂 Chuyển sang quản lý danh mục");
        SceneManager.switchScene("/CoffeeShop/view/category.fxml", "Quản lý Danh mục Sản phẩm", 1200, 700);
    }
    
    @FXML
    private void showEmployees() {
        logger.info("👥 Chuyển sang quản lý nhân viên");
        SceneManager.switchScene("/CoffeeShop/view/employees.fxml", "Quản lý nhân viên", 1200, 700);
    }
    
    @FXML
    private void showCustomers() {
        logger.info("👤 Chuyển sang quản lý khách hàng");
        SceneManager.switchScene("/CoffeeShop/view/customers.fxml", "Quản lý khách hàng", 1200, 700);
    }
    
    @FXML
    private void showAttendance() {
        logger.info("⏰ Chuyển sang chấm công");
        SceneManager.switchScene("/CoffeeShop/view/attendance.fxml", "Chấm công Nhân viên", 1400, 900);
    }
    
    @FXML
    private void showPOS() {
        logger.info("🛒 Chuyển sang bán hàng POS");
        SceneManager.switchScene("/CoffeeShop/view/pos.fxml", "Bán hàng POS", 1200, 700);
    }
    
    @FXML
    private void showInvoices() {
        logger.info("🧾 Chuyển sang quản lý hóa đơn");
        SceneManager.switchScene("/CoffeeShop/view/invoice.fxml", "Quản lý Hóa đơn", 1200, 750);
    }
    
    @FXML
    private void showTables() {
        logger.info("🪑 Chuyển sang quản lý bàn ăn");
        SceneManager.switchScene("/CoffeeShop/view/tables.fxml", "Quản lý Bàn ăn", 1200, 700);
    }
    
    @FXML
    private void showRevenue() {
        logger.info("📈 Chuyển sang báo cáo doanh thu");
        SceneManager.switchScene("/CoffeeShop/view/revenue_report.fxml", "Báo cáo Doanh thu", 1400, 900);
    }
    
    @FXML
    private void showStatistics() {
        logger.info("📊 Chuyển sang thống kê");
        SceneManager.switchScene("/CoffeeShop/view/statistics.fxml", "Thống kê Bán hàng", 1400, 900);
    }
    
    @FXML
    private void showSettings() {
        logger.info("⚙️ Chuyển sang cài đặt");
        SceneManager.switchScene("/CoffeeShop/view/settings.fxml", "Cài đặt Hệ thống", 1200, 700);
    }
    
    /**
     * Xử lý đăng xuất
     */
    @FXML
    private void handleLogout() {
        logger.info("🔓 Người dùng đăng xuất");
        
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Xác nhận");
        alert.setHeaderText("Bạn có chắc chắn muốn đăng xuất?");
        
        alert.showAndWait().ifPresent(response -> {
            if (response == ButtonType.OK) {
                SceneManager.switchScene(
                    "/CoffeeShop/view/login.fxml",
                    "Login - Coffee Shop Management",
                    950, 600
                );
            }
        });
    }
    
}

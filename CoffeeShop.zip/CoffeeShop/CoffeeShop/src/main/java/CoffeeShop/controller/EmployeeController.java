package CoffeeShop.controller;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.HBox;
import javafx.scene.layout.GridPane;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import CoffeeShop.util.LoggerUtil;
import CoffeeShop.util.SceneManager;
import CoffeeShop.dao.EmployeeDAO;
import java.util.logging.Logger;
import java.util.List;
import java.util.Map;

/**
 * Controller cho quản lý nhân viên
 */
public class EmployeeController {
    
    private static final Logger logger = LoggerUtil.getLogger(EmployeeController.class.getName());
    
    @FXML private TextField searchField;
    @FXML private Label totalEmployeesLabel;
    @FXML private TableView<Map<String, Object>> employeesTable;
    
    private ObservableList<Map<String, Object>> allEmployees = FXCollections.observableArrayList();
    private EmployeeDAO employeeDAO = new EmployeeDAO();
    
    @FXML
    private void initialize() {
        logger.info("👥 Khởi tạo EmployeeController");
        
        setupEmployeeTable();
        loadEmployees();
        setupEventListeners();
        
        logger.info("✅ EmployeeController sẵn sàng");
    }
    
    /**
     * Cấu hình bảng nhân viên
     */
    private void setupEmployeeTable() {
        // Cột ID
        TableColumn<Map<String, Object>, Integer> idCol = new TableColumn<>("ID");
        idCol.setCellValueFactory(cellData -> 
            new javafx.beans.property.SimpleObjectProperty<>((Integer)cellData.getValue().get("id")));
        idCol.setPrefWidth(50);
        
        // Cột Tên
        TableColumn<Map<String, Object>, String> nameCol = new TableColumn<>("Tên nhân viên");
        nameCol.setCellValueFactory(cellData -> 
            new javafx.beans.property.SimpleStringProperty((String)cellData.getValue().get("name")));
        nameCol.setPrefWidth(150);
        
        // Cột Chức vụ
        TableColumn<Map<String, Object>, String> posCol = new TableColumn<>("Chức vụ");
        posCol.setCellValueFactory(cellData -> 
            new javafx.beans.property.SimpleStringProperty((String)cellData.getValue().get("position")));
        posCol.setPrefWidth(120);
        
        // Cột Điện thoại
        TableColumn<Map<String, Object>, String> phoneCol = new TableColumn<>("Điện thoại");
        phoneCol.setCellValueFactory(cellData -> {
            Object v = cellData.getValue().get("phone");
            return new javafx.beans.property.SimpleStringProperty(v != null ? (String) v : "");
        });
        phoneCol.setPrefWidth(120);
        
        // Cột Lương
        TableColumn<Map<String, Object>, String> salaryCol = new TableColumn<>("Lương");
        salaryCol.setCellValueFactory(cellData -> 
            new javafx.beans.property.SimpleStringProperty(String.format("%.0f ₫", cellData.getValue().get("salary"))));
        salaryCol.setPrefWidth(120);
        
        // Cột Trạng thái
        TableColumn<Map<String, Object>, String> statusCol = new TableColumn<>("Trạng thái");
        statusCol.setCellValueFactory(cellData -> 
            new javafx.beans.property.SimpleStringProperty((String)cellData.getValue().get("status")));
        statusCol.setPrefWidth(100);
        
        // Cột Hành động
        TableColumn<Map<String, Object>, Void> actionCol = new TableColumn<>("Hành động");
        actionCol.setCellFactory(param -> new TableCell<Map<String, Object>, Void>() {
            private final Button editBtn = new Button("✎");
            private final Button deleteBtn = new Button("✕");
            
            {
                editBtn.setStyle("-fx-font-size: 12px; -fx-padding: 5px 8px; -fx-background-color: #3498db;");
                deleteBtn.setStyle("-fx-font-size: 12px; -fx-padding: 5px 8px; -fx-background-color: #e74c3c;");
                
                editBtn.setOnAction(event -> {
                    Map<String, Object> emp = getTableView().getItems().get(getIndex());
                    handleEditEmployee(emp);
                });
                
                deleteBtn.setOnAction(event -> {
                    Map<String, Object> emp = getTableView().getItems().get(getIndex());
                    handleDeleteEmployee((Integer)emp.get("id"));
                });
            }
            
            @Override
            protected void updateItem(Void item, boolean empty) {
                super.updateItem(item, empty);
                if (empty) {
                    setGraphic(null);
                } else {
                    HBox hbox = new HBox(5);
                    hbox.getChildren().addAll(editBtn, deleteBtn);
                    setGraphic(hbox);
                }
            }
        });
        actionCol.setPrefWidth(100);
        
        employeesTable.getColumns().addAll(idCol, nameCol, posCol, phoneCol, salaryCol, statusCol, actionCol);
    }
    
    /**
     * Tải danh sách nhân viên
     */
    private void loadEmployees() {
        logger.info("📥 Đang tải danh sách nhân viên...");
        
        List<Map<String, Object>> employees = employeeDAO.getAllEmployees();
        allEmployees.clear();
        allEmployees.addAll(employees);
        employeesTable.setItems(allEmployees);
        
        totalEmployeesLabel.setText(employees.size() + "");
        logger.info("✅ Tải " + employees.size() + " nhân viên");
    }
    
    /**
     * Cài đặt sự kiện
     */
    private void setupEventListeners() {
        searchField.textProperty().addListener((obs, old, newValue) -> {
            filterEmployees();
        });
    }
    
    /**
     * Lọc nhân viên
     */
    private void filterEmployees() {
        String searchText = searchField.getText().toLowerCase();
        ObservableList<Map<String, Object>> filtered = FXCollections.observableArrayList();
        
        for (Map<String, Object> emp : allEmployees) {
            String name = (String) emp.get("name");
            String phone = emp.get("phone") != null ? (String) emp.get("phone") : "";

            if (name.toLowerCase().contains(searchText) || phone.contains(searchText)) {
                filtered.add(emp);
            }
        }
        
        employeesTable.setItems(filtered);
    }
    
    /**
     * Thêm nhân viên mới
     */
    @FXML
    private void handleAddEmployee() {
        logger.info("➕ Thêm nhân viên mới");
        showEmployeeDialog(null);
    }
    
    /**
     * Sửa nhân viên
     */
    private void handleEditEmployee(Map<String, Object> employee) {
        logger.info("✎ Sửa nhân viên: " + employee.get("name"));
        showEmployeeDialog(employee);
    }
    
    /**
     * Xóa nhân viên
     */
    private void handleDeleteEmployee(int employeeId) {
        logger.info("✕ Xóa nhân viên #" + employeeId);
        
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Xác nhận xóa");
        alert.setHeaderText("Bạn có chắc muốn xóa nhân viên này?");
        
        alert.showAndWait().ifPresent(response -> {
            if (response == ButtonType.OK) {
                employeeDAO.deleteEmployee(employeeId);
                loadEmployees();
            }
        });
    }
    
    /**
     * Hiển thị dialog thêm/sửa nhân viên
     */
    private void showEmployeeDialog(Map<String, Object> employee) {
        Dialog<ButtonType> dialog = new Dialog<>();
        dialog.setTitle(employee == null ? "Thêm nhân viên" : "Sửa nhân viên");
        
        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(20));
        
        TextField nameField = new TextField();
        TextField phoneField = new TextField();
        TextField salaryField = new TextField();
        ComboBox<String> positionField = new ComboBox<>();
        ComboBox<String> statusField = new ComboBox<>();
        
        positionField.getItems().addAll("Quản lý", "Barista", "Phục vụ", "Kế toán");
        statusField.getItems().addAll("Dang lam", "Nghi phep", "Da nghi");
        
        if (employee != null) {
            nameField.setText((String)employee.get("name"));
            phoneField.setText((String)employee.get("phone"));
            salaryField.setText(String.valueOf(employee.get("salary")));
            positionField.setValue((String)employee.get("position"));
            statusField.setValue((String)employee.get("status"));
        } else {
            statusField.setValue("Dang lam");
        }
        
        grid.add(new Label("Tên nhân viên:"), 0, 0);
        grid.add(nameField, 1, 0);
        grid.add(new Label("Chức vụ:"), 0, 1);
        grid.add(positionField, 1, 1);
        grid.add(new Label("Điện thoại:"), 0, 2);
        grid.add(phoneField, 1, 2);
        grid.add(new Label("Lương:"), 0, 3);
        grid.add(salaryField, 1, 3);
        grid.add(new Label("Trạng thái:"), 0, 4);
        grid.add(statusField, 1, 4);
        
        dialog.getDialogPane().setContent(grid);
        dialog.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);
        
        dialog.showAndWait().ifPresent(result -> {
            if (result != ButtonType.OK) return;
            try {
                String name = nameField.getText();
                String position = positionField.getValue();
                String phone = phoneField.getText();
                double salary = Double.parseDouble(salaryField.getText());
                String status = statusField.getValue();
                
                if (employee == null) {
                    employeeDAO.addEmployee(name, position, phone, salary, status);
                    logger.info("✅ Thêm nhân viên: " + name);
                } else {
                    int id = (Integer)employee.get("id");
                    employeeDAO.updateEmployee(id, name, position, phone, salary, status);
                    logger.info("✅ Cập nhật nhân viên: " + name);
                }
                
                loadEmployees();
            } catch (NumberFormatException e) {
                showAlert("Lỗi", "Lương phải là số");
            }
        });
    }
    
    /**
     * Làm mới dữ liệu
     */
    @FXML
    private void handleRefresh() {
        logger.info("🔄 Làm mới dữ liệu");
        loadEmployees();
    }
    
    /**
     * Quay lại
     */
    @FXML
    private void handleBack() {
        logger.info("🔙 Quay lại");
        SceneManager.switchScene(
            "/CoffeeShop/view/dashboard.fxml",
            "☕ Dashboard - Hệ thống quản lý quán cà phê",
            1200, 700
        );
    }
    
    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(title);
        alert.setContentText(message);
        alert.showAndWait();
    }
}

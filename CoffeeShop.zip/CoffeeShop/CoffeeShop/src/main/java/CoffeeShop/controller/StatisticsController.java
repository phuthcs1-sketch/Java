package CoffeeShop.controller;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.chart.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.beans.property.SimpleStringProperty;
import CoffeeShop.util.LoggerUtil;
import CoffeeShop.util.SceneManager;
import CoffeeShop.dao.StatisticsDAO;
import java.util.logging.Logger;
import java.util.List;
import java.util.Map;

/**
 * Controller cho thống kê bán hàng
 */
public class StatisticsController {
    
    private static final Logger logger = LoggerUtil.getLogger(StatisticsController.class.getName());
    
    @FXML private Label todayRevenueLabel;
    @FXML private Label todayInvoicesLabel;
    @FXML private Label todayProductsLabel;
    @FXML private Label monthRevenueLabel;
    @FXML private Label monthInvoicesLabel;
    @FXML private Label monthCustomersLabel;
    
    @FXML private TableView<Map<String, Object>> categoryStatsTable;
    @FXML private TableView<Map<String, Object>> employeeSalesTable;
    @FXML private TableView<Map<String, Object>> paymentMethodTable;
    
    @FXML private PieChart categoryChart;
    @FXML private BarChart<String, Number> employeeChart;
    
    private StatisticsDAO statsDAO = new StatisticsDAO();
    
    @FXML
    private void initialize() {
        logger.info("📈 Khởi tạo StatisticsController");
        
        loadTodayStatistics();
        loadMonthlyStatistics();
        loadCategoryStatistics();
        loadEmployeeSalesStatistics();
        loadPaymentMethodStatistics();
        
        logger.info("✅ StatisticsController sẵn sàng");
    }
    
    /**
     * Tải thống kê hôm nay
     */
    private void loadTodayStatistics() {
        Map<String, Object> stats = statsDAO.getTodayStatistics();
        
        double revenue = (Double) stats.getOrDefault("revenue", 0.0);
        int invoices = (Integer) stats.getOrDefault("invoices", 0);
        int products = (Integer) stats.getOrDefault("products_sold", 0);
        
        todayRevenueLabel.setText(String.format("%.0f ₫", revenue));
        todayInvoicesLabel.setText(invoices + "");
        todayProductsLabel.setText(products + "");
        
        logger.info("✅ Thống kê hôm nay - Doanh thu: " + revenue);
    }
    
    /**
     * Tải thống kê tháng này
     */
    private void loadMonthlyStatistics() {
        Map<String, Object> stats = statsDAO.getMonthlyStatistics();
        
        double revenue = (Double) stats.getOrDefault("revenue", 0.0);
        int invoices = (Integer) stats.getOrDefault("invoices", 0);
        int customers = (Integer) stats.getOrDefault("customers", 0);
        
        monthRevenueLabel.setText(String.format("%.0f ₫", revenue));
        monthInvoicesLabel.setText(invoices + "");
        monthCustomersLabel.setText(customers + "");
        
        logger.info("✅ Thống kê tháng - Doanh thu: " + revenue);
    }
    
    /**
     * Tải thống kê danh mục
     */
    private void loadCategoryStatistics() {
        setupCategoryTable();
        List<Map<String, Object>> categories = statsDAO.getCategoryStatistics();
        ObservableList<Map<String, Object>> data = FXCollections.observableArrayList(categories);
        categoryStatsTable.setItems(data);
        
        // Setup Pie Chart
        setupCategoryChart(categories);
        logger.info("✅ Tải thống kê danh mục: " + categories.size());
    }
    
    /**
     * Cấu hình bảng thống kê danh mục
     */
    private void setupCategoryTable() {
        TableColumn<Map<String, Object>, String> nameCol = new TableColumn<>("Danh mục");
        nameCol.setCellValueFactory(cellData -> 
            new SimpleStringProperty((String)cellData.getValue().get("category")));
        nameCol.setPrefWidth(120);
        
        TableColumn<Map<String, Object>, String> qtyCol = new TableColumn<>("Số lượng");
        qtyCol.setCellValueFactory(cellData -> 
            new SimpleStringProperty(cellData.getValue().get("quantity").toString()));
        
        TableColumn<Map<String, Object>, String> totalCol = new TableColumn<>("Tổng tiền");
        totalCol.setCellValueFactory(cellData -> 
            new SimpleStringProperty(String.format("%.0f ₫", cellData.getValue().get("total"))));
        
        TableColumn<Map<String, Object>, String> percentCol = new TableColumn<>("Tỷ lệ %");
        percentCol.setCellValueFactory(cellData -> 
            new SimpleStringProperty(String.format("%.1f%%", cellData.getValue().get("percentage"))));
        
        categoryStatsTable.getColumns().clear();
        categoryStatsTable.getColumns().addAll(nameCol, qtyCol, totalCol, percentCol);
    }
    
    /**
     * Cấu hình pie chart danh mục
     */
    private void setupCategoryChart(List<Map<String, Object>> categories) {
        ObservableList<PieChart.Data> pieData = FXCollections.observableArrayList();
        
        for (Map<String, Object> cat : categories) {
            String name = (String) cat.get("category");
            int quantity = (Integer) cat.get("quantity");
            pieData.add(new PieChart.Data(name + " (" + quantity + ")", quantity));
        }
        
        categoryChart.setData(pieData);
        categoryChart.setTitle("Tỷ lệ Bán hàng Theo Danh mục");
    }
    
    /**
     * Tải thống kê nhân viên bán hàng
     */
    private void loadEmployeeSalesStatistics() {
        setupEmployeeTable();
        List<Map<String, Object>> employees = statsDAO.getEmployeeSalesStatistics();
        ObservableList<Map<String, Object>> data = FXCollections.observableArrayList(employees);
        employeeSalesTable.setItems(data);
        
        // Setup Bar Chart
        setupEmployeeChart(employees);
        logger.info("✅ Tải thống kê nhân viên: " + employees.size());
    }
    
    /**
     * Cấu hình bảng thống kê nhân viên
     */
    private void setupEmployeeTable() {
        TableColumn<Map<String, Object>, String> nameCol = new TableColumn<>("Tên nhân viên");
        nameCol.setCellValueFactory(cellData -> 
            new SimpleStringProperty((String)cellData.getValue().get("name")));
        nameCol.setPrefWidth(150);
        
        TableColumn<Map<String, Object>, String> invoicesCol = new TableColumn<>("Số hóa đơn");
        invoicesCol.setCellValueFactory(cellData -> 
            new SimpleStringProperty(cellData.getValue().get("invoices").toString()));
        
        TableColumn<Map<String, Object>, String> totalCol = new TableColumn<>("Tổng tiền");
        totalCol.setCellValueFactory(cellData -> 
            new SimpleStringProperty(String.format("%.0f ₫", cellData.getValue().get("total"))));
        
        employeeSalesTable.getColumns().clear();
        employeeSalesTable.getColumns().addAll(nameCol, invoicesCol, totalCol);
    }
    
    /**
     * Cấu hình bar chart nhân viên
     */
    private void setupEmployeeChart(List<Map<String, Object>> employees) {
        XYChart.Series<String, Number> series = new XYChart.Series<>();
        series.setName("Doanh số bán hàng");
        
        for (Map<String, Object> emp : employees) {
            String name = (String) emp.get("name");
            double total = (Double) emp.get("total");
            series.getData().add(new XYChart.Data<>(name, total));
        }
        
        employeeChart.getData().clear();
        employeeChart.getData().add(series);
        employeeChart.setTitle("Doanh số Bán hàng Của Nhân viên");
    }
    
    /**
     * Tải thống kê phương thức thanh toán
     */
    private void loadPaymentMethodStatistics() {
        setupPaymentMethodTable();
        List<Map<String, Object>> methods = statsDAO.getPaymentMethodStatistics();
        ObservableList<Map<String, Object>> data = FXCollections.observableArrayList(methods);
        paymentMethodTable.setItems(data);
        logger.info("✅ Tải thống kê phương thức thanh toán: " + methods.size());
    }
    
    /**
     * Cấu hình bảng phương thức thanh toán
     */
    private void setupPaymentMethodTable() {
        TableColumn<Map<String, Object>, String> methodCol = new TableColumn<>("Phương thức");
        methodCol.setCellValueFactory(cellData -> 
            new SimpleStringProperty((String)cellData.getValue().get("method")));
        methodCol.setPrefWidth(120);
        
        TableColumn<Map<String, Object>, String> countCol = new TableColumn<>("Số lần");
        countCol.setCellValueFactory(cellData -> 
            new SimpleStringProperty(cellData.getValue().get("count").toString()));
        
        TableColumn<Map<String, Object>, String> totalCol = new TableColumn<>("Tổng tiền");
        totalCol.setCellValueFactory(cellData -> 
            new SimpleStringProperty(String.format("%.0f ₫", cellData.getValue().get("total"))));
        
        paymentMethodTable.getColumns().clear();
        paymentMethodTable.getColumns().addAll(methodCol, countCol, totalCol);
    }
    
    /**
     * Làm mới dữ liệu
     */
    @FXML
    private void handleRefresh() {
        logger.info("🔄 Làm mới dữ liệu thống kê");
        loadTodayStatistics();
        loadMonthlyStatistics();
        loadCategoryStatistics();
        loadEmployeeSalesStatistics();
        loadPaymentMethodStatistics();
    }
    
    /**
     * Quay lại
     */
    @FXML
    private void handleBack() {
        logger.info("🔙 Quay lại Dashboard");
        SceneManager.switchScene(
            "/CoffeeShop/view/dashboard.fxml",
            "☕ Dashboard - Hệ thống quản lý quán cà phê",
            1200, 700
        );
    }
}

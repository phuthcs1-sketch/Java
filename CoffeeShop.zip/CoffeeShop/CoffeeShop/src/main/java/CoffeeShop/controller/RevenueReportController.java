package CoffeeShop.controller;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.beans.property.SimpleStringProperty;
import CoffeeShop.util.LoggerUtil;
import CoffeeShop.util.SceneManager;
import CoffeeShop.dao.RevenueReportDAO;
import java.time.LocalDate;
import java.util.logging.Logger;
import java.util.List;
import java.util.Map;

/**
 * Controller cho báo cáo doanh thu
 */
public class RevenueReportController {
    
    private static final Logger logger = LoggerUtil.getLogger(RevenueReportController.class.getName());
    
    @FXML private Label todayRevenueLabel;
    @FXML private Label monthRevenueLabel;
    @FXML private Label yearRevenueLabel;
    @FXML private TableView<Map<String, Object>> last7DaysTable;
    @FXML private TableView<Map<String, Object>> topProductsTable;
    @FXML private TableView<Map<String, Object>> shiftRevenueTable;
    
    @FXML private ComboBox<Integer> yearCombo;
    @FXML private ComboBox<Integer> monthCombo;
    @FXML private DatePicker datePicker;
    
    private RevenueReportDAO revenueDAO = new RevenueReportDAO();
    
    @FXML
    private void initialize() {
        logger.info("📊 Khởi tạo RevenueReportController");
        
        setupUI();
        loadTodayRevenue();
        loadMonthlyRevenue();
        loadYearlyRevenue();
        loadLast7Days();
        loadTopProducts();
        loadShiftRevenue();
        
        logger.info("✅ RevenueReportController sẵn sàng");
    }
    
    /**
     * Cấu hình giao diện
     */
    private void setupUI() {
        // Setup year combo
        ObservableList<Integer> years = FXCollections.observableArrayList();
        int currentYear = LocalDate.now().getYear();
        for (int i = currentYear - 5; i <= currentYear; i++) {
            years.add(i);
        }
        yearCombo.setItems(years);
        yearCombo.setValue(currentYear);
        
        // Setup month combo
        ObservableList<Integer> months = FXCollections.observableArrayList();
        for (int i = 1; i <= 12; i++) {
            months.add(i);
        }
        monthCombo.setItems(months);
        monthCombo.setValue(LocalDate.now().getMonthValue());
        
        // Setup datepicker
        datePicker.setValue(LocalDate.now());
        
        // Setup event listeners
        yearCombo.setOnAction(e -> loadMonthlyRevenue());
        monthCombo.setOnAction(e -> loadMonthlyRevenue());
        datePicker.setOnAction(e -> loadDailyRevenue());
    }
    
    /**
     * Tải doanh thu hôm nay
     */
    private void loadTodayRevenue() {
        double revenue = revenueDAO.getTodayRevenue();
        todayRevenueLabel.setText(String.format("%.0f ₫", revenue));
        logger.info("✅ Doanh thu hôm nay: " + revenue);
    }
    
    /**
     * Tải doanh thu ngày được chọn
     */
    private void loadDailyRevenue() {
        LocalDate date = datePicker.getValue();
        if (date != null) {
            double revenue = revenueDAO.getRevenueByDate(date);
            todayRevenueLabel.setText(String.format("%.0f ₫", revenue));
            logger.info("✅ Doanh thu ngày " + date + ": " + revenue);
        }
    }
    
    /**
     * Tải doanh thu theo tháng
     */
    private void loadMonthlyRevenue() {
        int year = yearCombo.getValue();
        int month = monthCombo.getValue();
        double revenue = revenueDAO.getRevenueByMonth(year, month);
        monthRevenueLabel.setText(String.format("%.0f ₫", revenue));
        logger.info("✅ Doanh thu tháng " + month + "/" + year + ": " + revenue);
    }
    
    /**
     * Tải doanh thu năm
     */
    private void loadYearlyRevenue() {
        int year = yearCombo.getValue();
        double revenue = revenueDAO.getRevenueByYear(year);
        yearRevenueLabel.setText(String.format("%.0f ₫", revenue));
        logger.info("✅ Doanh thu năm " + year + ": " + revenue);
    }
    
    /**
     * Tải doanh thu 7 ngày gần đây
     */
    private void loadLast7Days() {
        setupLast7DaysTable();
        List<Map<String, Object>> revenues = revenueDAO.getLast7DaysRevenue();
        ObservableList<Map<String, Object>> data = FXCollections.observableArrayList(revenues);
        last7DaysTable.setItems(data);
        logger.info("✅ Tải doanh thu 7 ngày");
    }
    
    /**
     * Cấu hình bảng 7 ngày gần đây
     */
    private void setupLast7DaysTable() {
        TableColumn<Map<String, Object>, String> dateCol = new TableColumn<>("Ngày");
        dateCol.setCellValueFactory(cellData -> 
            new SimpleStringProperty(cellData.getValue().get("date").toString()));
        
        TableColumn<Map<String, Object>, String> revenueCol = new TableColumn<>("Doanh thu");
        revenueCol.setCellValueFactory(cellData -> 
            new SimpleStringProperty(String.format("%.0f ₫", cellData.getValue().get("revenue"))));
        
        TableColumn<Map<String, Object>, String> ordersCol = new TableColumn<>("Số hóa đơn");
        ordersCol.setCellValueFactory(cellData -> 
            new SimpleStringProperty(cellData.getValue().get("orders").toString()));
        
        last7DaysTable.getColumns().clear();
        last7DaysTable.getColumns().addAll(dateCol, revenueCol, ordersCol);
    }
    
    /**
     * Tải top 10 sản phẩm bán chạy
     */
    private void loadTopProducts() {
        setupTopProductsTable();
        List<Map<String, Object>> products = revenueDAO.getTopSellingProducts();
        ObservableList<Map<String, Object>> data = FXCollections.observableArrayList(products);
        topProductsTable.setItems(data);
        logger.info("✅ Tải top 10 sản phẩm bán chạy");
    }
    
    /**
     * Cấu hình bảng top products
     */
    private void setupTopProductsTable() {
        TableColumn<Map<String, Object>, String> nameCol = new TableColumn<>("Sản phẩm");
        nameCol.setCellValueFactory(cellData -> 
            new SimpleStringProperty((String)cellData.getValue().get("name")));
        nameCol.setPrefWidth(150);
        
        TableColumn<Map<String, Object>, String> categoryCol = new TableColumn<>("Danh mục");
        categoryCol.setCellValueFactory(cellData -> 
            new SimpleStringProperty((String)cellData.getValue().get("category")));
        
        TableColumn<Map<String, Object>, String> qtyCol = new TableColumn<>("Số lượng");
        qtyCol.setCellValueFactory(cellData -> 
            new SimpleStringProperty(cellData.getValue().get("quantity").toString()));
        
        TableColumn<Map<String, Object>, String> totalCol = new TableColumn<>("Tổng tiền");
        totalCol.setCellValueFactory(cellData -> 
            new SimpleStringProperty(String.format("%.0f ₫", cellData.getValue().get("total"))));
        
        topProductsTable.getColumns().clear();
        topProductsTable.getColumns().addAll(nameCol, categoryCol, qtyCol, totalCol);
    }
    
    /**
     * Tải doanh thu theo ca làm
     */
    private void loadShiftRevenue() {
        setupShiftRevenueTable();
        List<Map<String, Object>> shifts = revenueDAO.getRevenueByShift();
        ObservableList<Map<String, Object>> data = FXCollections.observableArrayList(shifts);
        shiftRevenueTable.setItems(data);
        logger.info("✅ Tải doanh thu theo ca làm");
    }
    
    /**
     * Cấu hình bảng doanh thu ca làm
     */
    private void setupShiftRevenueTable() {
        TableColumn<Map<String, Object>, String> shiftCol = new TableColumn<>("Ca làm");
        shiftCol.setCellValueFactory(cellData -> 
            new SimpleStringProperty(cellData.getValue().get("startTime") + " - " + cellData.getValue().get("endTime")));
        
        TableColumn<Map<String, Object>, String> invoicesCol = new TableColumn<>("Số hóa đơn");
        invoicesCol.setCellValueFactory(cellData -> 
            new SimpleStringProperty(cellData.getValue().get("invoices").toString()));
        
        TableColumn<Map<String, Object>, String> totalCol = new TableColumn<>("Tổng doanh thu");
        totalCol.setCellValueFactory(cellData -> 
            new SimpleStringProperty(String.format("%.0f ₫", cellData.getValue().get("total"))));
        
        shiftRevenueTable.getColumns().clear();
        shiftRevenueTable.getColumns().addAll(shiftCol, invoicesCol, totalCol);
    }
    
    /**
     * Làm mới dữ liệu
     */
    @FXML
    private void handleRefresh() {
        logger.info("🔄 Làm mới dữ liệu báo cáo");
        loadTodayRevenue();
        loadMonthlyRevenue();
        loadYearlyRevenue();
        loadLast7Days();
        loadTopProducts();
        loadShiftRevenue();
    }
    
    /**
     * Quay lại
     */
    @FXML
    private void handleBack() {
        logger.info("🔙 Quay lại Dashboard");
        SceneManager.switchScene(
            "/CoffeeShop/view/dashboard.fxml",
            "☕ Dashboard - Hệ thống quản lý quán cà phê",
            1200, 700
        );
    }
}

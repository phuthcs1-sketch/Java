package CoffeeShop.controller;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import CoffeeShop.util.LoggerUtil;
import CoffeeShop.util.SceneManager;
import CoffeeShop.dao.ProductDAO;
import CoffeeShop.dao.OrderDAO;
import CoffeeShop.dao.TableDAO;
import CoffeeShop.dao.CategoryDAO;
import CoffeeShop.Product;
import CoffeeShop.CartItem;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;
import java.util.stream.Collectors;

public class POSController {

    private static final Logger logger = LoggerUtil.getLogger(POSController.class.getName());

    @FXML private ComboBox<String> tableCombo;
    @FXML private TextField productSearchField;
    @FXML private javafx.scene.layout.GridPane productsGridPane;
    @FXML private HBox categoryButtonsHBox;
    @FXML private TableView<CartItem> cartTable;
    @FXML private Label totalLabel;
    @FXML private Spinner<Integer> discountSpinner;
    @FXML private TextField paymentField;
    @FXML private Label changeLabel;

    private double cartTotal = 0;
    private ObservableList<CartItem> cartItems = FXCollections.observableArrayList();
    private Map<Integer, CartItem> cartMap = new HashMap<>();
    private Map<String, Integer> tableIdMap = new HashMap<>();

    private List<Product> allProductsList = new ArrayList<>();
    private String selectedCategory = null; // null = hiển thị tất cả
    private Button activeCategoryBtn = null;

    @FXML
    private void initialize() {
        logger.info("🛒 Khởi tạo POSController");
        setupCartTable();
        loadTables();
        loadProducts();
        loadCategoryButtons();
        setupEventListeners();
        logger.info("✅ POSController sẵn sàng");
    }

    // ─── Cart Table ───────────────────────────────────────────────────────────

    private void setupCartTable() {
        cartTable.setItems(cartItems);

        TableColumn<CartItem, String> nameCol = new TableColumn<>("Sản phẩm");
        nameCol.setCellValueFactory(c ->
            new javafx.beans.property.SimpleStringProperty(c.getValue().getProductName()));
        nameCol.setPrefWidth(120);

        TableColumn<CartItem, String> priceCol = new TableColumn<>("Giá");
        priceCol.setCellValueFactory(c ->
            new javafx.beans.property.SimpleStringProperty(String.format("%.0f ₫", c.getValue().getPrice())));
        priceCol.setPrefWidth(70);

        TableColumn<CartItem, Integer> qtyCol = new TableColumn<>("SL");
        qtyCol.setCellValueFactory(c ->
            new javafx.beans.property.SimpleObjectProperty<>(c.getValue().getQuantity()));
        qtyCol.setPrefWidth(40);

        TableColumn<CartItem, String> totalCol = new TableColumn<>("Thành tiền");
        totalCol.setCellValueFactory(c ->
            new javafx.beans.property.SimpleStringProperty(String.format("%.0f ₫", c.getValue().getTotal())));
        totalCol.setPrefWidth(80);

        TableColumn<CartItem, Void> delCol = new TableColumn<>("");
        delCol.setCellFactory(param -> new TableCell<CartItem, Void>() {
            private final Button btn = new Button("✕");
            {
                btn.setStyle("-fx-font-size: 12px; -fx-padding: 4px 8px; -fx-text-fill: #e74c3c; -fx-background-color: transparent;");
                btn.setOnAction(e -> removeFromCart(getTableView().getItems().get(getIndex()).getProductId()));
            }
            @Override protected void updateItem(Void item, boolean empty) {
                super.updateItem(item, empty);
                setGraphic(empty ? null : btn);
            }
        });
        delCol.setPrefWidth(35);

        cartTable.getColumns().addAll(nameCol, priceCol, qtyCol, totalCol, delCol);
    }

    // ─── Tables ───────────────────────────────────────────────────────────────

    private void loadTables() {
        tableIdMap.clear();
        tableCombo.getItems().clear();

        for (Map<String, Object> table : new TableDAO().getAllTables()) {
            String name = (String) table.get("name");
            tableCombo.getItems().add(name);
            tableIdMap.put(name, (Integer) table.get("id"));
        }
        tableCombo.getItems().add("Mang về");

        if (!tableCombo.getItems().isEmpty())
            tableCombo.setValue(tableCombo.getItems().get(0));
    }

    // ─── Products ────────────────────────────────────────────────────────────

    private void loadProducts() {
        allProductsList = new ProductDAO().getAllProducts();
        displayProducts(allProductsList);
        logger.info("✅ Tải " + allProductsList.size() + " sản phẩm");
    }

    private void displayProducts(List<Product> products) {
        productsGridPane.getChildren().clear();
        int col = 0, row = 0;
        for (Product p : products) {
            productsGridPane.add(createProductButton(p), col, row);
            col++;
            if (col >= 4) { col = 0; row++; }
        }
    }

    private Button createProductButton(Product product) {
        String bgColor = getCategoryColor(product.getCategory());
        Button btn = new Button(product.getName() + "\n" + String.format("%.0f ₫", product.getPrice()));
        btn.setStyle(
            "-fx-min-width: 130px; -fx-min-height: 85px;" +
            "-fx-font-size: 12px; -fx-font-weight: bold;" +
            "-fx-padding: 10px; -fx-text-alignment: center;" +
            "-fx-background-color: " + bgColor + ";" +
            "-fx-text-fill: white;" +
            "-fx-background-radius: 8px;" +
            "-fx-cursor: hand;" +
            "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.18), 4, 0, 0, 2);"
        );
        btn.setWrapText(true);

        // hover effect
        String hoverColor = darken(bgColor);
        btn.setOnMouseEntered(e -> btn.setStyle(btn.getStyle().replace(bgColor, hoverColor)));
        btn.setOnMouseExited(e -> btn.setStyle(btn.getStyle().replace(hoverColor, bgColor)));

        btn.setOnAction(e -> addToCart(product.getId(), product.getName(), product.getPrice()));
        return btn;
    }

    /** Màu nền theo danh mục */
    private String getCategoryColor(String category) {
        if (category == null) return "#546e7a";
        switch (category) {
            case "Ca phe":   return "#5d4037"; // nâu cà phê
            case "Tra":      return "#2e7d32"; // xanh lá trà
            case "Sinh to":  return "#6a1b9a"; // tím sinh tố
            case "Nuoc ngot":return "#1565c0"; // xanh nước ngọt
            case "Do an nhe":return "#e65100"; // cam đồ ăn
            default:         return "#37474f"; // xám xanh mặc định
        }
    }

    /** Làm tối màu hex khoảng 15% cho hover */
    private String darken(String hex) {
        try {
            int r = Integer.parseInt(hex.substring(1, 3), 16);
            int g = Integer.parseInt(hex.substring(3, 5), 16);
            int b = Integer.parseInt(hex.substring(5, 7), 16);
            r = Math.max(0, (int)(r * 0.82));
            g = Math.max(0, (int)(g * 0.82));
            b = Math.max(0, (int)(b * 0.82));
            return String.format("#%02x%02x%02x", r, g, b);
        } catch (Exception e) {
            return hex;
        }
    }

    // ─── Category Buttons ────────────────────────────────────────────────────

    private void loadCategoryButtons() {
        categoryButtonsHBox.getChildren().clear();

        // "Tất cả" button
        Button allBtn = makeCategoryButton("🔹 Tất cả", "#6f4e37", null);
        categoryButtonsHBox.getChildren().add(allBtn);
        setActiveCategory(allBtn, null); // mặc định chọn "Tất cả"

        // Buttons từ DB
        for (String catName : new CategoryDAO().getCategoryNames()) {
            String color = getCategoryColor(catName);
            Button btn = makeCategoryButton(catName, color, catName);
            categoryButtonsHBox.getChildren().add(btn);
        }
    }

    private Button makeCategoryButton(String label, String color, String category) {
        Button btn = new Button(label);
        btn.setUserData(color); // lưu màu để khôi phục khi bỏ chọn
        btn.setStyle(buildCategoryBtnStyle(color, false));
        btn.setOnAction(e -> setActiveCategory(btn, category));
        return btn;
    }

    private void setActiveCategory(Button btn, String category) {
        // Bỏ highlight nút cũ
        if (activeCategoryBtn != null) {
            String prevColor = (String) activeCategoryBtn.getUserData();
            activeCategoryBtn.setStyle(buildCategoryBtnStyle(prevColor != null ? prevColor : "#6f4e37", false));
        }

        // Highlight nút mới
        selectedCategory = category;
        activeCategoryBtn = btn;
        String color = (String) btn.getUserData();
        btn.setStyle(buildCategoryBtnStyle(color != null ? color : "#6f4e37", true));

        filterAndDisplayProducts();
    }

    private String buildCategoryBtnStyle(String color, boolean active) {
        return "-fx-padding: 7px 14px;" +
               "-fx-font-size: 12px;" +
               "-fx-font-weight: bold;" +
               "-fx-background-color: " + (active ? color : color + "cc") + ";" +
               "-fx-text-fill: white;" +
               "-fx-background-radius: 20px;" +
               "-fx-cursor: hand;" +
               (active ? "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.3), 6, 0, 0, 2);" +
                         "-fx-border-color: white; -fx-border-radius: 20px; -fx-border-width: 2px;" : "");
    }

    // ─── Filtering ───────────────────────────────────────────────────────────

    private void filterAndDisplayProducts() {
        String searchText = productSearchField.getText().trim().toLowerCase();

        List<Product> filtered = allProductsList.stream()
            .filter(p -> selectedCategory == null || selectedCategory.equals(p.getCategory()))
            .filter(p -> searchText.isEmpty() || p.getName().toLowerCase().contains(searchText))
            .collect(Collectors.toList());

        displayProducts(filtered);
        logger.info("🔍 Hiển thị " + filtered.size() + " sản phẩm (danh mục: " +
                    (selectedCategory == null ? "Tất cả" : selectedCategory) + ")");
    }

    // ─── Event Listeners ─────────────────────────────────────────────────────

    private void setupEventListeners() {
        paymentField.textProperty().addListener((obs, old, nv) -> calculateChange());
        discountSpinner.valueProperty().addListener((obs, old, nv) -> updateTotalPrice());
        productSearchField.textProperty().addListener((obs, old, nv) -> filterAndDisplayProducts());
    }

    // ─── Cart Logic ──────────────────────────────────────────────────────────

    private void addToCart(int productId, String productName, double price) {
        if (cartMap.containsKey(productId)) {
            CartItem item = cartMap.get(productId);
            item.setQuantity(item.getQuantity() + 1);
            cartTable.refresh();
        } else {
            CartItem item = new CartItem(productId, productName, price, 1);
            cartMap.put(productId, item);
            cartItems.add(item);
        }
        cartTotal += price;
        updateTotalPrice();
    }

    private void removeFromCart(int productId) {
        if (cartMap.containsKey(productId)) {
            CartItem item = cartMap.get(productId);
            cartTotal -= item.getTotal();
            cartItems.remove(item);
            cartMap.remove(productId);
            updateTotalPrice();
        }
    }

    private void updateTotalPrice() {
        int discountPercent = discountSpinner.getValue();
        double finalTotal = cartTotal - (cartTotal * discountPercent / 100.0);
        totalLabel.setText(String.format("%.0f ₫", finalTotal));
        calculateChange();
    }

    private void calculateChange() {
        try {
            double total = Double.parseDouble(totalLabel.getText().replace(" ₫", ""));
            double payment = Double.parseDouble(paymentField.getText());
            double change = payment - total;
            if (change >= 0) {
                changeLabel.setText(String.format("%.0f ₫", change));
                changeLabel.setStyle("-fx-text-fill: #27ae60;");
            } else {
                changeLabel.setText(String.format("Còn thiếu %.0f ₫", Math.abs(change)));
                changeLabel.setStyle("-fx-text-fill: #e74c3c;");
            }
        } catch (NumberFormatException e) {
            changeLabel.setText("0 ₫");
            changeLabel.setStyle("-fx-text-fill: #666;");
        }
    }

    // ─── FXML Actions ────────────────────────────────────────────────────────

    @FXML
    private void handleClearCart() {
        cartTotal = 0;
        cartItems.clear();
        cartMap.clear();
        updateTotalPrice();
        changeLabel.setText("0 ₫");
        paymentField.clear();
    }

    @FXML
    private void handleCheckout() {
        if (cartTotal <= 0) { showAlert("Giỏ hàng trống", "Vui lòng thêm sản phẩm vào giỏ hàng"); return; }
        if (paymentField.getText().isEmpty()) { showAlert("Chưa nhập tiền", "Vui lòng nhập số tiền khách trả"); return; }

        try {
            double total   = Double.parseDouble(totalLabel.getText().replace(" ₫", ""));
            double payment = Double.parseDouble(paymentField.getText());

            if (payment < total) {
                showAlert("Tiền không đủ", "Khách cần trả thêm " + String.format("%.0f ₫", total - payment));
                return;
            }

            int employeeId = LoginController.getCurrentUserId();
            Integer tableId = tableIdMap.get(tableCombo.getValue()); // null nếu "Mang về"

            OrderDAO orderDAO = new OrderDAO();
            int orderId = orderDAO.createOrder(employeeId, null, tableId, total);

            for (CartItem item : cartItems)
                orderDAO.addOrderDetail(orderId, item.getProductId(), item.getQuantity(), item.getPrice());

            showAlert("✅ Thanh toán thành công", "Hóa đơn #" + orderId + " đã được lưu");
            handleClearCart();

        } catch (NumberFormatException e) {
            showAlert("Lỗi", "Số tiền không hợp lệ");
        } catch (Exception e) {
            logger.severe("❌ Lỗi lưu hóa đơn: " + e.getMessage());
            showAlert("Lỗi", "Không thể lưu hóa đơn: " + e.getMessage());
        }
    }

    @FXML
    private void handlePrint() {
        showAlert("In hóa đơn", "Chức năng in hóa đơn (chưa phát triển)");
    }

    @FXML
    private void handleBack() {
        if (cartTotal > 0) {
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Xác nhận");
            alert.setHeaderText("Giỏ hàng còn sản phẩm");
            alert.setContentText("Bạn có chắc muốn quay lại mà không thanh toán?");
            alert.showAndWait().ifPresent(r -> { if (r == ButtonType.OK) goBackToDashboard(); });
        } else {
            goBackToDashboard();
        }
    }

    private void goBackToDashboard() {
        SceneManager.switchScene("/CoffeeShop/view/dashboard.fxml",
            "☕ Dashboard - Hệ thống quản lý quán cà phê", 1200, 700);
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(title);
        alert.setContentText(message);
        alert.showAndWait();
    }
}

package CoffeeShop.controller;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import CoffeeShop.util.LoggerUtil;
import CoffeeShop.util.SceneManager;
import CoffeeShop.dao.SettingsDAO;
import java.util.logging.Logger;

/**
 * Controller cho cài đặt hệ thống
 */
public class SettingsController {
    
    private static final Logger logger = LoggerUtil.getLogger(SettingsController.class.getName());
    
    @FXML private TextField shopNameField;
    @FXML private TextField shopAddressField;
    @FXML private TextField shopPhoneField;
    @FXML private TextField shopEmailField;
    @FXML private Spinner<Double> defaultDiscountSpinner;
    @FXML private Spinner<Integer> invoiceRetentionSpinner;
    @FXML private CheckBox debugModeCheckBox;
    @FXML private Label appVersionLabel;
    @FXML private Label systemStatusLabel;
    
    private SettingsDAO settingsDAO = new SettingsDAO();
    
    @FXML
    private void initialize() {
        logger.info("⚙️ Khởi tạo SettingsController");
        
        setupUI();
        loadSettings();
        
        logger.info("✅ SettingsController sẵn sàng");
    }
    
    /**
     * Cấu hình giao diện
     */
    private void setupUI() {
        // Setup spinners
        defaultDiscountSpinner.setValueFactory(new SpinnerValueFactory.DoubleSpinnerValueFactory(0, 100, 0, 0.5));
        invoiceRetentionSpinner.setValueFactory(new SpinnerValueFactory.IntegerSpinnerValueFactory(30, 3650, 365, 30));
        
        // Setup system info
        String version = settingsDAO.getAppVersion();
        appVersionLabel.setText("v" + (version != null ? version : "1.0.0"));
        systemStatusLabel.setText("✅ Hệ thống hoạt động bình thường");
    }
    
    /**
     * Tải cài đặt
     */
    private void loadSettings() {
        logger.info("📥 Tải cài đặt hệ thống...");
        
        String shopName = settingsDAO.getShopName();
        String shopAddress = settingsDAO.getShopAddress();
        String shopPhone = settingsDAO.getShopPhone();
        String shopEmail = settingsDAO.getShopEmail();
        
        shopNameField.setText(shopName != null ? shopName : "");
        shopAddressField.setText(shopAddress != null ? shopAddress : "");
        shopPhoneField.setText(shopPhone != null ? shopPhone : "");
        shopEmailField.setText(shopEmail != null ? shopEmail : "");
        
        defaultDiscountSpinner.getValueFactory().setValue(settingsDAO.getDefaultDiscount());
        invoiceRetentionSpinner.getValueFactory().setValue(settingsDAO.getInvoiceRetentionDays());
        debugModeCheckBox.setSelected(settingsDAO.isDebugMode());
        
        logger.info("✅ Tải cài đặt thành công");
    }
    
    /**
     * Lưu cài đặt
     */
    @FXML
    private void handleSaveSettings() {
        logger.info("💾 Lưu cài đặt...");
        
        try {
            settingsDAO.updateSetting("SHOP_NAME", shopNameField.getText());
            settingsDAO.updateSetting("SHOP_ADDRESS", shopAddressField.getText());
            settingsDAO.updateSetting("SHOP_PHONE", shopPhoneField.getText());
            settingsDAO.updateSetting("SHOP_EMAIL", shopEmailField.getText());
            settingsDAO.updateSetting("DEFAULT_DISCOUNT", String.valueOf(defaultDiscountSpinner.getValue()));
            settingsDAO.updateSetting("INVOICE_RETENTION_DAYS", String.valueOf(invoiceRetentionSpinner.getValue()));
            settingsDAO.updateSetting("DEBUG_MODE", String.valueOf(debugModeCheckBox.isSelected()));
            
            showAlert("Thành công", "✅ Lưu cài đặt thành công!");
            logger.info("✅ Lưu cài đặt thành công");
        } catch (Exception e) {
            logger.severe("❌ Lỗi lưu cài đặt: " + e.getMessage());
            showAlert("Lỗi", "❌ Lỗi khi lưu cài đặt: " + e.getMessage());
        }
    }
    
    /**
     * Reset cài đặt mặc định
     */
    @FXML
    private void handleResetSettings() {
        logger.info("🔄 Reset cài đặt...");
        
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Xác nhận");
        alert.setHeaderText("Bạn có chắc muốn reset cài đặt về mặc định?");
        alert.setContentText("Hành động này không thể hoàn tác!");
        
        alert.showAndWait().ifPresent(response -> {
            if (response == ButtonType.OK) {
                // Reset to defaults
                shopNameField.setText("");
                shopAddressField.setText("");
                shopPhoneField.setText("");
                shopEmailField.setText("");
                defaultDiscountSpinner.getValueFactory().setValue(0.0);
                invoiceRetentionSpinner.getValueFactory().setValue(365);
                debugModeCheckBox.setSelected(false);
                
                handleSaveSettings();
                logger.info("✅ Reset cài đặt thành công");
            }
        });
    }
    
    /**
     * Xóa cache
     */
    @FXML
    private void handleClearCache() {
        logger.info("🧹 Xóa cache...");
        
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Xác nhận");
        alert.setHeaderText("Xóa cache ứng dụng?");
        alert.setContentText("Điều này sẽ xóa dữ liệu tạm thời nhưng không ảnh hưởng đến cơ sở dữ liệu.");
        
        alert.showAndWait().ifPresent(response -> {
            if (response == ButtonType.OK) {
                if (settingsDAO.clearCache()) {
                    showAlert("Thành công", "✅ Xóa cache thành công!");
                    logger.info("✅ Xóa cache thành công");
                } else {
                    showAlert("Lỗi", "❌ Lỗi khi xóa cache!");
                }
            }
        });
    }
    
    /**
     * Kiểm tra kết nối cơ sở dữ liệu
     */
    @FXML
    private void handleCheckConnection() {
        logger.info("🔗 Kiểm tra kết nối...");
        
        try {
            // Thực hiện một query đơn giản để kiểm tra
            CoffeeShop.DBConnection.getConnection();
            showAlert("Thành công", "✅ Kết nối cơ sở dữ liệu thành công!");
            systemStatusLabel.setText("✅ Hệ thống hoạt động bình thường");
            logger.info("✅ Kết nối DB OK");
        } catch (Exception e) {
            showAlert("Lỗi", "❌ Không thể kết nối cơ sở dữ liệu!\n" + e.getMessage());
            systemStatusLabel.setText("❌ Lỗi kết nối cơ sở dữ liệu");
            logger.severe("❌ Lỗi kết nối DB: " + e.getMessage());
        }
    }
    
    /**
     * Xem logs
     */
    @FXML
    private void handleViewLogs() {
        logger.info("📋 Xem logs...");
        
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Logs");
        alert.setHeaderText("File logs");
        alert.setContentText("Logs được lưu tại: logs/coffeeshop.log\n\nVui lòng mở file này bằng text editor để xem chi tiết.");
        alert.showAndWait();
    }
    
    /**
     * Thông tin ứng dụng
     */
    @FXML
    private void handleAboutApp() {
        logger.info("ℹ️ Xem thông tin ứng dụng...");
        
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Về ứng dụng");
        alert.setHeaderText("☕ Coffee Shop Management System");
        alert.setContentText("Phiên bản: " + appVersionLabel.getText() + "\n" +
                           "Năm: 2024-2026\n\n" +
                           "Hệ thống quản lý quán cà phê toàn diện\n" +
                           "Bao gồm: Bán hàng POS, Quản lý sản phẩm,\n" +
                           "Quản lý nhân viên, Thống kê & Báo cáo\n\n" +
                           "Phát triển bằng JavaFX + SQL Server");
        alert.showAndWait();
    }
    
    /**
     * Làm mới dữ liệu
     */
    @FXML
    private void handleRefresh() {
        logger.info("🔄 Làm mới cài đặt");
        loadSettings();
    }
    
    /**
     * Quay lại
     */
    @FXML
    private void handleBack() {
        logger.info("🔙 Quay lại Dashboard");
        SceneManager.switchScene(
            "/CoffeeShop/view/dashboard.fxml",
            "☕ Dashboard - Hệ thống quản lý quán cà phê",
            1200, 700
        );
    }
    
    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(title);
        alert.setContentText(message);
        alert.showAndWait();
    }
}

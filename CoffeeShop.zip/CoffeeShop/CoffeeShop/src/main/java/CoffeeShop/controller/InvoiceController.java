package CoffeeShop.controller;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.beans.property.SimpleStringProperty;
import CoffeeShop.util.LoggerUtil;
import CoffeeShop.util.SceneManager;
import CoffeeShop.dao.OrderDAO;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

public class InvoiceController {

    private static final Logger logger = LoggerUtil.getLogger(InvoiceController.class.getName());

    @FXML private DatePicker fromDatePicker;
    @FXML private DatePicker toDatePicker;
    @FXML private Label summaryLabel;
    @FXML private TableView<Map<String, Object>> invoicesTable;
    @FXML private TableView<Map<String, Object>> invoiceDetailTable;
    @FXML private Label selectedInvoiceLabel;
    @FXML private Label detailTotalLabel;

    private final OrderDAO orderDAO = new OrderDAO();
    private ObservableList<Map<String, Object>> invoiceData = FXCollections.observableArrayList();

    @FXML
    private void initialize() {
        logger.info("🧾 Khởi tạo InvoiceController");
        toDatePicker.setValue(LocalDate.now());
        fromDatePicker.setValue(LocalDate.now().minusMonths(1));
        setupInvoiceTable();
        setupDetailTable();
        loadInvoices(fromDatePicker.getValue(), toDatePicker.getValue());
    }

    // ─── Table setup ─────────────────────────────────────────────────────────

    private void setupInvoiceTable() {
        TableColumn<Map<String, Object>, String> idCol = col("Mã HD", "id", 65);
        TableColumn<Map<String, Object>, String> dateCol = col("Ngày lập", "date", 150);
        TableColumn<Map<String, Object>, String> empCol = col("Nhân viên", "employee", 130);
        TableColumn<Map<String, Object>, String> custCol = col("Khách hàng", "customer", 130);
        TableColumn<Map<String, Object>, String> tableCol = col("Bàn", "table", 90);
        TableColumn<Map<String, Object>, String> shiftCol = col("Ca làm", "shift", 90);

        TableColumn<Map<String, Object>, String> totalCol = new TableColumn<>("Tổng tiền");
        totalCol.setCellValueFactory(c ->
            new SimpleStringProperty(String.format("%.0f ₫", c.getValue().get("total"))));
        totalCol.setPrefWidth(110);
        totalCol.setStyle("-fx-alignment: CENTER-RIGHT;");

        invoicesTable.getColumns().add(idCol);
        invoicesTable.getColumns().add(dateCol);
        invoicesTable.getColumns().add(empCol);
        invoicesTable.getColumns().add(custCol);
        invoicesTable.getColumns().add(tableCol);
        invoicesTable.getColumns().add(shiftCol);
        invoicesTable.getColumns().add(totalCol);
        invoicesTable.setItems(invoiceData);

        // Load chi tiết khi chọn hóa đơn
        invoicesTable.getSelectionModel().selectedItemProperty().addListener(
            (obs, old, selected) -> {
                if (selected != null) loadInvoiceDetail(selected);
            }
        );
    }

    private void setupDetailTable() {
        TableColumn<Map<String, Object>, String> nameCol = new TableColumn<>("Sản phẩm");
        nameCol.setCellValueFactory(c ->
            new SimpleStringProperty((String) c.getValue().get("productName")));
        nameCol.setPrefWidth(200);

        TableColumn<Map<String, Object>, String> qtyCol = new TableColumn<>("Số lượng");
        qtyCol.setCellValueFactory(c ->
            new SimpleStringProperty(String.valueOf(c.getValue().get("quantity"))));
        qtyCol.setPrefWidth(90);
        qtyCol.setStyle("-fx-alignment: CENTER;");

        TableColumn<Map<String, Object>, String> priceCol = new TableColumn<>("Đơn giá");
        priceCol.setCellValueFactory(c ->
            new SimpleStringProperty(String.format("%.0f ₫", c.getValue().get("price"))));
        priceCol.setPrefWidth(110);
        priceCol.setStyle("-fx-alignment: CENTER-RIGHT;");

        TableColumn<Map<String, Object>, String> subtotalCol = new TableColumn<>("Thành tiền");
        subtotalCol.setCellValueFactory(c ->
            new SimpleStringProperty(String.format("%.0f ₫", c.getValue().get("total"))));
        subtotalCol.setPrefWidth(120);
        subtotalCol.setStyle("-fx-alignment: CENTER-RIGHT;");

        invoiceDetailTable.getColumns().add(nameCol);
        invoiceDetailTable.getColumns().add(qtyCol);
        invoiceDetailTable.getColumns().add(priceCol);
        invoiceDetailTable.getColumns().add(subtotalCol);
    }

    // ─── Data loading ─────────────────────────────────────────────────────────

    private void loadInvoices(LocalDate from, LocalDate to) {
        List<Map<String, Object>> list = orderDAO.getAllInvoicesWithNames(from, to);
        invoiceData.setAll(list);

        double totalRevenue = list.stream()
            .mapToDouble(m -> (Double) m.get("total"))
            .sum();
        summaryLabel.setText(String.format("%d hóa đơn  |  Tổng: %.0f ₫", list.size(), totalRevenue));

        // Reset detail panel
        invoiceDetailTable.getItems().clear();
        selectedInvoiceLabel.setText("(chọn hóa đơn để xem chi tiết)");
        detailTotalLabel.setText("");

        logger.info("✅ Tải " + list.size() + " hóa đơn");
    }

    private void loadInvoiceDetail(Map<String, Object> invoice) {
        int invoiceId = (Integer) invoice.get("id");
        List<Map<String, Object>> details = orderDAO.getOrderDetails(invoiceId);

        invoiceDetailTable.setItems(FXCollections.observableArrayList(details));

        selectedInvoiceLabel.setText("Hóa đơn #" + invoiceId +
            "  |  " + invoice.get("date") +
            "  |  KH: " + invoice.get("customer") +
            "  |  " + invoice.get("table"));

        detailTotalLabel.setText(String.format("Tổng: %.0f ₫", invoice.get("total")));
    }

    // ─── FXML handlers ────────────────────────────────────────────────────────

    @FXML
    private void handleSearch() {
        LocalDate from = fromDatePicker.getValue();
        LocalDate to   = toDatePicker.getValue();
        if (from != null && to != null && from.isAfter(to)) {
            showAlert("Lỗi", "Ngày bắt đầu phải trước ngày kết thúc!");
            return;
        }
        loadInvoices(from, to);
    }

    @FXML
    private void handleLoadAll() {
        fromDatePicker.setValue(null);
        toDatePicker.setValue(null);
        loadInvoices(null, null);
    }

    @FXML
    private void handleBack() {
        SceneManager.switchScene(
            "/CoffeeShop/view/dashboard.fxml",
            "☕ Dashboard - Hệ thống quản lý quán cà phê",
            1200, 700
        );
    }

    // ─── Helpers ──────────────────────────────────────────────────────────────

    /** Tạo cột chuỗi đơn giản từ key trong Map */
    private TableColumn<Map<String, Object>, String> col(String title, String key, double width) {
        TableColumn<Map<String, Object>, String> c = new TableColumn<>(title);
        c.setCellValueFactory(cell -> {
            Object v = cell.getValue().get(key);
            return new SimpleStringProperty(v != null ? v.toString() : "");
        });
        c.setPrefWidth(width);
        return c;
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle(title);
        alert.setHeaderText(title);
        alert.setContentText(message);
        alert.showAndWait();
    }
}

package CoffeeShop.controller;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.beans.property.SimpleStringProperty;
import CoffeeShop.util.LoggerUtil;
import CoffeeShop.util.SceneManager;
import CoffeeShop.dao.AttendanceDAO;
import CoffeeShop.dao.EmployeeDAO;
import java.time.LocalDate;
import java.util.logging.Logger;
import java.util.List;
import java.util.Map;

/**
 * Controller cho chấm công nhân viên
 */
public class AttendanceController {
    
    private static final Logger logger = LoggerUtil.getLogger(AttendanceController.class.getName());
    
    @FXML private DatePicker attendanceDatePicker;
    @FXML private ComboBox<Map<String, Object>> employeeCombo;
    @FXML private TableView<Map<String, Object>> attendanceTable;
    @FXML private TableView<Map<String, Object>> monthlyAttendanceTable;
    @FXML private TableView<Map<String, Object>> absenteeismTable;
    @FXML private Label totalWorkDaysLabel;
    
    private AttendanceDAO attendanceDAO = new AttendanceDAO();
    private EmployeeDAO employeeDAO = new EmployeeDAO();
    
    @FXML
    private void initialize() {
        logger.info("⏰ Khởi tạo AttendanceController");
        
        setupUI();
        loadAttendanceByDate();
        loadAbsenteeismStatistics();
        
        logger.info("✅ AttendanceController sẵn sàng");
    }
    
    /**
     * Cấu hình giao diện
     */
    private void setupUI() {
        // Setup date picker
        attendanceDatePicker.setValue(LocalDate.now());
        attendanceDatePicker.setOnAction(e -> loadAttendanceByDate());
        
        // Setup employee combo
        List<Map<String, Object>> employees = employeeDAO.getAllEmployees();
        ObservableList<Map<String, Object>> empData = FXCollections.observableArrayList(employees);
        employeeCombo.setItems(empData);
        employeeCombo.setConverter(new javafx.util.StringConverter<Map<String, Object>>() {
            @Override
            public String toString(Map<String, Object> obj) {
                if (obj == null) return "";
                return obj.get("id") + " - " + obj.get("name");
            }
            
            @Override
            public Map<String, Object> fromString(String str) {
                return null;
            }
        });
        employeeCombo.setOnAction(e -> loadEmployeeMonthlyAttendance());
        
        // Setup tables
        setupAttendanceTable();
        setupMonthlyAttendanceTable();
        setupAbsenteeismTable();
    }
    
    /**
     * Tải chấm công theo ngày
     */
    private void loadAttendanceByDate() {
        LocalDate date = attendanceDatePicker.getValue();
        List<Map<String, Object>> attendance = attendanceDAO.getAttendanceByDate(date);
        ObservableList<Map<String, Object>> data = FXCollections.observableArrayList(attendance);
        attendanceTable.setItems(data);
        logger.info("✅ Tải chấm công ngày " + date + ": " + attendance.size());
    }
    
    /**
     * Tải chấm công tháng của nhân viên
     */
    private void loadEmployeeMonthlyAttendance() {
        Map<String, Object> employee = employeeCombo.getValue();
        if (employee != null) {
            int empId = (Integer) employee.get("id");
            List<Map<String, Object>> attendance = attendanceDAO.getEmployeeMonthlyAttendance(empId);
            ObservableList<Map<String, Object>> data = FXCollections.observableArrayList(attendance);
            monthlyAttendanceTable.setItems(data);
            
            int workDays = attendanceDAO.getTotalWorkDaysInMonth(empId);
            totalWorkDaysLabel.setText("Tổng công tháng: " + workDays + " ngày");
            
            logger.info("✅ Tải chấm công tháng NV#" + empId + ": " + attendance.size());
        }
    }
    
    /**
     * Cấu hình bảng chấm công ngày
     */
    private void setupAttendanceTable() {
        TableColumn<Map<String, Object>, String> empIdCol = new TableColumn<>("Mã NV");
        empIdCol.setCellValueFactory(cellData -> 
            new SimpleStringProperty(cellData.getValue().get("employeeId").toString()));
        empIdCol.setPrefWidth(60);
        
        TableColumn<Map<String, Object>, String> nameCol = new TableColumn<>("Tên");
        nameCol.setCellValueFactory(cellData -> 
            new SimpleStringProperty((String)cellData.getValue().get("name")));
        nameCol.setPrefWidth(150);
        
        TableColumn<Map<String, Object>, String> shiftCol = new TableColumn<>("Ca làm");
        shiftCol.setCellValueFactory(cellData -> 
            new SimpleStringProperty(cellData.getValue().get("shiftStart") + " - " + cellData.getValue().get("shiftEnd")));
        shiftCol.setPrefWidth(100);
        
        TableColumn<Map<String, Object>, String> checkInCol = new TableColumn<>("Giờ vào");
        checkInCol.setCellValueFactory(cellData -> 
            new SimpleStringProperty(cellData.getValue().get("checkIn") != null ? cellData.getValue().get("checkIn").toString() : ""));
        checkInCol.setPrefWidth(100);
        
        TableColumn<Map<String, Object>, String> checkOutCol = new TableColumn<>("Giờ ra");
        checkOutCol.setCellValueFactory(cellData -> 
            new SimpleStringProperty(cellData.getValue().get("checkOut") != null ? cellData.getValue().get("checkOut").toString() : "Chưa ra"));
        checkOutCol.setPrefWidth(100);
        
        TableColumn<Map<String, Object>, String> onTimeCol = new TableColumn<>("Đúng giờ");
        onTimeCol.setCellValueFactory(cellData -> 
            new SimpleStringProperty((String)cellData.getValue().get("onTime")));
        onTimeCol.setPrefWidth(80);
        
        attendanceTable.getColumns().clear();
        attendanceTable.getColumns().addAll(empIdCol, nameCol, shiftCol, checkInCol, checkOutCol, onTimeCol);
    }
    
    /**
     * Cấu hình bảng chấm công tháng
     */
    private void setupMonthlyAttendanceTable() {
        TableColumn<Map<String, Object>, String> dateCol = new TableColumn<>("Ngày");
        dateCol.setCellValueFactory(cellData -> 
            new SimpleStringProperty(cellData.getValue().get("date").toString()));
        dateCol.setPrefWidth(100);
        
        TableColumn<Map<String, Object>, String> checkInCol = new TableColumn<>("Giờ vào");
        checkInCol.setCellValueFactory(cellData -> 
            new SimpleStringProperty(cellData.getValue().get("checkIn") != null ? cellData.getValue().get("checkIn").toString() : "Vắng"));
        checkInCol.setPrefWidth(100);
        
        TableColumn<Map<String, Object>, String> checkOutCol = new TableColumn<>("Giờ ra");
        checkOutCol.setCellValueFactory(cellData -> 
            new SimpleStringProperty(cellData.getValue().get("checkOut") != null ? cellData.getValue().get("checkOut").toString() : ""));
        checkOutCol.setPrefWidth(100);
        
        TableColumn<Map<String, Object>, String> statusCol = new TableColumn<>("Trạng thái");
        statusCol.setCellValueFactory(cellData -> 
            new SimpleStringProperty((String)cellData.getValue().get("status")));
        statusCol.setPrefWidth(120);
        
        monthlyAttendanceTable.getColumns().clear();
        monthlyAttendanceTable.getColumns().addAll(dateCol, checkInCol, checkOutCol, statusCol);
    }
    
    /**
     * Tải thống kê vắng mặt
     */
    private void loadAbsenteeismStatistics() {
        List<Map<String, Object>> stats = attendanceDAO.getAbsenteeismStatistics();
        ObservableList<Map<String, Object>> data = FXCollections.observableArrayList(stats);
        absenteeismTable.setItems(data);
        logger.info("✅ Tải thống kê vắng mặt: " + stats.size());
    }
    
    /**
     * Cấu hình bảng vắng mặt
     */
    private void setupAbsenteeismTable() {
        TableColumn<Map<String, Object>, String> empIdCol = new TableColumn<>("Mã NV");
        empIdCol.setCellValueFactory(cellData -> 
            new SimpleStringProperty(cellData.getValue().get("employeeId").toString()));
        empIdCol.setPrefWidth(60);
        
        TableColumn<Map<String, Object>, String> nameCol = new TableColumn<>("Tên");
        nameCol.setCellValueFactory(cellData -> 
            new SimpleStringProperty((String)cellData.getValue().get("name")));
        nameCol.setPrefWidth(150);
        
        TableColumn<Map<String, Object>, String> absentCol = new TableColumn<>("Vắng (ngày)");
        absentCol.setCellValueFactory(cellData -> 
            new SimpleStringProperty(cellData.getValue().get("absentDays").toString()));
        absentCol.setPrefWidth(100);
        
        TableColumn<Map<String, Object>, String> lateCol = new TableColumn<>("Đi muộn (ngày)");
        lateCol.setCellValueFactory(cellData -> 
            new SimpleStringProperty(cellData.getValue().get("lateDays").toString()));
        lateCol.setPrefWidth(120);
        
        absenteeismTable.getColumns().clear();
        absenteeismTable.getColumns().addAll(empIdCol, nameCol, absentCol, lateCol);
    }
    
    /**
     * Chấm công vào
     */
    @FXML
    private void handleCheckIn() {
        Map<String, Object> employee = employeeCombo.getValue();
        if (employee == null) {
            showAlert("Lỗi", "Vui lòng chọn nhân viên!");
            return;
        }
        
        int empId = (Integer) employee.get("id");
        LocalDate date = LocalDate.now();
        int shiftId = 1; // Mặc định ca 1
        
        if (attendanceDAO.checkIn(empId, shiftId, date)) {
            showAlert("Thành công", "✅ Ghi nhận giờ vào thành công!");
            loadAttendanceByDate();
        } else {
            showAlert("Lỗi", "❌ Lỗi ghi nhận giờ vào!");
        }
    }
    
    /**
     * Chấm công ra
     */
    @FXML
    private void handleCheckOut() {
        Map<String, Object> employee = employeeCombo.getValue();
        if (employee == null) {
            showAlert("Lỗi", "Vui lòng chọn nhân viên!");
            return;
        }
        
        int empId = (Integer) employee.get("id");
        LocalDate date = LocalDate.now();
        
        if (attendanceDAO.checkOut(empId, date)) {
            showAlert("Thành công", "✅ Ghi nhận giờ ra thành công!");
            loadAttendanceByDate();
        } else {
            showAlert("Lỗi", "❌ Lỗi ghi nhận giờ ra!");
        }
    }
    
    /**
     * Làm mới dữ liệu
     */
    @FXML
    private void handleRefresh() {
        logger.info("🔄 Làm mới dữ liệu chấm công");
        loadAttendanceByDate();
        loadEmployeeMonthlyAttendance();
        loadAbsenteeismStatistics();
    }
    
    /**
     * Quay lại
     */
    @FXML
    private void handleBack() {
        logger.info("🔙 Quay lại Dashboard");
        SceneManager.switchScene(
            "/CoffeeShop/view/dashboard.fxml",
            "☕ Dashboard - Hệ thống quản lý quán cà phê",
            1200, 700
        );
    }
    
    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(title);
        alert.setContentText(message);
        alert.showAndWait();
    }
}

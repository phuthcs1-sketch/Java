package CoffeeShop.controller;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.layout.FlowPane;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.beans.property.SimpleStringProperty;
import CoffeeShop.util.LoggerUtil;
import CoffeeShop.util.SceneManager;
import CoffeeShop.dao.TableDAO;
import java.util.logging.Logger;
import java.util.List;
import java.util.Map;

/**
 * Controller cho quản lý bàn ăn
 */
public class TableController {
    
    private static final Logger logger = LoggerUtil.getLogger(TableController.class.getName());
    
    @FXML private TableView<Map<String, Object>> tablesTable;
    @FXML private Label totalTablesLabel;
    @FXML private Label availableTablesLabel;
    @FXML private FlowPane tableGridPane;
    
    private ObservableList<Map<String, Object>> allTables = FXCollections.observableArrayList();
    private TableDAO tableDAO = new TableDAO();
    
    @FXML
    private void initialize() {
        logger.info("🪑 Khởi tạo TableController");
        
        setupTableView();
        loadTables();
        loadTableGrid();
        
        logger.info("✅ TableController sẵn sàng");
    }
    
    /**
     * Cấu hình bảng bàn
     */
    private void setupTableView() {
        TableColumn<Map<String, Object>, String> idCol = new TableColumn<>("Mã Bàn");
        idCol.setCellValueFactory(cellData -> 
            new SimpleStringProperty(cellData.getValue().get("id").toString()));
        idCol.setPrefWidth(70);
        
        TableColumn<Map<String, Object>, String> nameCol = new TableColumn<>("Tên Bàn");
        nameCol.setCellValueFactory(cellData -> 
            new SimpleStringProperty((String)cellData.getValue().get("name")));
        nameCol.setPrefWidth(150);
        
        TableColumn<Map<String, Object>, String> seatsCol = new TableColumn<>("Số Ghế");
        seatsCol.setCellValueFactory(cellData -> 
            new SimpleStringProperty(cellData.getValue().get("seats").toString()));
        seatsCol.setPrefWidth(70);
        
        TableColumn<Map<String, Object>, String> statusCol = new TableColumn<>("Trạng thái");
        statusCol.setCellValueFactory(cellData -> 
            new SimpleStringProperty((String)cellData.getValue().get("status")));
        statusCol.setPrefWidth(120);
        
        TableColumn<Map<String, Object>, Void> actionCol = new TableColumn<>("Hành động");
        actionCol.setCellFactory(param -> new TableCell<Map<String, Object>, Void>() {
            private final Button editBtn = new Button("✎");
            private final Button deleteBtn = new Button("✕");
            
            {
                editBtn.setStyle("-fx-font-size: 12px; -fx-padding: 5px 8px; -fx-background-color: #3498db;");
                deleteBtn.setStyle("-fx-font-size: 12px; -fx-padding: 5px 8px; -fx-background-color: #e74c3c;");
                
                editBtn.setOnAction(event -> {
                    Map<String, Object> table = getTableView().getItems().get(getIndex());
                    handleEditTable(table);
                });
                
                deleteBtn.setOnAction(event -> {
                    Map<String, Object> table = getTableView().getItems().get(getIndex());
                    handleDeleteTable((Integer)table.get("id"));
                });
            }
            
            @Override
            protected void updateItem(Void item, boolean empty) {
                super.updateItem(item, empty);
                if (empty) {
                    setGraphic(null);
                } else {
                    HBox hbox = new HBox(5);
                    hbox.getChildren().addAll(editBtn, deleteBtn);
                    setGraphic(hbox);
                }
            }
        });
        actionCol.setPrefWidth(100);
        
        tablesTable.getColumns().addAll(idCol, nameCol, seatsCol, statusCol, actionCol);
    }
    
    /**
     * Tải danh sách bàn
     */
    private void loadTables() {
        logger.info("📥 Đang tải danh sách bàn...");
        List<Map<String, Object>> tables = tableDAO.getAllTables();
        allTables.clear();
        allTables.addAll(tables);
        tablesTable.setItems(allTables);
        
        totalTablesLabel.setText(tables.size() + "");
        int available = tableDAO.getAvailableTablesCount();
        availableTablesLabel.setText(available + "/" + tables.size());
        
        logger.info("✅ Tải " + tables.size() + " bàn");
    }
    
    /**
     * Tải bàn dưới dạng grid
     */
    private void loadTableGrid() {
        tableGridPane.getChildren().clear();
        
        for (Map<String, Object> table : allTables) {
            String name = (String) table.get("name");
            String status = (String) table.get("status");
            int id = (Integer) table.get("id");
            
            // Chọn màu sắc dựa vào trạng thái
            String color = "Trống".equals(status) ? "#27ae60" : 
                          "Đang sử dụng".equals(status) ? "#e74c3c" : "#95a5a6";
            
            Button tableBtn = new Button(name + "\n" + status);
            tableBtn.setStyle("-fx-min-width: 100; -fx-min-height: 100; -fx-font-size: 12px; " +
                            "-fx-background-color: " + color + "; -fx-text-fill: white;");
            tableBtn.setOnAction(e -> toggleTableStatus(id));
            
            tableGridPane.getChildren().add(tableBtn);
        }
    }
    
    /**
     * Thay đổi trạng thái bàn
     */
    private void toggleTableStatus(int tableId) {
        Map<String, Object> table = allTables.stream()
            .filter(t -> (Integer)t.get("id") == tableId)
            .findFirst()
            .orElse(null);
        
        if (table != null) {
            String currentStatus = (String) table.get("status");
            String newStatus = "Trống".equals(currentStatus) ? "Đang sử dụng" : "Trống";
            
            if (tableDAO.updateTableStatus(tableId, newStatus)) {
                logger.info("✅ Thay đổi trạng thái bàn #" + tableId + " thành " + newStatus);
                loadTables();
                loadTableGrid();
            }
        }
    }
    
    /**
     * Thêm bàn mới
     */
    @FXML
    private void handleAddTable() {
        logger.info("➕ Thêm bàn mới");
        showTableDialog(null);
    }
    
    /**
     * Sửa bàn
     */
    private void handleEditTable(Map<String, Object> table) {
        logger.info("✎ Sửa bàn: " + table.get("name"));
        showTableDialog(table);
    }
    
    /**
     * Xóa bàn
     */
    private void handleDeleteTable(int tableId) {
        logger.info("✕ Xóa bàn #" + tableId);
        
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Xác nhận xóa");
        alert.setHeaderText("Bạn có chắc muốn xóa bàn này?");
        
        alert.showAndWait().ifPresent(response -> {
            if (response == ButtonType.OK) {
                if (tableDAO.deleteTable(tableId)) {
                    showAlert("Thành công", "✅ Xóa bàn thành công!");
                    loadTables();
                    loadTableGrid();
                } else {
                    showAlert("Lỗi", "❌ Lỗi khi xóa bàn!");
                }
            }
        });
    }
    
    /**
     * Hiển thị dialog thêm/sửa bàn
     */
    private void showTableDialog(Map<String, Object> table) {
        Dialog<ButtonType> dialog = new Dialog<>();
        dialog.setTitle(table == null ? "Thêm bàn" : "Sửa bàn");
        
        javafx.scene.layout.GridPane grid = new javafx.scene.layout.GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new javafx.geometry.Insets(20));
        
        TextField nameField = new TextField();
        Spinner<Integer> seatsSpinner = new Spinner<>(1, 20, 4);
        ComboBox<String> statusCombo = new ComboBox<>();
        statusCombo.getItems().addAll("Trống", "Đang sử dụng", "Bảo trì");
        
        if (table != null) {
            nameField.setText((String)table.get("name"));
            seatsSpinner.getValueFactory().setValue((Integer)table.get("seats"));
            statusCombo.setValue((String)table.get("status"));
        } else {
            statusCombo.setValue("Trống");
        }
        
        grid.add(new Label("Tên bàn:"), 0, 0);
        grid.add(nameField, 1, 0);
        grid.add(new Label("Số ghế:"), 0, 1);
        grid.add(seatsSpinner, 1, 1);
        grid.add(new Label("Trạng thái:"), 0, 2);
        grid.add(statusCombo, 1, 2);
        
        dialog.getDialogPane().setContent(grid);
        dialog.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);
        
        dialog.showAndWait().ifPresent(result -> {
            if (result != ButtonType.OK) return;
            String name = nameField.getText().trim();
            int seats = seatsSpinner.getValue();
            String status = statusCombo.getValue();
            
            if (name.isEmpty()) {
                showAlert("Lỗi", "❌ Tên bàn không được để trống!");
                return;
            }
            
            if (table == null) {
                if (tableDAO.addTable(name, seats)) {
                    showAlert("Thành công", "✅ Thêm bàn thành công!");
                    loadTables();
                    loadTableGrid();
                } else {
                    showAlert("Lỗi", "❌ Lỗi khi thêm bàn!");
                }
            } else {
                int id = (Integer)table.get("id");
                if (tableDAO.updateTable(id, name, seats, status)) {
                    showAlert("Thành công", "✅ Cập nhật bàn thành công!");
                    loadTables();
                    loadTableGrid();
                } else {
                    showAlert("Lỗi", "❌ Lỗi khi cập nhật bàn!");
                }
            }
        });
    }
    
    /**
     * Làm mới dữ liệu
     */
    @FXML
    private void handleRefresh() {
        logger.info("🔄 Làm mới dữ liệu");
        loadTables();
        loadTableGrid();
    }
    
    /**
     * Quay lại
     */
    @FXML
    private void handleBack() {
        logger.info("🔙 Quay lại Dashboard");
        SceneManager.switchScene(
            "/CoffeeShop/view/dashboard.fxml",
            "☕ Dashboard - Hệ thống quản lý quán cà phê",
            1200, 700
        );
    }
    
    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(title);
        alert.setContentText(message);
        alert.showAndWait();
    }
}

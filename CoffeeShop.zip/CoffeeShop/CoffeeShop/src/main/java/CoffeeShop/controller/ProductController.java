package CoffeeShop.controller;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.HBox;
import javafx.scene.layout.GridPane;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import CoffeeShop.util.LoggerUtil;
import CoffeeShop.util.SceneManager;
import CoffeeShop.dao.ProductDAO;
import CoffeeShop.dao.CategoryDAO;
import CoffeeShop.Product;
import java.util.logging.Logger;
import java.util.List;

/**
 * Controller cho quản lý sản phẩm
 * Quản lý danh sách sản phẩm, thêm/sửa/xóa sản phẩm
 */
public class ProductController {
    
    private static final Logger logger = LoggerUtil.getLogger(ProductController.class.getName());
    
    @FXML private TextField searchField;
    @FXML private ComboBox<String> categoryCombo;
    @FXML private Label totalProductsLabel;
    @FXML private Label inStockLabel;
    @FXML private Label outOfStockLabel;
    @FXML private Label totalValueLabel;
    @FXML private TableView<Product> productsTable;
    
    private ObservableList<Product> allProducts = FXCollections.observableArrayList();
    private ProductDAO productDAO = new ProductDAO();
    
    /**
     * Khởi tạo Controller
     */
    @FXML
    private void initialize() {
        logger.info("📦 Khởi tạo ProductController");
        
        setupProductTable();
        loadCategories();
        loadProducts();
        setupEventListeners();
        
        logger.info("✅ ProductController sẵn sàng");
    }
    
    /**
     * Cấu hình TableView sản phẩm
     */
    private void setupProductTable() {
        // Cột Mã SP
        TableColumn<Product, Integer> idCol = new TableColumn<>("ID");
        idCol.setCellValueFactory(new PropertyValueFactory<>("id"));
        idCol.setPrefWidth(50);
        
        // Cột Tên SP
        TableColumn<Product, String> nameCol = new TableColumn<>("Tên sản phẩm");
        nameCol.setCellValueFactory(new PropertyValueFactory<>("name"));
        nameCol.setPrefWidth(200);
        
        // Cột Loại
        TableColumn<Product, String> categoryCol = new TableColumn<>("Loại");
        categoryCol.setCellValueFactory(new PropertyValueFactory<>("category"));
        categoryCol.setPrefWidth(100);
        
        // Cột Giá
        TableColumn<Product, Double> priceCol = new TableColumn<>("Giá");
        priceCol.setCellValueFactory(new PropertyValueFactory<>("price"));
        priceCol.setPrefWidth(100);
        priceCol.setCellFactory(tc -> new TableCell<Product, Double>() {
            @Override
            protected void updateItem(Double value, boolean empty) {
                super.updateItem(value, empty);
                setText(empty ? null : String.format("%.0f ₫", value));
            }
        });
        
        // Cột Hành động
        TableColumn<Product, Void> actionCol = new TableColumn<>("Hành động");
        actionCol.setCellFactory(param -> new TableCell<Product, Void>() {
            private final Button editBtn = new Button("✎");
            private final Button deleteBtn = new Button("✕");
            
            {
                editBtn.setStyle("-fx-font-size: 12px; -fx-padding: 5px 8px; -fx-background-color: #3498db;");
                deleteBtn.setStyle("-fx-font-size: 12px; -fx-padding: 5px 8px; -fx-background-color: #e74c3c;");
                
                editBtn.setOnAction(event -> {
                    Product product = getTableView().getItems().get(getIndex());
                    handleEditProduct(product);
                });
                
                deleteBtn.setOnAction(event -> {
                    Product product = getTableView().getItems().get(getIndex());
                    handleDeleteProduct(product);
                });
            }
            
            @Override
            protected void updateItem(Void item, boolean empty) {
                super.updateItem(item, empty);
                if (empty) {
                    setGraphic(null);
                } else {
                    HBox hbox = new HBox(5);
                    hbox.getChildren().addAll(editBtn, deleteBtn);
                    setGraphic(hbox);
                }
            }
        });
        actionCol.setPrefWidth(100);
        
        productsTable.getColumns().addAll(idCol, nameCol, categoryCol, priceCol, actionCol);
    }
    
    /**
     * Tải danh sách danh mục
     */
    private void loadCategories() {
        logger.info("📂 Đang tải danh mục sản phẩm...");

        CategoryDAO categoryDAO = new CategoryDAO();
        List<String> names = categoryDAO.getCategoryNames();

        categoryCombo.getItems().clear();
        categoryCombo.getItems().add("Tất cả");
        categoryCombo.getItems().addAll(names);
        categoryCombo.setValue("Tất cả");

        categoryCombo.setOnAction(e -> filterProducts());
    }
    
    /**
     * Tải danh sách sản phẩm
     */
    private void loadProducts() {
        logger.info("📥 Đang tải danh sách sản phẩm từ database...");
        
        List<Product> products = productDAO.getAllProducts();
        allProducts.clear();
        allProducts.addAll(products);
        productsTable.setItems(allProducts);
        
        updateStatistics();
        
        logger.info("✅ Tải xong: " + products.size() + " sản phẩm");
    }
    
    /**
     * Cập nhật thống kê
     */
    private void updateStatistics() {
        int total = productDAO.getTotalProducts();
        int inStock = productDAO.getInStockCount();
        int outOfStock = total - inStock;
        double totalValue = productDAO.getTotalInventoryValue();
        
        totalProductsLabel.setText(total + "");
        inStockLabel.setText(inStock + "");
        outOfStockLabel.setText(outOfStock + "");
        totalValueLabel.setText(String.format("%.0f ₫", totalValue));
    }
    
    /**
     * Cài đặt sự kiện
     */
    private void setupEventListeners() {
        searchField.textProperty().addListener((obs, old, newValue) -> {
            filterProducts();
        });
    }
    
    /**
     * Lọc sản phẩm theo tìm kiếm và danh mục
     */
    private void filterProducts() {
        String searchText = searchField.getText().toLowerCase();
        String selectedCategory = categoryCombo.getValue();
        
        ObservableList<Product> filtered = FXCollections.observableArrayList();
        
        for (Product product : allProducts) {
            boolean matchesSearch = product.getName().toLowerCase().contains(searchText);
            boolean matchesCategory = selectedCategory.equals("Tất cả") || product.getCategory().equals(selectedCategory);
            
            if (matchesSearch && matchesCategory) {
                filtered.add(product);
            }
        }
        
        productsTable.setItems(filtered);
        logger.info("🔍 Lọc sản phẩm: " + filtered.size() + " kết quả");
    }
    
    /**
     * Xử lý thêm sản phẩm mới
     */
    @FXML
    private void handleAddProduct() {
        logger.info("➕ Thêm sản phẩm mới");
        showProductDialog(null);
    }
    
    /**
     * Xử lý sửa sản phẩm
     */
    private void handleEditProduct(Product product) {
        logger.info("✎ Sửa sản phẩm: " + product.getName());
        showProductDialog(product);
    }
    
    /**
     * Xử lý xóa sản phẩm
     */
    private void handleDeleteProduct(Product product) {
        logger.info("✕ Xóa sản phẩm: " + product.getName());
        
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Xác nhận xóa");
        alert.setHeaderText("Bạn có chắc muốn xóa sản phẩm này?");
        alert.setContentText("Sản phẩm: " + product.getName());
        
        alert.showAndWait().ifPresent(response -> {
            if (response == ButtonType.OK) {
                if (productDAO.deleteProduct(product.getId())) {
                    showAlert("Thành công", "✅ Xóa sản phẩm thành công!");
                    loadProducts();
                } else {
                    showAlert("Lỗi", "❌ Lỗi khi xóa sản phẩm!");
                }
            }
        });
    }
    
    /**
     * Hiển thị dialog thêm/sửa sản phẩm
     */
    private void showProductDialog(Product product) {
        Dialog<ButtonType> dialog = new Dialog<>();
        dialog.setTitle(product == null ? "Thêm sản phẩm" : "Sửa sản phẩm");
        
        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new javafx.geometry.Insets(20));
        
        TextField nameField = new TextField();
        TextField priceField = new TextField();
        ComboBox<String> categoryField = new ComboBox<>();
        CategoryDAO categoryDAO = new CategoryDAO();
        categoryField.getItems().addAll(categoryDAO.getCategoryNames());
        
        if (product != null) {
            nameField.setText(product.getName());
            priceField.setText(String.valueOf(product.getPrice()));
            categoryField.setValue(product.getCategory());
        }
        
        grid.add(new Label("Tên sản phẩm:"), 0, 0);
        grid.add(nameField, 1, 0);
        grid.add(new Label("Loại:"), 0, 1);
        grid.add(categoryField, 1, 1);
        grid.add(new Label("Giá:"), 0, 2);
        grid.add(priceField, 1, 2);
        
        dialog.getDialogPane().setContent(grid);
        dialog.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);
        
        dialog.showAndWait().ifPresent(result -> {
            if (result != ButtonType.OK) return;
            try {
                String name = nameField.getText().trim();
                String category = categoryField.getValue();
                double price = Double.parseDouble(priceField.getText().trim());
                
                if (name.isEmpty()) {
                    showAlert("Lỗi", "❌ Tên sản phẩm không được để trống!");
                    return;
                }
                
                if (price <= 0) {
                    showAlert("Lỗi", "❌ Giá phải lớn hơn 0!");
                    return;
                }
                
                if (product == null) {
                    // Thêm sản phẩm mới
                    if (productDAO.addProduct(name, category, price)) {
                        showAlert("Thành công", "✅ Thêm sản phẩm thành công!");
                        logger.info("✅ Thêm sản phẩm: " + name);
                        loadProducts();
                    } else {
                        showAlert("Lỗi", "❌ Lỗi khi thêm sản phẩm!");
                    }
                } else {
                    // Cập nhật sản phẩm
                    if (productDAO.updateProduct(product.getId(), name, category, price)) {
                        showAlert("Thành công", "✅ Cập nhật sản phẩm thành công!");
                        logger.info("✅ Cập nhật sản phẩm: " + name);
                        loadProducts();
                    } else {
                        showAlert("Lỗi", "❌ Lỗi khi cập nhật sản phẩm!");
                    }
                }
                
            } catch (NumberFormatException e) {
                showAlert("Lỗi", "❌ Giá phải là số hợp lệ!");
            }
        });
    }
    
    /**
     * Làm mới dữ liệu
     */
    @FXML
    private void handleRefresh() {
        logger.info("🔄 Làm mới dữ liệu sản phẩm");
        loadProducts();
    }
    
    /**
     * Quay lại dashboard
     */
    @FXML
    private void handleBack() {
        logger.info("🔙 Quay lại dashboard");
        SceneManager.switchScene(
            "/CoffeeShop/view/dashboard.fxml",
            "☕ Dashboard - Hệ thống quản lý quán cà phê",
            1200, 700
        );
    }
    
    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(title);
        alert.setContentText(message);
        alert.showAndWait();
    }
}

package CoffeeShop.controller;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.GridPane;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import CoffeeShop.util.LoggerUtil;
import CoffeeShop.util.SceneManager;
import CoffeeShop.dao.CustomerDAO;
import java.util.logging.Logger;
import java.util.List;
import java.util.Map;

/**
 * Controller cho quản lý khách hàng
 */
public class CustomerController {
    
    private static final Logger logger = LoggerUtil.getLogger(CustomerController.class.getName());
    
    @FXML private TextField searchField;
    @FXML private Label totalCustomersLabel;
    @FXML private TableView<Map<String, Object>> customersTable;
    
    private ObservableList<Map<String, Object>> allCustomers = FXCollections.observableArrayList();
    private CustomerDAO customerDAO = new CustomerDAO();
    
    @FXML
    private void initialize() {
        logger.info("👤 Khởi tạo CustomerController");
        
        setupCustomerTable();
        loadCustomers();
        setupEventListeners();
        
        logger.info("✅ CustomerController sẵn sàng");
    }
    
    /**
     * Cấu hình bảng khách hàng
     */
    private void setupCustomerTable() {
        // Cột ID
        TableColumn<Map<String, Object>, Integer> idCol = new TableColumn<>("ID");
        idCol.setCellValueFactory(cellData -> 
            new javafx.beans.property.SimpleObjectProperty<>((Integer)cellData.getValue().get("id")));
        idCol.setPrefWidth(50);
        
        // Cột Tên
        TableColumn<Map<String, Object>, String> nameCol = new TableColumn<>("Tên khách hàng");
        nameCol.setCellValueFactory(cellData -> 
            new javafx.beans.property.SimpleStringProperty((String)cellData.getValue().get("name")));
        nameCol.setPrefWidth(150);
        
        // Cột Điện thoại
        TableColumn<Map<String, Object>, String> phoneCol = new TableColumn<>("Điện thoại");
        phoneCol.setCellValueFactory(cellData -> {
            Object v = cellData.getValue().get("phone");
            return new javafx.beans.property.SimpleStringProperty(v != null ? (String) v : "");
        });
        phoneCol.setPrefWidth(120);

        // Cột Email
        TableColumn<Map<String, Object>, String> emailCol = new TableColumn<>("Email");
        emailCol.setCellValueFactory(cellData -> {
            Object v = cellData.getValue().get("email");
            return new javafx.beans.property.SimpleStringProperty(v != null ? (String) v : "");
        });
        emailCol.setPrefWidth(150);

        // Cột Địa chỉ
        TableColumn<Map<String, Object>, String> addressCol = new TableColumn<>("Địa chỉ");
        addressCol.setCellValueFactory(cellData -> {
            Object v = cellData.getValue().get("address");
            return new javafx.beans.property.SimpleStringProperty(v != null ? (String) v : "");
        });
        addressCol.setPrefWidth(200);
        
        // Cột Điểm tích lũy
        TableColumn<Map<String, Object>, String> loyaltyCol = new TableColumn<>("Điểm");
        loyaltyCol.setCellValueFactory(cellData ->
            new javafx.beans.property.SimpleStringProperty(String.valueOf(cellData.getValue().get("loyalty"))));
        loyaltyCol.setPrefWidth(80);
        
        // Cột Hành động
        TableColumn<Map<String, Object>, Void> actionCol = new TableColumn<>("Hành động");
        actionCol.setCellFactory(param -> new TableCell<Map<String, Object>, Void>() {
            private final Button editBtn = new Button("✎");
            private final Button deleteBtn = new Button("✕");
            
            {
                editBtn.setStyle("-fx-font-size: 12px; -fx-padding: 5px 8px; -fx-background-color: #3498db;");
                deleteBtn.setStyle("-fx-font-size: 12px; -fx-padding: 5px 8px; -fx-background-color: #e74c3c;");
                
                editBtn.setOnAction(event -> {
                    Map<String, Object> cust = getTableView().getItems().get(getIndex());
                    handleEditCustomer(cust);
                });
                
                deleteBtn.setOnAction(event -> {
                    Map<String, Object> cust = getTableView().getItems().get(getIndex());
                    handleDeleteCustomer((Integer)cust.get("id"));
                });
            }
            
            @Override
            protected void updateItem(Void item, boolean empty) {
                super.updateItem(item, empty);
                if (empty) {
                    setGraphic(null);
                } else {
                    HBox hbox = new HBox(5);
                    hbox.getChildren().addAll(editBtn, deleteBtn);
                    setGraphic(hbox);
                }
            }
        });
        actionCol.setPrefWidth(100);
        
        customersTable.getColumns().addAll(idCol, nameCol, phoneCol, emailCol, addressCol, loyaltyCol, actionCol);
    }
    
    /**
     * Tải danh sách khách hàng
     */
    private void loadCustomers() {
        logger.info("📥 Đang tải danh sách khách hàng...");
        
        List<Map<String, Object>> customers = customerDAO.getAllCustomers();
        allCustomers.clear();
        allCustomers.addAll(customers);
        customersTable.setItems(allCustomers);
        
        totalCustomersLabel.setText(customers.size() + "");
        logger.info("✅ Tải " + customers.size() + " khách hàng");
    }
    
    /**
     * Cài đặt sự kiện
     */
    private void setupEventListeners() {
        searchField.textProperty().addListener((obs, old, newValue) -> {
            filterCustomers();
        });
    }
    
    /**
     * Lọc khách hàng
     */
    private void filterCustomers() {
        String searchText = searchField.getText().toLowerCase();
        ObservableList<Map<String, Object>> filtered = FXCollections.observableArrayList();
        
        for (Map<String, Object> cust : allCustomers) {
            String name = (String) cust.get("name");
            String phone = cust.get("phone") != null ? (String) cust.get("phone") : "";
            String email = cust.get("email") != null ? (String) cust.get("email") : "";

            if (name.toLowerCase().contains(searchText) ||
                phone.contains(searchText) ||
                email.toLowerCase().contains(searchText)) {
                filtered.add(cust);
            }
        }
        
        customersTable.setItems(filtered);
    }
    
    /**
     * Thêm khách hàng mới
     */
    @FXML
    private void handleAddCustomer() {
        logger.info("➕ Thêm khách hàng mới");
        showCustomerDialog(null);
    }
    
    /**
     * Sửa khách hàng
     */
    private void handleEditCustomer(Map<String, Object> customer) {
        logger.info("✎ Sửa khách hàng: " + customer.get("name"));
        showCustomerDialog(customer);
    }
    
    /**
     * Xóa khách hàng
     */
    private void handleDeleteCustomer(int customerId) {
        logger.info("✕ Xóa khách hàng #" + customerId);

        int orderCount = customerDAO.getOrderCount(customerId);

        String content = "Bạn có chắc muốn xóa khách hàng này?";
        if (orderCount > 0) {
            content = "Khách hàng này có " + orderCount + " hóa đơn liên quan.\n\n" +
                      "Nếu xóa, các hóa đơn đó sẽ không còn gắn với khách hàng nào.\n\n" +
                      "Bạn có chắc muốn tiếp tục?";
        }

        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Xác nhận xóa");
        alert.setHeaderText("Xóa khách hàng");
        alert.setContentText(content);

        alert.showAndWait().ifPresent(response -> {
            if (response == ButtonType.OK) {
                if (customerDAO.deleteCustomer(customerId)) {
                    showAlert("Thành công", "✅ Đã xóa khách hàng thành công!");
                    loadCustomers();
                } else {
                    showAlert("Lỗi", "❌ Không thể xóa khách hàng. Vui lòng thử lại.");
                }
            }
        });
    }
    
    /**
     * Hiển thị dialog thêm/sửa khách hàng
     */
    private void showCustomerDialog(Map<String, Object> customer) {
        Dialog<ButtonType> dialog = new Dialog<>();
        dialog.setTitle(customer == null ? "Thêm khách hàng" : "Sửa khách hàng");
        
        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(20));
        
        TextField nameField = new TextField();
        TextField phoneField = new TextField();
        TextField emailField = new TextField();
        TextField addressField = new TextField();
        
        if (customer != null) {
            nameField.setText((String) customer.get("name"));
            Object phone = customer.get("phone");
            phoneField.setText(phone != null ? (String) phone : "");
            Object email = customer.get("email");
            emailField.setText(email != null ? (String) email : "");
            Object address = customer.get("address");
            addressField.setText(address != null ? (String) address : "");
        }
        
        grid.add(new Label("Tên khách hàng:"), 0, 0);
        grid.add(nameField, 1, 0);
        grid.add(new Label("Điện thoại:"), 0, 1);
        grid.add(phoneField, 1, 1);
        grid.add(new Label("Email:"), 0, 2);
        grid.add(emailField, 1, 2);
        grid.add(new Label("Địa chỉ:"), 0, 3);
        grid.add(addressField, 1, 3);
        
        dialog.getDialogPane().setContent(grid);
        dialog.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);
        
        dialog.showAndWait().ifPresent(result -> {
            if (result != ButtonType.OK) return;
            try {
                String name = nameField.getText().trim();
                String phone = phoneField.getText().trim();
                String email = emailField.getText().trim();
                String address = addressField.getText().trim();
                
                if (name.isEmpty()) {
                    showAlert("Lỗi", "❌ Vui lòng nhập tên khách hàng");
                    return;
                }
                
                boolean success = false;
                if (customer == null) {
                    success = customerDAO.addCustomer(name, phone, address, email);
                    if (success) {
                        showAlert("Thành công", "✅ Thêm khách hàng thành công: " + name);
                        logger.info("✅ Thêm khách hàng: " + name);
                    } else {
                        showAlert("Lỗi", "❌ Lỗi khi thêm khách hàng");
                    }
                } else {
                    int id = (Integer)customer.get("id");
                    success = customerDAO.updateCustomer(id, name, phone, address, email);
                    if (success) {
                        showAlert("Thành công", "✅ Cập nhật khách hàng thành công: " + name);
                        logger.info("✅ Cập nhật khách hàng: " + name);
                    } else {
                        showAlert("Lỗi", "❌ Lỗi khi cập nhật khách hàng");
                    }
                }
                
                if (success) {
                    loadCustomers();
                }
            } catch (Exception e) {
                showAlert("Lỗi", "❌ Lỗi: " + e.getMessage());
                logger.severe("❌ Exception: " + e.getMessage());
                e.printStackTrace();
            }
        });
    }
    
    /**
     * Làm mới dữ liệu
     */
    @FXML
    private void handleRefresh() {
        logger.info("🔄 Làm mới dữ liệu");
        loadCustomers();
    }
    
    /**
     * Quay lại
     */
    @FXML
    private void handleBack() {
        logger.info("🔙 Quay lại");
        SceneManager.switchScene(
            "/CoffeeShop/view/dashboard.fxml",
            "☕ Dashboard - Hệ thống quản lý quán cà phê",
            1200, 700
        );
    }
    
    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(title);
        alert.setContentText(message);
        alert.showAndWait();
    }
}

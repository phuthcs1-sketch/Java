package CoffeeShop.controller;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import CoffeeShop.util.LoggerUtil;
import CoffeeShop.util.ValidationUtil;
import CoffeeShop.util.SceneManager;
import CoffeeShop.DBConnection;
import java.sql.*;
import java.util.logging.Logger;

/**
 * Controller cho màn hình Đăng ký
 * Xử lý tạo tài khoản mới
 */
public class RegisterController {
    
    private static final Logger logger = LoggerUtil.getLogger(RegisterController.class.getName());
    
    @FXML private TextField fullNameField;
    @FXML private TextField usernameField;
    @FXML private TextField emailField;
    @FXML private PasswordField passwordField;
    @FXML private PasswordField confirmPasswordField;
    @FXML private ComboBox<String> roleComboBox;
    @FXML private Label messageLabel;
    
    /**
     * Khởi tạo Controller
     */
    @FXML
    private void initialize() {
        logger.info("📝 Khởi tạo RegisterController");
        roleComboBox.getItems().addAll("admin", "manager", "employee");
        roleComboBox.setValue("employee");
    }
    
    /**
     * Xử lý đăng ký
     */
    @FXML
    private void handleRegister() {
        String fullName = fullNameField.getText().trim();
        String username = usernameField.getText().trim();
        String email = emailField.getText().trim();
        String password = passwordField.getText();
        String confirmPassword = confirmPasswordField.getText();
        String role = roleComboBox.getValue();
        
        logger.info("✍️ Nỗ lực đăng ký tài khoản: " + username);
        
        // Kiểm tra dữ liệu
        if (!validateRegistrationData(fullName, username, email, password, confirmPassword)) {
            return;
        }
        
        // Tạo tài khoản
        createAccount(fullName, username, email, password, role);
    }
    
    /**
     * Kiểm tra dữ liệu đăng ký
     */
    private boolean validateRegistrationData(String fullName, String username, 
                                             String email, String password, String confirmPassword) {
        if (ValidationUtil.isEmpty(fullName)) {
            showError("❌ Vui lòng nhập họ và tên!");
            return false;
        }
        
        if (ValidationUtil.isEmpty(username) || username.length() < 3) {
            showError("❌ Tên đăng nhập phải có ít nhất 3 ký tự!");
            return false;
        }
        
        if (ValidationUtil.isEmpty(email) || !ValidationUtil.isValidEmail(email)) {
            showError("❌ Email không hợp lệ!");
            return false;
        }
        
        if (ValidationUtil.isEmpty(password) || password.length() < 6) {
            showError("❌ Mật khẩu phải có ít nhất 6 ký tự!");
            return false;
        }
        
        if (!password.equals(confirmPassword)) {
            showError("❌ Mật khẩu xác nhận không khớp!");
            return false;
        }
        
        return true;
    }
    
    /**
     * Tạo tài khoản mới
     */
    private void createAccount(String fullName, String username, String email,
                              String password, String role) {
        try {
            logger.info("💾 Tạo tài khoản mới: " + username);

            if (isUsernameExists(username)) {
                showError("❌ Tên đăng nhập đã tồn tại!");
                return;
            }

            try (Connection conn = DBConnection.getConnection()) {
                if (conn == null) {
                    showError("❌ Không thể kết nối đến cơ sở dữ liệu!");
                    return;
                }

                conn.setAutoCommit(false);
                try {
                    // 1. Tạo tài khoản đăng nhập trong USERS
                    String userQuery = "INSERT INTO USERS (FullName, Username, Email, Password, Role) VALUES (?, ?, ?, ?, ?)";
                    try (PreparedStatement stmt = conn.prepareStatement(userQuery)) {
                        stmt.setString(1, fullName);
                        stmt.setString(2, username);
                        stmt.setString(3, email);
                        stmt.setString(4, password);
                        stmt.setString(5, role);
                        stmt.executeUpdate();
                    }

                    // 2. Tạo hồ sơ nhân viên trong NhanVien để xuất hiện ở
                    //    màn hình Quản lý nhân viên và Chấm công
                    String chucVu = switch (role) {
                        case "admin"   -> N("Quản lý");
                        case "manager" -> N("Quản lý");
                        default        -> N("Nhân viên");
                    };

                    String nvQuery = "INSERT INTO NhanVien (TenNV, ChucVu, DienThoai, Luong, TrangThai) " +
                                     "VALUES (?, ?, NULL, 7000000, N'Dang lam')";
                    try (PreparedStatement stmt = conn.prepareStatement(nvQuery)) {
                        stmt.setNString(1, fullName);
                        stmt.setNString(2, chucVu);
                        stmt.executeUpdate();
                    }

                    conn.commit();

                    showSuccess("✅ Đăng ký thành công! Nhân viên \"" + fullName + "\" đã được thêm vào hệ thống.");
                    logger.info("✅ Đăng ký thành công: " + username + " (Role: " + role + ")");

                    new Thread(() -> {
                        try {
                            Thread.sleep(2000);
                            javafx.application.Platform.runLater(this::handleBack);
                        } catch (InterruptedException e) {
                            logger.severe("❌ Lỗi thread: " + e.getMessage());
                        }
                    }).start();

                } catch (Exception ex) {
                    conn.rollback();
                    throw ex;
                }
            }

        } catch (Exception e) {
            logger.severe("❌ Lỗi tạo tài khoản: " + e.getMessage());
            showError("❌ Lỗi: " + e.getMessage());
        }
    }

    /** Trả về chuỗi để dùng với setNString — helper tránh lặp N'...' literal */
    private String N(String s) { return s; }
    
    /**
     * Kiểm tra username đã tồn tại
     */
    private boolean isUsernameExists(String username) {
        String query = "SELECT COUNT(*) as count FROM USERS WHERE Username = ?";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            
            stmt.setString(1, username);
            
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt("count") > 0;
                }
            }
            
        } catch (SQLException e) {
            logger.severe("❌ Lỗi kiểm tra username: " + e.getMessage());
        }
        
        return false;
    }
    
    /**
     * Quay lại trang login
     */
    @FXML
    private void handleBack() {
        logger.info("🔙 Quay lại trang login");
        SceneManager.switchScene(
            "/CoffeeShop/view/login.fxml",
            "Login - Coffee Shop Management",
            950, 600
        );
    }
    
    /**
     * Hiển thị lỗi
     */
    private void showError(String message) {
        messageLabel.setText(message);
        messageLabel.setStyle("-fx-text-fill: #e74c3c; -fx-font-size: 13px;");
    }
    
    /**
     * Hiển thị thành công
     */
    private void showSuccess(String message) {
        messageLabel.setText(message);
        messageLabel.setStyle("-fx-text-fill: #27ae60; -fx-font-size: 13px;");
    }
}

package CoffeeShop.controller;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import CoffeeShop.util.LoggerUtil;
import CoffeeShop.util.ValidationUtil;
import CoffeeShop.util.SceneManager;
import CoffeeShop.dao.UserDAO;
import java.util.logging.Logger;

/**
 * Controller cho màn hình Login
 * Xử lý đăng nhập người dùng
 */
public class LoginController {
    
    private static final Logger logger = LoggerUtil.getLogger(LoginController.class.getName());
    
    @FXML private TextField usernameField;
    @FXML private PasswordField passwordField;
    @FXML private CheckBox rememberMeCheckBox;
    @FXML private Label messageLabel;
    @FXML private Button loginButton;
    @FXML private Button registerButton;
    
    // Session data
    private static String currentUsername;
    private static String currentRole;
    private static int currentUserId;
    
    /**
     * Khởi tạo controller
     */
    @FXML
    private void initialize() {
        logger.info("📋 Khởi tạo LoginController");
        setupEventListeners();
    }
    
    /**
     * Cài đặt các sự kiện
     */
    private void setupEventListeners() {
        // Cho phép nhấn Enter để đăng nhập
        usernameField.setOnKeyPressed(event -> {
            if (event.getCode().toString().equals("ENTER")) {
                handleLogin();
            }
        });
        
        passwordField.setOnKeyPressed(event -> {
            if (event.getCode().toString().equals("ENTER")) {
                handleLogin();
            }
        });
    }
    
    /**
     * Xử lý đăng nhập
     */
    @FXML
    private void handleLogin() {
        String username = usernameField.getText().trim();
        String password = passwordField.getText();
        
        logger.info("🔐 Nỗ lực đăng nhập với username: " + username);
        
        // Kiểm tra nhập liệu
        if (!validateInput(username, password)) {
            return;
        }
        
        // Kiểm tra trong database
        if (authenticateUser(username, password)) {
            showSuccess("✅ Đăng nhập thành công!");
            logger.info("✅ Đăng nhập thành công cho: " + username);
            
            // Mở dashboard sau 1 giây
            new Thread(() -> {
                try {
                    Thread.sleep(1000);
                    javafx.application.Platform.runLater(() -> {
                        SceneManager.switchScene(
                            "/CoffeeShop/view/dashboard.fxml",
                            "☕ Dashboard - Hệ thống quản lý quán cà phê",
                            1200, 700
                        );
                    });
                } catch (InterruptedException e) {
                    logger.severe("❌ Lỗi: " + e.getMessage());
                }
            }).start();
        } else {
            showError("❌ Tên đăng nhập hoặc mật khẩu sai!");
            passwordField.clear();
            logger.warning("⚠️ Đăng nhập thất bại cho: " + username);
        }
    }
    
    /**
     * Kiểm tra dữ liệu nhập vào
     */
    private boolean validateInput(String username, String password) {
        if (ValidationUtil.isEmpty(username)) {
            showError("❌ Vui lòng nhập tên đăng nhập!");
            return false;
        }
        
        if (ValidationUtil.isEmpty(password)) {
            showError("❌ Vui lòng nhập mật khẩu!");
            return false;
        }
        
        if (username.length() < 3) {
            showError("❌ Tên đăng nhập phải có ít nhất 3 ký tự!");
            return false;
        }
        
        if (password.length() < 6) {
            showError("❌ Mật khẩu phải có ít nhất 6 ký tự!");
            return false;
        }
        
        return true;
    }
    
    /**
     * Xác thực người dùng với database
     */
    private boolean authenticateUser(String username, String password) {
        try {
            UserDAO userDAO = new UserDAO();
            int userId = userDAO.authenticate(username, password);
            
            if (userId > 0) {
                currentUsername = username;
                currentUserId = userId;
                
                // Lấy thêm info
                String[] info = userDAO.getUserInfo(username);
                currentRole = info[1];  // role
                
                logger.info("✅ Xác thực từ DB thành công: " + username);
                return true;
            } else {
                logger.warning("❌ Xác thực từ DB thất bại: " + username);
                return false;
            }
            
        } catch (Exception e) {
            logger.severe("❌ Lỗi xác thực: " + e.getMessage());
            showError("❌ Lỗi: " + e.getMessage());
            return false;
        }
    }
    
    /**
     * Xử lý đăng ký tài khoản mới
     */
    @FXML
    private void handleRegister() {
        logger.info("📄 Chuyển sang trang đăng ký");
        SceneManager.switchScene(
            "/CoffeeShop/view/register.fxml",
            "Đăng ký - Coffee Shop Management",
            950, 600
        );
    }
    
    /**
     * Hiển thị thông báo lỗi
     */
    private void showError(String message) {
        messageLabel.setText(message);
        messageLabel.setStyle("-fx-text-fill: #e74c3c; -fx-font-size: 13px;");
    }
    
    /**
     * Hiển thị thông báo thành công
     */
    private void showSuccess(String message) {
        messageLabel.setText(message);
        messageLabel.setStyle("-fx-text-fill: #27ae60; -fx-font-size: 13px;");
    }
    
    // Getters cho session data
    public static String getCurrentUsername() {
        return currentUsername;
    }
    
    public static String getCurrentRole() {
        return currentRole;
    }
    
    public static int getCurrentUserId() {
        return currentUserId;
    }
}

package CoffeeShop;

import java.sql.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

/**
 * Model class cho Product
 * POJO (Plain Old Java Object) với getter/setter
 */
public class Product {
    private int id;
    private String name;
    private String category;
    private double price;
    private int quantity;
    private String description;
    
    // Constructor mặc định
    public Product() {
    }
    
    // Constructor đầy đủ
    public Product(int id, String name, String category, double price, int quantity, String description) {
        this.id = id;
        this.name = name;
        this.category = category;
        this.price = price;
        this.quantity = quantity;
        this.description = description;
    }
    
    // Getters
    public int getId() {
        return id;
    }
    
    public String getName() {
        return name;
    }
    
    public String getCategory() {
        return category;
    }
    
    public double getPrice() {
        return price;
    }
    
    public int getQuantity() {
        return quantity;
    }
    
    public String getDescription() {
        return description;
    }
    
    // Setters
    public void setId(int id) {
        this.id = id;
    }
    
    public void setName(String name) {
        this.name = name;
    }
    
    public void setCategory(String category) {
        this.category = category;
    }
    
    public void setPrice(double price) {
        this.price = price;
    }
    
    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
    
    public void setDescription(String description) {
        this.description = description;
    }
    
    @Override
    public String toString() {
        return "Product{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", category='" + category + '\'' +
                ", price=" + price +
                ", quantity=" + quantity +
                ", description='" + description + '\'' +
                '}';
    }
    
    // ==================== CÁC PHƯƠNG THỨC QUẢN LÝ DATABASE ====================
    
    /**
     * Hiển thị danh sách sản phẩm
     */
    public static void hienThiSanPhamGui(Frame parent) {
        try (Connection con = DBConnection.getConnection();
             PreparedStatement p = con.prepareStatement("SELECT MaSP, TenSP, Loai, Gia FROM SanPham ORDER BY MaSP");
             ResultSet r = p.executeQuery()) {
            DefaultTableModel model = new DefaultTableModel();
            model.addColumn("Mã SP");
            model.addColumn("Tên SP");
            model.addColumn("Loại");
            model.addColumn("Giá");
            
            while (r.next()) {
                model.addRow(new Object[]{
                    r.getInt("MaSP"),
                    r.getString("TenSP"),
                    r.getString("Loai"),
                    String.format("%,.0f đ", r.getBigDecimal("Gia"))
                });
            }
            
            JTable table = new JTable(model);
            table.setRowHeight(25);
            JOptionPane.showMessageDialog(parent, new JScrollPane(table), "Danh sách Sản phẩm", JOptionPane.INFORMATION_MESSAGE);
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(parent, "Lỗi: " + e.getMessage());
        }
    }
    
    /**
     * Thêm sản phẩm mới
     */
    public static void themSanPham(String ten, String giaChuoi, String loai) {
        try (Connection con = DBConnection.getConnection();
             PreparedStatement p = con.prepareStatement("INSERT INTO SanPham(TenSP, Gia, Loai) VALUES(?, ?, ?)")) {
            p.setString(1, ten);
            p.setBigDecimal(2, new java.math.BigDecimal(giaChuoi));
            p.setString(3, loai);
            p.executeUpdate();
            JOptionPane.showMessageDialog(null, "Thêm sản phẩm thành công!");
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Lỗi thêm sản phẩm: " + e.getMessage());
        }
    }
    
    /**
     * Xóa sản phẩm
     */
    public static void xoaSanPham(int id) {
        try (Connection con = DBConnection.getConnection();
             PreparedStatement p = con.prepareStatement("DELETE FROM SanPham WHERE MaSP = ?")) {
            p.setInt(1, id);
            int rows = p.executeUpdate();
            if (rows > 0) {
                JOptionPane.showMessageDialog(null, "Xóa sản phẩm thành công!");
            } else {
                JOptionPane.showMessageDialog(null, "Không tìm thấy sản phẩm!");
            }
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Lỗi xóa sản phẩm: " + e.getMessage());
        }
    }
}
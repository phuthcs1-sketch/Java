package CoffeeShop;

import java.sql.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class Employee {
    public static void hienThiNhanVienGui(Frame parent) {
        try (Connection con = DBConnection.getConnection();
             PreparedStatement p = con.prepareStatement("SELECT MaNV, TenNV, ChucVu, DienThoai, Luong, TrangThai FROM NhanVien ORDER BY MaNV");
             ResultSet r = p.executeQuery()) {
            DefaultTableModel model = new DefaultTableModel() {
                @Override
                public boolean isCellEditable(int row, int column) {
                    return false; // Không cho phép chỉnh sửa trực tiếp
                }
            };
            model.addColumn("Mã NV"); 
            model.addColumn("Tên NV"); 
            model.addColumn("Chức vụ");
            model.addColumn("Điện thoại"); 
            model.addColumn("Lương"); 
            model.addColumn("Trạng thái");
            
            while (r.next()) {
                model.addRow(new Object[] {
                    r.getInt("MaNV"), 
                    r.getString("TenNV"), 
                    r.getString("ChucVu"),
                    r.getString("DienThoai"), 
                    r.getBigDecimal("Luong"), 
                    r.getString("TrangThai")
                });
            }
            
            JTable table = new JTable(model);
            table.setRowHeight(25);
            
            // Thêm nút đổi trạng thái
            JPanel panel = new JPanel(new BorderLayout());
            panel.add(new JScrollPane(table), BorderLayout.CENTER);
            
            JButton btnDoiTrangThai = new JButton("Đổi trạng thái nhân viên");
            btnDoiTrangThai.addActionListener(e -> {
                int selectedRow = table.getSelectedRow();
                if (selectedRow >= 0) {
                    int maNV = (int) table.getValueAt(selectedRow, 0);
                    String tenNV = (String) table.getValueAt(selectedRow, 1);
                    String trangThaiHienTai = (String) table.getValueAt(selectedRow, 5);
                    
                    doiTrangThaiNhanVien(parent, maNV, tenNV, trangThaiHienTai);
                } else {
                    JOptionPane.showMessageDialog(parent, "Vui lòng chọn một nhân viên!");
                }
            });
            
            panel.add(btnDoiTrangThai, BorderLayout.SOUTH);
            
            JOptionPane.showMessageDialog(parent, panel, "Danh sách nhân viên", JOptionPane.INFORMATION_MESSAGE);
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(parent, "Lỗi: " + e.getMessage(), "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void doiTrangThaiNhanVien(Frame parent, int maNV, String tenNV, String trangThaiHienTai) {
        // Tạo combobox với các trạng thái có thể
        String[] trangThaiOptions = {"Đang làm", "Nghỉ", "Nghỉ phép", "Tạm nghỉ"};
        JComboBox<String> cbTrangThai = new JComboBox<>(trangThaiOptions);
        
        // Chọn trạng thái hiện tại nếu có trong danh sách
        for (int i = 0; i < trangThaiOptions.length; i++) {
            if (trangThaiOptions[i].equals(trangThaiHienTai)) {
                cbTrangThai.setSelectedIndex(i);
                break;
            }
        }
        
        Object[] message = {
            "Nhân viên: " + tenNV + " (Mã: " + maNV + ")",
            "Trạng thái hiện tại: " + trangThaiHienTai,
            "Chọn trạng thái mới:",
            cbTrangThai
        };
        
        int option = JOptionPane.showConfirmDialog(parent, message, "Đổi trạng thái nhân viên", 
                JOptionPane.OK_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE);
        
        if (option == JOptionPane.OK_OPTION) {
            String trangThaiMoi = (String) cbTrangThai.getSelectedItem();
            
            if (trangThaiMoi.equals(trangThaiHienTai)) {
                JOptionPane.showMessageDialog(parent, "Trạng thái không thay đổi!");
                return;
            }
            
            try (Connection con = DBConnection.getConnection();
                 PreparedStatement p = con.prepareStatement("UPDATE NhanVien SET TrangThai = ? WHERE MaNV = ?")) {
                p.setString(1, trangThaiMoi);
                p.setInt(2, maNV);
                int result = p.executeUpdate();
                
                if (result > 0) {
                    JOptionPane.showMessageDialog(parent, 
                        "Đã cập nhật trạng thái nhân viên " + tenNV + 
                        "\nTừ: " + trangThaiHienTai + 
                        "\nThành: " + trangThaiMoi,
                        "Thành công", JOptionPane.INFORMATION_MESSAGE);
                } else {
                    JOptionPane.showMessageDialog(parent, "Không tìm thấy nhân viên!", "Lỗi", JOptionPane.ERROR_MESSAGE);
                }
            } catch (Exception e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(parent, "Lỗi cập nhật: " + e.getMessage(), "Lỗi", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    // Phương thức riêng để đổi trạng thái (có thể gọi từ menu)
    public static void doiTrangThaiNhanVienGui(Frame parent) {
        String maNVStr = JOptionPane.showInputDialog(parent, "Nhập mã nhân viên:");
        if (maNVStr == null || maNVStr.trim().isEmpty()) return;
        
        try {
            int maNV = Integer.parseInt(maNVStr.trim());
            
            // Lấy thông tin nhân viên hiện tại
            try (Connection con = DBConnection.getConnection();
                 PreparedStatement p = con.prepareStatement("SELECT TenNV, TrangThai FROM NhanVien WHERE MaNV = ?")) {
                p.setInt(1, maNV);
                try (ResultSet r = p.executeQuery()) {
                    if (r.next()) {
                        String tenNV = r.getString("TenNV");
                        String trangThaiHienTai = r.getString("TrangThai");
                        doiTrangThaiNhanVien(parent, maNV, tenNV, trangThaiHienTai);
                    } else {
                        JOptionPane.showMessageDialog(parent, "Không tìm thấy nhân viên với mã: " + maNV);
                    }
                }
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(parent, "Mã nhân viên phải là số!");
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(parent, "Lỗi: " + e.getMessage());
        }
    }

    public static void themNhanVien(String ten, String chucVu, String dt, String luongStr, String trangThai) {
        try (Connection con = DBConnection.getConnection();
             PreparedStatement p = con.prepareStatement("INSERT INTO NhanVien(TenNV,ChucVu,DienThoai,Luong,TrangThai) VALUES(?,?,?,?,?)")) {
            p.setString(1, ten);
            p.setString(2, chucVu);
            p.setString(3, dt);
            p.setBigDecimal(4, new java.math.BigDecimal(luongStr));
            p.setString(5, trangThai);
            p.executeUpdate();
            JOptionPane.showMessageDialog(null, "Thêm nhân viên thành công!");
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Lỗi thêm NV: " + e.getMessage());
        }
    }

    public static void xoaNhanVien(int id) {
        try (Connection con = DBConnection.getConnection();
             PreparedStatement p = con.prepareStatement("DELETE FROM NhanVien WHERE MaNV=?")) {
            p.setInt(1, id);
            int n = p.executeUpdate();
            JOptionPane.showMessageDialog(null, n>0 ? "Xóa thành công" : "Không tìm thấy");
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Lỗi xóa NV: " + e.getMessage());
        }
    }

    public static void timNhanVien(int id) {
        try (Connection con = DBConnection.getConnection();
             PreparedStatement p = con.prepareStatement("SELECT MaNV,TenNV,ChucVu,DienThoai,Luong,TrangThai FROM NhanVien WHERE MaNV=?")) {
            p.setInt(1, id);
            try (ResultSet r = p.executeQuery()) {
                if (r.next()) {
                    JOptionPane.showMessageDialog(null, 
                        "Mã NV: " + r.getInt("MaNV") + "\n" +
                        "Tên: " + r.getString("TenNV") + "\n" +
                        "Chức vụ: " + r.getString("ChucVu") + "\n" +
                        "Điện thoại: " + r.getString("DienThoai") + "\n" +
                        "Lương: " + r.getBigDecimal("Luong") + "\n" +
                        "Trạng thái: " + r.getString("TrangThai"));
                } else {
                    JOptionPane.showMessageDialog(null, "Không tìm thấy nhân viên");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Lỗi tìm NV: " + e.getMessage());
        }
    }
}
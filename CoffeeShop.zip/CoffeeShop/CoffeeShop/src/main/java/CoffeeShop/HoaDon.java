package CoffeeShop;

import java.sql.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class HoaDon {
    // Thêm Hoá đơn (MaNV, MaKH nullable, MaBan, TongTien)
    public static void themHoaDon(int maNV, Integer maKH, int maBan, java.math.BigDecimal tongTien) {
        try (Connection con = DBConnection.getConnection();
             PreparedStatement p = con.prepareStatement("INSERT INTO HoaDon(MaNV,MaKH,MaBan,NgayLap,TongTien,MaCa) VALUES(?,?,?,?,?,NULL)", Statement.RETURN_GENERATED_KEYS)) {
            p.setInt(1, maNV);
            if (maKH == null) p.setNull(2, Types.INTEGER); else p.setInt(2, maKH);
            p.setInt(3, maBan);
            p.setTimestamp(4, new Timestamp(System.currentTimeMillis()));
            p.setBigDecimal(5, tongTien);
            p.executeUpdate();
            try (ResultSet keys = p.getGeneratedKeys()) {
                if (keys.next()) JOptionPane.showMessageDialog(null, "Tạo hoá đơn MaHD=" + keys.getInt(1));
                else JOptionPane.showMessageDialog(null, "Tạo hoá đơn xong (không lấy được ID)");
            }
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Lỗi tạo hoá đơn: " + e.getMessage());
        }
    }

    // Hiện thị danh sách Hoá đơn kèm tổng (join với KhachHang / NhanVien)
    public static void hienThiHoaDonGui(Frame parent) {
        String sql = "SELECT h.MaHD, h.NgayLap, nv.TenNV AS NhanVien, kh.TenKH AS KhachHang, h.TongTien "
                   + "FROM HoaDon h LEFT JOIN NhanVien nv ON h.MaNV = nv.MaNV LEFT JOIN KhachHang kh ON h.MaKH = kh.MaKH ORDER BY h.NgayLap DESC";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement p = con.prepareStatement(sql);
             ResultSet r = p.executeQuery()) {
            DefaultTableModel model = new DefaultTableModel();
            model.addColumn("MaHD"); model.addColumn("NgayLap"); model.addColumn("NhanVien"); model.addColumn("KhachHang"); model.addColumn("TongTien");
            while (r.next()) model.addRow(new Object[] { r.getInt("MaHD"), r.getTimestamp("NgayLap"), r.getString("NhanVien"), r.getString("KhachHang"), r.getBigDecimal("TongTien") });
            JTable table = new JTable(model);
            JOptionPane.showMessageDialog(parent, new JScrollPane(table), "Danh sách Hoá đơn", JOptionPane.INFORMATION_MESSAGE);
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(parent, "Lỗi: " + e.getMessage());
        }
    }

    public static void hienThiChiTietHoaDonGui(Frame parent, int maHD) {
        String sql = "SELECT c.MaSP, s.TenSP, c.SoLuong, c.DonGia, (c.SoLuong * c.DonGia) AS ThanhTien "
                   + "FROM ChiTietHoaDon c JOIN SanPham s ON c.MaSP = s.MaSP WHERE c.MaHD = ?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement p = con.prepareStatement(sql)) {
            p.setInt(1, maHD);
            try (ResultSet r = p.executeQuery()) {
                DefaultTableModel model = new DefaultTableModel();
                model.addColumn("MaSP"); model.addColumn("TenSP"); model.addColumn("SoLuong"); model.addColumn("DonGia"); model.addColumn("ThanhTien");
                boolean found = false;
                while (r.next()) {
                    found = true;
                    model.addRow(new Object[] { r.getInt("MaSP"), r.getString("TenSP"), r.getInt("SoLuong"), r.getBigDecimal("DonGia"), r.getBigDecimal("ThanhTien") });
                }
                if (!found) { JOptionPane.showMessageDialog(parent, "Không tìm thấy chi tiết cho MaHD=" + maHD); return; }
                JTable table = new JTable(model);
                JOptionPane.showMessageDialog(parent, new JScrollPane(table), "Chi tiết Hoá đơn " + maHD, JOptionPane.INFORMATION_MESSAGE);
            }
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(parent, "Lỗi: " + e.getMessage());
        }
    }
}
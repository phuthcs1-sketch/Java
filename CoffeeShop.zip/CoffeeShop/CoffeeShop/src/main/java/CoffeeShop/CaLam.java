package CoffeeShop;

import java.math.BigDecimal;
import java.time.LocalTime;

public class CaLam {
    private int maCa;
    private String tenCa;
    private LocalTime gioBatDau;
    private LocalTime gioKetThuc;
    private BigDecimal tienCa;

    public CaLam() {}

    public CaLam(int maCa, String tenCa, LocalTime gioBatDau, LocalTime gioKetThuc, BigDecimal tienCa) {
        this.maCa = maCa;
        this.tenCa = tenCa;
        this.gioBatDau = gioBatDau;
        this.gioKetThuc = gioKetThuc;
        this.tienCa = tienCa;
    }

    public int getMaCa() { return maCa; }
    public void setMaCa(int maCa) { this.maCa = maCa; }

    public String getTenCa() { return tenCa; }
    public void setTenCa(String tenCa) { this.tenCa = tenCa; }

    public LocalTime getGioBatDau() { return gioBatDau; }
    public void setGioBatDau(LocalTime gioBatDau) { this.gioBatDau = gioBatDau; }

    public LocalTime getGioKetThuc() { return gioKetThuc; }
    public void setGioKetThuc(LocalTime gioKetThuc) { this.gioKetThuc = gioKetThuc; }

    public BigDecimal getTienCa() { return tienCa; }
    public void setTienCa(BigDecimal tienCa) { this.tienCa = tienCa; }

    @Override
    public String toString() {
        return "CaLam{" + "maCa=" + maCa + ", tenCa='" + tenCa + '\'' + '}';
    }
}
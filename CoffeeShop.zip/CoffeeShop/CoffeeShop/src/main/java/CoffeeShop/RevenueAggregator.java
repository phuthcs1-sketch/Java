package CoffeeShop;

import java.math.BigDecimal;
import java.sql.*;
import java.time.*;
import java.util.Timer;
import java.util.TimerTask;
import javax.swing.JOptionPane;

/**
 * Tổng hợp doanh thu vào bảng DoanhThu.
 */
public class RevenueAggregator {
    // Tổng hợp doanh thu cho ngày 'date'
    public static void aggregateForDate(LocalDate date) throws SQLException {
        String sqlGroup = "SELECT MaCa, MaNV, COUNT(*) AS TongHoaDon, ISNULL(SUM(TongTien),0) AS TongDoanhThu " +
                          "FROM HoaDon WHERE CONVERT(date, NgayLap) = ? GROUP BY MaCa, MaNV";
        try (Connection c = DBConnection.getConnection()) {
            c.setAutoCommit(false);
            try {
                // xóa cũ trước (nếu có) để tránh duplicate
                try (PreparedStatement del = c.prepareStatement("DELETE FROM DoanhThu WHERE Ngay = ?")) {
                    del.setDate(1, java.sql.Date.valueOf(date));
                    del.executeUpdate();
                }

                try (PreparedStatement p = c.prepareStatement(sqlGroup);
                     PreparedStatement ins = c.prepareStatement("INSERT INTO DoanhThu(Ngay,MaCa,MaNV,TongHoaDon,TongDoanhThu) VALUES(?,?,?,?,?)")) {
                    p.setDate(1, java.sql.Date.valueOf(date));
                    try (ResultSet r = p.executeQuery()) {
                        while (r.next()) {
                            Object maCaObj = r.getObject("MaCa");
                            Object maNVObj = r.getObject("MaNV");
                            Integer maCa = maCaObj == null ? null : r.getInt("MaCa");
                            Integer maNV = maNVObj == null ? null : r.getInt("MaNV");
                            int tongHD = r.getInt("TongHoaDon");
                            BigDecimal tongDT = r.getBigDecimal("TongDoanhThu");

                            ins.setDate(1, java.sql.Date.valueOf(date));
                            if (maCa == null) ins.setNull(2, Types.INTEGER); else ins.setInt(2, maCa);
                            if (maNV == null) ins.setNull(3, Types.INTEGER); else ins.setInt(3, maNV);
                            ins.setInt(4, tongHD);
                            ins.setBigDecimal(5, tongDT == null ? BigDecimal.ZERO : tongDT);
                            ins.addBatch();
                        }
                        ins.executeBatch();
                    }
                }

                c.commit();
            } catch (SQLException ex) {
                c.rollback();
                throw ex;
            } finally {
                c.setAutoCommit(true);
            }
        }
    }

    // Lên lịch chạy hàng ngày vào lúc 00:05 (chạy tổng hợp cho ngày trước đó)
    public static void scheduleDailyAggregation() {
        Timer timer = new Timer("RevenueAggregatorTimer", true);

        LocalDateTime tomorrowAt005 = LocalDate.now().plusDays(1).atStartOfDay().plusMinutes(5);
        long initialDelay = Duration.between(LocalDateTime.now(), tomorrowAt005).toMillis();

        long period = Duration.ofDays(1).toMillis();

        timer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                LocalDate dayToAggregate = LocalDate.now().minusDays(1); // tổng hợp cho ngày hôm qua
                try {
                    aggregateForDate(dayToAggregate);
                    System.out.println("Aggregated revenue for " + dayToAggregate);
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        }, initialDelay, period);
    }
}
package CoffeeShop;

import java.sql.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class Attendance {
    // Ghi 1 bản chấm công
    public static void themChamCong(int maNV, int maCa, String ngay /*YYYY-MM-DD*/, String gioVao /*HH:MM:SS*/, String gioRa /*HH:MM:SS or empty*/) {
        try (Connection c = DBConnection.getConnection();
             PreparedStatement p = c.prepareStatement("INSERT INTO ChamCong(MaNV,MaCa,NgayLam,GioVao,GioRa) VALUES(?,?,?,?,?)")) {
            p.setInt(1, maNV);
            p.setInt(2, maCa);
            p.setDate(3, java.sql.Date.valueOf(ngay));
            p.setTime(4, java.sql.Time.valueOf(gioVao));
            if (gioRa == null || gioRa.trim().isEmpty()) p.setNull(5, Types.TIME); else p.setTime(5, java.sql.Time.valueOf(gioRa));
            p.executeUpdate();
            JOptionPane.showMessageDialog(null, "Ghi chấm công OK");
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Lỗi ghi chấm công: " + e.getMessage());
        }
    }

    // Hiển thị chấm công theo ngày (GUI)
    public static void hienThiChamCongGui(Frame parent, String ngay /*YYYY-MM-DD*/) {
        DefaultTableModel model = new DefaultTableModel(new Object[] {"MaCC","MaNV","MaCa","NgayLam","GioVao","GioRa"}, 0);
        String sql = "SELECT MaCC,MaNV,MaCa,NgayLam,GioVao,GioRa FROM ChamCong WHERE NgayLam = ? ORDER BY MaNV";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement p = c.prepareStatement(sql)) {
            p.setDate(1, java.sql.Date.valueOf(ngay));
            try (ResultSet r = p.executeQuery()) {
                while (r.next()) model.addRow(new Object[] { r.getInt(1), r.getInt(2), r.getInt(3), r.getDate(4), r.getTime(5), r.getTime(6) });
            }
            JTable tbl = new JTable(model);
            tbl.setAutoCreateRowSorter(true);
            JOptionPane.showMessageDialog(parent, new JScrollPane(tbl), "Chấm công - " + ngay, JOptionPane.INFORMATION_MESSAGE);
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(parent, "Lỗi lấy chấm công: " + e.getMessage());
        }
    }
}
package CoffeeShop;

import java.sql.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class Ban {
    // Hiển thị danh sách bàn
    public static void hienThiBanGui(Frame parent) {
        try (Connection con = DBConnection.getConnection();
             PreparedStatement p = con.prepareStatement("SELECT MaBan, TenBan, KhuVuc, TrangThai, SoCho, GhiChu FROM Ban ORDER BY MaBan");
             ResultSet r = p.executeQuery()) {
            DefaultTableModel model = new DefaultTableModel();
            model.addColumn("Mã bàn"); 
            model.addColumn("Tên bàn"); 
            model.addColumn("Khu vực"); 
            model.addColumn("Trạng thái");
            model.addColumn("Số chỗ");
            model.addColumn("Ghi chú");
            
            while (r.next()) {
                model.addRow(new Object[] { 
                    r.getInt("MaBan"), 
                    r.getString("TenBan"), 
                    r.getString("KhuVuc"), 
                    r.getString("TrangThai"),
                    r.getInt("SoCho"),
                    r.getString("GhiChu")
                });
            }
            
            JTable table = new JTable(model);
            table.setRowHeight(30);
            
            // Tô màu các dòng theo trạng thái
            table.setDefaultRenderer(Object.class, new javax.swing.table.DefaultTableCellRenderer() {
                @Override
                public Component getTableCellRendererComponent(JTable table, Object value,
                        boolean isSelected, boolean hasFocus, int row, int column) {
                    Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                    
                    String trangThai = (String) table.getModel().getValueAt(row, 3);
                    
                    if (!isSelected) {
                        if ("Trống".equals(trangThai)) {
                            c.setBackground(new Color(220, 255, 220)); // Xanh lá nhạt
                        } else if ("Đang sử dụng".equals(trangThai)) {
                            c.setBackground(new Color(255, 220, 220)); // Đỏ nhạt
                        } else if ("Đặt trước".equals(trangThai)) {
                            c.setBackground(new Color(255, 255, 200)); // Vàng nhạt
                        } else if ("Bảo trì".equals(trangThai)) {
                            c.setBackground(new Color(220, 220, 220)); // Xám
                        } else {
                            c.setBackground(Color.WHITE);
                        }
                    }
                    
                    return c;
                }
            });
            
            JScrollPane scrollPane = new JScrollPane(table);
            scrollPane.setPreferredSize(new Dimension(800, 400));
            JOptionPane.showMessageDialog(parent, scrollPane, "Danh sách Bàn", JOptionPane.INFORMATION_MESSAGE);
            
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(parent, "Lỗi: " + e.getMessage());
        }
    }

    // Thêm bàn mới với đầy đủ thông tin
    public static void themBan(String ten, String khuVuc, String trangThai, int soCho, String ghiChu) {
        try (Connection con = DBConnection.getConnection();
             PreparedStatement p = con.prepareStatement(
                 "INSERT INTO Ban(TenBan, KhuVuc, TrangThai, SoCho, GhiChu) VALUES(?, ?, ?, ?, ?)")) {
            p.setString(1, ten); 
            p.setString(2, khuVuc); 
            p.setString(3, trangThai);
            p.setInt(4, soCho);
            p.setString(5, ghiChu);
            p.executeUpdate();
            JOptionPane.showMessageDialog(null, "Thêm bàn thành công!");
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Lỗi thêm bàn: " + e.getMessage());
        }
    }

    // Xóa bàn
   public static void xoaBan(int id) {
    int option = JOptionPane.showConfirmDialog(null,
        "Bàn đang có hóa đơn. Bạn có muốn đánh dấu là 'Đã xóa' thay vì xóa thật không?\n\n" +
        "Chọn Yes: Đánh dấu 'Đã xóa'\n" +
        "Chọn No: Xóa cả hóa đơn liên quan\n" +
        "Chọn Cancel: Hủy",
        "Xác nhận xóa bàn",
        JOptionPane.YES_NO_CANCEL_OPTION);
    
    if (option == JOptionPane.YES_OPTION) {
        // Đánh dấu là đã xóa (ẩn đi)
        try (Connection con = DBConnection.getConnection();
             PreparedStatement p = con.prepareStatement(
                 "UPDATE Ban SET TrangThai = 'Đã xóa', GhiChu = CONCAT(ISNULL(GhiChu, ''), ' [Đã xóa: ', CONVERT(varchar, GETDATE(), 103), ']') WHERE MaBan = ?")) {
            p.setInt(1, id);
            int n = p.executeUpdate();
            JOptionPane.showMessageDialog(null, 
                n > 0 ? "Đã đánh dấu bàn là 'Đã xóa'" : "Không tìm thấy bàn");
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Lỗi: " + e.getMessage());
        }
    } else if (option == JOptionPane.NO_OPTION) {
        // Xóa cả hóa đơn (dùng phương pháp 1)
        try (Connection con = DBConnection.getConnection()) {
            con.setAutoCommit(false);
            
            try {
                // Xóa chi tiết hóa đơn
                String sql1 = "DELETE FROM ChiTietHoaDon WHERE MaHD IN (SELECT MaHD FROM HoaDon WHERE MaBan = ?)";
                try (PreparedStatement p1 = con.prepareStatement(sql1)) {
                    p1.setInt(1, id);
                    p1.executeUpdate();
                }
                
                // Xóa hóa đơn
                String sql2 = "DELETE FROM HoaDon WHERE MaBan = ?";
                try (PreparedStatement p2 = con.prepareStatement(sql2)) {
                    p2.setInt(1, id);
                    p2.executeUpdate();
                }
                
                // Xóa bàn
                String sql3 = "DELETE FROM Ban WHERE MaBan = ?";
                try (PreparedStatement p3 = con.prepareStatement(sql3)) {
                    p3.setInt(1, id);
                    int n = p3.executeUpdate();
                    
                    con.commit();
                    
                    if (n > 0) {
                        JOptionPane.showMessageDialog(null, "Đã xóa bàn và tất cả hóa đơn liên quan!");
                    } else {
                        JOptionPane.showMessageDialog(null, "Không tìm thấy bàn!");
                    }
                }
            } catch (Exception e) {
                con.rollback();
                throw e;
            } finally {
                con.setAutoCommit(true);
            }
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Lỗi xóa bàn: " + e.getMessage());
        }
    }
    // Nếu Cancel: không làm gì cả
}
    
    // Đổi trạng thái bàn
    public static void doiTrangThaiBan(int maBan, String trangThaiMoi) {
        try (Connection con = DBConnection.getConnection();
             PreparedStatement p = con.prepareStatement(
                 "UPDATE Ban SET TrangThai = ? WHERE MaBan = ?")) {
            p.setString(1, trangThaiMoi);
            p.setInt(2, maBan);
            int n = p.executeUpdate();
            JOptionPane.showMessageDialog(null, 
                n>0 ? "Đã đổi trạng thái bàn thành công" : "Không tìm thấy bàn");
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Lỗi: " + e.getMessage());
        }
    }
    
    // Cập nhật thông tin bàn
    public static void capNhatBan(int maBan, String ten, String khuVuc, String trangThai, int soCho, String ghiChu) {
        try (Connection con = DBConnection.getConnection();
             PreparedStatement p = con.prepareStatement(
                 "UPDATE Ban SET TenBan = ?, KhuVuc = ?, TrangThai = ?, SoCho = ?, GhiChu = ? WHERE MaBan = ?")) {
            p.setString(1, ten);
            p.setString(2, khuVuc);
            p.setString(3, trangThai);
            p.setInt(4, soCho);
            p.setString(5, ghiChu);
            p.setInt(6, maBan);
            int n = p.executeUpdate();
            JOptionPane.showMessageDialog(null, 
                n>0 ? "Cập nhật bàn thành công" : "Không tìm thấy bàn");
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Lỗi cập nhật bàn: " + e.getMessage());
        }
    }
    
    // Lấy danh sách bàn theo trạng thái
    public static void hienThiBanTheoTrangThai(Frame parent, String trangThai) {
        try (Connection con = DBConnection.getConnection();
             PreparedStatement p = con.prepareStatement(
                 "SELECT MaBan, TenBan, KhuVuc, TrangThai, SoCho, GhiChu FROM Ban WHERE TrangThai = ? ORDER BY MaBan")) {
            p.setString(1, trangThai);
            try (ResultSet r = p.executeQuery()) {
                DefaultTableModel model = new DefaultTableModel();
                model.addColumn("Mã bàn"); 
                model.addColumn("Tên bàn"); 
                model.addColumn("Khu vực"); 
                model.addColumn("Trạng thái");
                model.addColumn("Số chỗ");
                model.addColumn("Ghi chú");
                
                while (r.next()) {
                    model.addRow(new Object[] { 
                        r.getInt("MaBan"), 
                        r.getString("TenBan"), 
                        r.getString("KhuVuc"), 
                        r.getString("TrangThai"),
                        r.getInt("SoCho"),
                        r.getString("GhiChu")
                    });
                }
                
                JTable table = new JTable(model);
                table.setRowHeight(30);
                
                // Tô màu các dòng theo trạng thái
                table.setDefaultRenderer(Object.class, new javax.swing.table.DefaultTableCellRenderer() {
                    @Override
                    public Component getTableCellRendererComponent(JTable table, Object value,
                            boolean isSelected, boolean hasFocus, int row, int column) {
                        Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                        
                        String trangThaiCell = (String) table.getModel().getValueAt(row, 3);
                        
                        if (!isSelected) {
                            if ("Trống".equals(trangThaiCell)) {
                                c.setBackground(new Color(220, 255, 220));
                            } else if ("Đang sử dụng".equals(trangThaiCell)) {
                                c.setBackground(new Color(255, 220, 220));
                            } else if ("Đặt trước".equals(trangThaiCell)) {
                                c.setBackground(new Color(255, 255, 200));
                            } else if ("Bảo trì".equals(trangThaiCell)) {
                                c.setBackground(new Color(220, 220, 220));
                            } else {
                                c.setBackground(Color.WHITE);
                            }
                        }
                        
                        return c;
                    }
                });
                
                JScrollPane scrollPane = new JScrollPane(table);
                scrollPane.setPreferredSize(new Dimension(800, 400));
                JOptionPane.showMessageDialog(parent, scrollPane, 
                    "Bàn " + trangThai, JOptionPane.INFORMATION_MESSAGE);
            }
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(parent, "Lỗi: " + e.getMessage());
        }
    }
    
    // Lấy số bàn trống
    public static int demBanTrong() {
        try (Connection con = DBConnection.getConnection();
             PreparedStatement p = con.prepareStatement(
                 "SELECT COUNT(*) FROM Ban WHERE TrangThai = 'Trống'")) {
            try (ResultSet r = p.executeQuery()) {
                if (r.next()) {
                    return r.getInt(1);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }
    
    // Tìm bàn theo tên hoặc khu vực
    public static void timBan(Frame parent, String keyword) {
        try (Connection con = DBConnection.getConnection();
             PreparedStatement p = con.prepareStatement(
                 "SELECT MaBan, TenBan, KhuVuc, TrangThai, SoCho, GhiChu FROM Ban WHERE TenBan LIKE ? OR KhuVuc LIKE ? ORDER BY MaBan")) {
            p.setString(1, "%" + keyword + "%");
            p.setString(2, "%" + keyword + "%");
            try (ResultSet r = p.executeQuery()) {
                DefaultTableModel model = new DefaultTableModel();
                model.addColumn("Mã bàn"); 
                model.addColumn("Tên bàn"); 
                model.addColumn("Khu vực"); 
                model.addColumn("Trạng thái");
                model.addColumn("Số chỗ");
                model.addColumn("Ghi chú");
                
                boolean found = false;
                while (r.next()) {
                    found = true;
                    model.addRow(new Object[] { 
                        r.getInt("MaBan"), 
                        r.getString("TenBan"), 
                        r.getString("KhuVuc"), 
                        r.getString("TrangThai"),
                        r.getInt("SoCho"),
                        r.getString("GhiChu")
                    });
                }
                
                if (found) {
                    JTable table = new JTable(model);
                    table.setRowHeight(30);
                    
                    // Tô màu các dòng theo trạng thái
                    table.setDefaultRenderer(Object.class, new javax.swing.table.DefaultTableCellRenderer() {
                        @Override
                        public Component getTableCellRendererComponent(JTable table, Object value,
                                boolean isSelected, boolean hasFocus, int row, int column) {
                            Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                            
                            String trangThai = (String) table.getModel().getValueAt(row, 3);
                            
                            if (!isSelected) {
                                if ("Trống".equals(trangThai)) {
                                    c.setBackground(new Color(220, 255, 220));
                                } else if ("Đang sử dụng".equals(trangThai)) {
                                    c.setBackground(new Color(255, 220, 220));
                                } else if ("Đặt trước".equals(trangThai)) {
                                    c.setBackground(new Color(255, 255, 200));
                                } else if ("Bảo trì".equals(trangThai)) {
                                    c.setBackground(new Color(220, 220, 220));
                                } else {
                                    c.setBackground(Color.WHITE);
                                }
                            }
                            
                            return c;
                        }
                    });
                    
                    JScrollPane scrollPane = new JScrollPane(table);
                    scrollPane.setPreferredSize(new Dimension(800, 400));
                    JOptionPane.showMessageDialog(parent, scrollPane, 
                        "Kết quả tìm kiếm: " + keyword, JOptionPane.INFORMATION_MESSAGE);
                } else {
                    JOptionPane.showMessageDialog(parent, "Không tìm thấy bàn phù hợp");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(parent, "Lỗi: " + e.getMessage());
        }
    }
}
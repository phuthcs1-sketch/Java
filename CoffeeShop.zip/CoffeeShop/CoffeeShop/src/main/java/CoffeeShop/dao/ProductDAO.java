package CoffeeShop.dao;

import CoffeeShop.Product;
import CoffeeShop.DBConnection;
import CoffeeShop.util.LoggerUtil;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

/**
 * DAO cho bảng Products
 * Xử lý truy vấn sản phẩm
 */
public class ProductDAO {
    
    private static final Logger logger = LoggerUtil.getLogger(ProductDAO.class.getName());
    
    /**
     * Lấy tất cả sản phẩm
     */
    public List<Product> getAllProducts() {
        List<Product> products = new ArrayList<>();
        String query = "SELECT MaSP, TenSP, Loai, Gia FROM SanPham";
        
        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            
            while (rs.next()) {
                Product p = new Product();
                p.setId(rs.getInt("MaSP"));
                p.setName(rs.getString("TenSP"));
                p.setCategory(rs.getString("Loai"));
                p.setPrice(rs.getDouble("Gia"));
                p.setQuantity(0);  // SanPham không có cột quantity
                p.setDescription("");
                products.add(p);
            }
            
            logger.info("✅ Lấy " + products.size() + " sản phẩm từ DB");
            
        } catch (SQLException e) {
            logger.severe("❌ Lỗi lấy products: " + e.getMessage());
            e.printStackTrace();
        }
        
        return products;
    }
    
    /**
     * Lấy sản phẩm theo danh mục
     */
    public List<Product> getProductsByCategory(String category) {
        List<Product> products = new ArrayList<>();
        String query = "SELECT MaSP, TenSP, Loai, Gia FROM SanPham WHERE Loai = ?";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            
            pstmt.setString(1, category);
            
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    Product p = new Product();
                    p.setId(rs.getInt("MaSP"));
                    p.setName(rs.getString("TenSP"));
                    p.setCategory(rs.getString("Loai"));
                    p.setPrice(rs.getDouble("Gia"));
                    p.setQuantity(0);
                    p.setDescription("");
                    products.add(p);
                }
            }
            
            logger.info("✅ Lấy " + products.size() + " sản phẩm từ danh mục: " + category);
            
        } catch (SQLException e) {
            logger.severe("❌ Lỗi lấy products by category: " + e.getMessage());
            e.printStackTrace();
        }
        
        return products;
    }
    
    /**
     * Tìm sản phẩm theo tên
     */
    public List<Product> searchProducts(String keyword) {
        List<Product> products = new ArrayList<>();
        String query = "SELECT MaSP, TenSP, Loai, Gia FROM SanPham WHERE TenSP LIKE ?";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            
            pstmt.setString(1, "%" + keyword + "%");
            
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    Product p = new Product();
                    p.setId(rs.getInt("MaSP"));
                    p.setName(rs.getString("TenSP"));
                    p.setCategory(rs.getString("Loai"));
                    p.setPrice(rs.getDouble("Gia"));
                    p.setQuantity(0);
                    p.setDescription("");
                    products.add(p);
                }
            }
            
            logger.info("✅ Tìm thấy " + products.size() + " sản phẩm với keyword: " + keyword);
            
        } catch (SQLException e) {
            logger.severe("❌ Lỗi tìm products: " + e.getMessage());
            e.printStackTrace();
        }
        
        return products;
    }
    
    /**
     * Đếm tổng số sản phẩm
     */
    public int getTotalProducts() {
        String query = "SELECT COUNT(*) as count FROM SanPham";
        
        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            
            if (rs.next()) {
                return rs.getInt("count");
            }
            
        } catch (SQLException e) {
            logger.severe("❌ Lỗi đếm products: " + e.getMessage());
        }
        
        return 0;
    }
    
    /**
     * Đếm sản phẩm 
     */
    public int getInStockCount() {
        String query = "SELECT COUNT(*) as count FROM SanPham";
        
        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            
            if (rs.next()) {
                return rs.getInt("count");
            }
            
        } catch (SQLException e) {
            logger.severe("❌ Lỗi đếm sản phẩm: " + e.getMessage());
        }
        
        return 0;
    }
    
    /**
     * Tính tổng giá trị hàng
     */
    public double getTotalInventoryValue() {
        String query = "SELECT SUM(Gia) as total FROM SanPham";
        
        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            
            if (rs.next()) {
                double total = rs.getDouble("total");
                return total > 0 ? total : 0;
            }
            
        } catch (SQLException e) {
            logger.severe("❌ Lỗi tính total: " + e.getMessage());
        }
        
        return 0;
    }
    
    /**
     * Thêm sản phẩm mới
     */
    public boolean addProduct(String name, String category, double price) {
        String query = "INSERT INTO SanPham (TenSP, Loai, Gia) VALUES (?, ?, ?)";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            
            pstmt.setString(1, name);
            pstmt.setString(2, category);
            pstmt.setDouble(3, price);
            
            int result = pstmt.executeUpdate();
            if (result > 0) {
                logger.info("✅ Thêm sản phẩm thành công: " + name);
                return true;
            }
            
        } catch (SQLException e) {
            logger.severe("❌ Lỗi thêm product: " + e.getMessage());
            e.printStackTrace();
        }
        
        return false;
    }
    
    /**
     * Cập nhật sản phẩm
     */
    public boolean updateProduct(int id, String name, String category, double price) {
        String query = "UPDATE SanPham SET TenSP = ?, Loai = ?, Gia = ? WHERE MaSP = ?";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            
            pstmt.setString(1, name);
            pstmt.setString(2, category);
            pstmt.setDouble(3, price);
            pstmt.setInt(4, id);
            
            int result = pstmt.executeUpdate();
            if (result > 0) {
                logger.info("✅ Cập nhật sản phẩm thành công: " + name);
                return true;
            }
            
        } catch (SQLException e) {
            logger.severe("❌ Lỗi cập nhật product: " + e.getMessage());
            e.printStackTrace();
        }
        
        return false;
    }
    
    /**
     * Xóa sản phẩm
     */
    public boolean deleteProduct(int id) {
        String query = "DELETE FROM SanPham WHERE MaSP = ?";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            
            pstmt.setInt(1, id);
            
            int result = pstmt.executeUpdate();
            if (result > 0) {
                logger.info("✅ Xóa sản phẩm thành công: ID " + id);
                return true;
            }
            
        } catch (SQLException e) {
            logger.severe("❌ Lỗi xóa product: " + e.getMessage());
            e.printStackTrace();
        }
        
        return false;
    }
}

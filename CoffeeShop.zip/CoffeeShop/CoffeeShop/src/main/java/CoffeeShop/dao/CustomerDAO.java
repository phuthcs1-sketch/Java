package CoffeeShop.dao;

import CoffeeShop.DBConnection;
import CoffeeShop.util.LoggerUtil;
import java.sql.*;
import java.util.*;
import java.util.logging.Logger;

/**
 * DAO cho bảng Customers
 * Xử lý truy vấn liên quan đến khách hàng
 */
public class CustomerDAO {

    private static final Logger logger = LoggerUtil.getLogger(CustomerDAO.class.getName());

    /**
     * Lấy tổng số khách hàng
     */
    public int getTotalCustomers() {
        String sql = "SELECT COUNT(*) as Count FROM KhachHang";

        try (Connection conn = DBConnection.getConnection();
                Statement stmt = conn.createStatement();
                ResultSet rs = stmt.executeQuery(sql)) {

            if (rs.next()) {
                int count = rs.getInt("Count");
                logger.info("✅ Tổng khách hàng: " + count);
                return count;
            }
        } catch (Exception e) {
            logger.severe("❌ Lỗi lấy số lượng khách hàng: " + e.getMessage());
        }

        return 0;
    }

    /**
     * Lấy tất cả khách hàng
     */
    public List<Map<String, Object>> getAllCustomers() {
        List<Map<String, Object>> customers = new ArrayList<>();
        String sql = "SELECT MaKH, TenKH, DienThoai, Email, DiaChi, DiemTich FROM KhachHang ORDER BY MaKH";

        try (Connection conn = DBConnection.getConnection();
                Statement stmt = conn.createStatement();
                ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                Map<String, Object> cust = new HashMap<>();
                cust.put("id", rs.getInt("MaKH"));
                cust.put("name", rs.getString("TenKH"));
                cust.put("phone", rs.getString("DienThoai"));
                cust.put("email", rs.getString("Email"));
                cust.put("address", rs.getString("DiaChi"));
                cust.put("loyalty", rs.getInt("DiemTich"));
                customers.add(cust);
            }
            logger.info("✅ Tải " + customers.size() + " khách hàng");
        } catch (Exception e) {
            logger.severe("❌ Lỗi lấy danh sách khách hàng: " + e.getMessage());
        }

        return customers;
    }

    /**
     * Đếm số hóa đơn của khách hàng
     */
    public int getOrderCount(int customerId) {
        String sql = "SELECT COUNT(*) as cnt FROM HoaDon WHERE MaKH = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, customerId);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) return rs.getInt("cnt");
            }
        } catch (Exception e) {
            logger.severe("❌ Lỗi đếm hóa đơn: " + e.getMessage());
        }

        return 0;
    }

    /**
     * Xóa khách hàng.
     * Nếu khách có hóa đơn, set MaKH = NULL trong HoaDon trước rồi mới xóa.
     */
    public boolean deleteCustomer(int customerId) {
        try (Connection conn = DBConnection.getConnection()) {
            conn.setAutoCommit(false);
            try {
                // Bỏ liên kết hóa đơn trước để tránh FK violation
                String nullifyOrders = "UPDATE HoaDon SET MaKH = NULL WHERE MaKH = ?";
                try (PreparedStatement ps = conn.prepareStatement(nullifyOrders)) {
                    ps.setInt(1, customerId);
                    ps.executeUpdate();
                }

                // Xóa khách hàng
                String deleteSql = "DELETE FROM KhachHang WHERE MaKH = ?";
                try (PreparedStatement ps = conn.prepareStatement(deleteSql)) {
                    ps.setInt(1, customerId);
                    int rows = ps.executeUpdate();
                    if (rows > 0) {
                        conn.commit();
                        logger.info("✅ Xóa khách hàng #" + customerId);
                        return true;
                    }
                }

                conn.rollback();
            } catch (Exception e) {
                conn.rollback();
                logger.severe("❌ Lỗi xóa khách hàng: " + e.getMessage());
            }
        } catch (Exception e) {
            logger.severe("❌ Lỗi kết nối: " + e.getMessage());
        }

        return false;
    }

    /**
     * Cập nhật khách hàng
     */
    public boolean updateCustomer(int id, String name, String phone, String address, String email) {
        String sql = "UPDATE KhachHang SET TenKH = ?, DienThoai = ?, Email = ?, DiaChi = ? WHERE MaKH = ?";

        try (Connection conn = DBConnection.getConnection();
                PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, name);
            pstmt.setString(2, phone);
            pstmt.setString(3, email);
            pstmt.setString(4, address);
            pstmt.setInt(5, id);

            int rows = pstmt.executeUpdate();
            if (rows > 0) {
                logger.info("✅ Cập nhật khách hàng #" + id);
                return true;
            }
        } catch (Exception e) {
            logger.severe("❌ Lỗi cập nhật khách hàng: " + e.getMessage());
        }

        return false;
    }

    /**
     * Thêm khách hàng mới
     */
    public boolean addCustomer(String name, String phone, String address, String email) {
        String sql = "INSERT INTO KhachHang (TenKH, DienThoai, DiaChi, Email, DiemTich) VALUES (?, ?, ?, ?, 0)";

        try (Connection conn = DBConnection.getConnection();
                PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, name);
            pstmt.setString(2, phone);
            pstmt.setString(3, address);
            pstmt.setString(4, email);

            int rows = pstmt.executeUpdate();
            if (rows > 0) {
                logger.info("✅ Thêm khách hàng: " + name);
                return true;
            }
        } catch (Exception e) {
            logger.severe("❌ Lỗi thêm khách hàng: " + e.getMessage());
        }

        return false;
    }
}

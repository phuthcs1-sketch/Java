package CoffeeShop.dao;

import CoffeeShop.DBConnection;
import CoffeeShop.util.LoggerUtil;
import java.sql.*;
import java.time.LocalDateTime;
import java.util.logging.Logger;

/**
 * DAO cho cài đặt hệ thống
 */
public class SettingsDAO {
    
    private static final Logger logger = LoggerUtil.getLogger(SettingsDAO.class.getName());
    
    /**
     * Lấy giá trị setting
     */
    public String getSetting(String key) {
        String query = "SELECT SettingValue FROM Settings WHERE SettingKey = ?";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            
            pstmt.setString(1, key);
            
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getString("SettingValue");
                }
            }
        } catch (SQLException e) {
            logger.severe("❌ Lỗi lấy setting: " + e.getMessage());
        }
        
        return null;
    }
    
    /**
     * Cập nhật setting
     */
    public boolean updateSetting(String key, String value) {
        String checkQuery = "SELECT COUNT(*) as count FROM Settings WHERE SettingKey = ?";
        
        try (Connection conn = DBConnection.getConnection()) {
            // Kiểm tra setting có tồn tại không
            try (PreparedStatement checkStmt = conn.prepareStatement(checkQuery)) {
                checkStmt.setString(1, key);
                ResultSet rs = checkStmt.executeQuery();
                
                boolean exists = false;
                if (rs.next()) {
                    exists = rs.getInt("count") > 0;
                }
                
                if (exists) {
                    // Update
                    String updateQuery = "UPDATE Settings SET SettingValue = ?, UpdatedAt = GETDATE() WHERE SettingKey = ?";
                    try (PreparedStatement updateStmt = conn.prepareStatement(updateQuery)) {
                        updateStmt.setString(1, value);
                        updateStmt.setString(2, key);
                        updateStmt.executeUpdate();
                        logger.info("✅ Cập nhật setting: " + key);
                        return true;
                    }
                } else {
                    // Insert
                    String insertQuery = "INSERT INTO Settings (SettingKey, SettingValue) VALUES (?, ?)";
                    try (PreparedStatement insertStmt = conn.prepareStatement(insertQuery)) {
                        insertStmt.setString(1, key);
                        insertStmt.setString(2, value);
                        insertStmt.executeUpdate();
                        logger.info("✅ Thêm setting: " + key);
                        return true;
                    }
                }
            }
        } catch (SQLException e) {
            logger.severe("❌ Lỗi cập nhật setting: " + e.getMessage());
        }
        
        return false;
    }
    
    /**
     * Lấy thông tin quán
     */
    public String getShopName() {
        return getSetting("SHOP_NAME");
    }
    
    /**
     * Lấy địa chỉ quán
     */
    public String getShopAddress() {
        return getSetting("SHOP_ADDRESS");
    }
    
    /**
     * Lấy số điện thoại quán
     */
    public String getShopPhone() {
        return getSetting("SHOP_PHONE");
    }
    
    /**
     * Lấy email quán
     */
    public String getShopEmail() {
        return getSetting("SHOP_EMAIL");
    }
    
    /**
     * Lấy tỷ lệ chiết khấu mặc định
     */
    public double getDefaultDiscount() {
        String discount = getSetting("DEFAULT_DISCOUNT");
        try {
            return Double.parseDouble(discount != null ? discount : "0");
        } catch (NumberFormatException e) {
            return 0;
        }
    }
    
    /**
     * Lấy độ dài hóa đơn tối đa
     */
    public int getInvoiceRetentionDays() {
        String days = getSetting("INVOICE_RETENTION_DAYS");
        try {
            return Integer.parseInt(days != null ? days : "365");
        } catch (NumberFormatException e) {
            return 365;
        }
    }
    
    /**
     * Kiểm tra debug mode
     */
    public boolean isDebugMode() {
        String debug = getSetting("DEBUG_MODE");
        return "true".equalsIgnoreCase(debug);
    }
    
    /**
     * Xóa cache ứng dụng
     */
    public boolean clearCache() {
        try {
            logger.info("✅ Xóa cache ứng dụng");
            // Có thể thêm logic xóa cache ở đây
            return true;
        } catch (Exception e) {
            logger.severe("❌ Lỗi xóa cache: " + e.getMessage());
            return false;
        }
    }
    
    /**
     * Reset cơ sở dữ liệu (chỉ demo)
     */
    public boolean resetDatabase() {
        logger.warning("⚠️ Reset database - Action này không thể hoàn tác!");
        // Cần xác nhận từ người dùng
        return false;
    }
    
    /**
     * Lấy phiên bản ứng dụng
     */
    public String getAppVersion() {
        return getSetting("APP_VERSION");
    }
}

package CoffeeShop.dao;

import CoffeeShop.DBConnection;
import CoffeeShop.util.LoggerUtil;
import java.sql.*;
import java.util.*;
import java.util.logging.Logger;

/**
 * DAO cho bảng DanhMuc
 * Quản lý danh mục sản phẩm độc lập với SanPham
 */
public class CategoryDAO {

    private static final Logger logger = LoggerUtil.getLogger(CategoryDAO.class.getName());

    /**
     * Lấy tất cả danh mục (từ bảng DanhMuc)
     */
    public List<Map<String, Object>> getAllCategories() {
        List<Map<String, Object>> categories = new ArrayList<>();
        String query = "SELECT MaDM, TenDM FROM DanhMuc ORDER BY TenDM";

        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            while (rs.next()) {
                Map<String, Object> cat = new HashMap<>();
                cat.put("id", rs.getInt("MaDM"));
                cat.put("name", rs.getString("TenDM"));
                categories.add(cat);
            }
            logger.info("✅ Lấy " + categories.size() + " danh mục");
        } catch (SQLException e) {
            logger.severe("❌ Lỗi lấy danh mục: " + e.getMessage());
        }

        return categories;
    }

    /**
     * Thêm danh mục mới
     */
    public boolean addCategory(String name) {
        String query = "INSERT INTO DanhMuc (TenDM) VALUES (?)";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setString(1, name);
            int rows = pstmt.executeUpdate();
            if (rows > 0) {
                logger.info("✅ Thêm danh mục: " + name);
                return true;
            }
        } catch (SQLException e) {
            logger.severe("❌ Lỗi thêm danh mục: " + e.getMessage());
        }

        return false;
    }

    /**
     * Cập nhật danh mục
     */
    public boolean updateCategory(int id, String name) {
        String query = "UPDATE DanhMuc SET TenDM = ? WHERE MaDM = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setString(1, name);
            pstmt.setInt(2, id);
            int rows = pstmt.executeUpdate();
            if (rows > 0) {
                logger.info("✅ Cập nhật danh mục #" + id + " → " + name);
                return true;
            }
        } catch (SQLException e) {
            logger.severe("❌ Lỗi cập nhật danh mục: " + e.getMessage());
        }

        return false;
    }

    /**
     * Xóa danh mục
     */
    public boolean deleteCategory(int id) {
        String query = "DELETE FROM DanhMuc WHERE MaDM = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setInt(1, id);
            int rows = pstmt.executeUpdate();
            if (rows > 0) {
                logger.info("✅ Xóa danh mục #" + id);
                return true;
            }
        } catch (SQLException e) {
            logger.severe("❌ Lỗi xóa danh mục: " + e.getMessage());
        }

        return false;
    }

    /**
     * Kiểm tra danh mục đã tồn tại chưa (không phân biệt hoa thường)
     */
    public boolean categoryExists(String name) {
        String query = "SELECT COUNT(*) as cnt FROM DanhMuc WHERE TenDM = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setString(1, name);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) return rs.getInt("cnt") > 0;
            }
        } catch (SQLException e) {
            logger.severe("❌ Lỗi kiểm tra danh mục: " + e.getMessage());
        }

        return false;
    }

    /**
     * Đếm số sản phẩm trong danh mục (từ SanPham.Loai)
     */
    public int getProductCountInCategory(String categoryName) {
        String query = "SELECT COUNT(*) as count FROM SanPham WHERE Loai = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setString(1, categoryName);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt("count");
                }
            }
        } catch (SQLException e) {
            logger.severe("❌ Lỗi đếm sản phẩm: " + e.getMessage());
        }

        return 0;
    }

    /**
     * Lấy tên tất cả danh mục (dùng cho ComboBox trong form sản phẩm)
     */
    public List<String> getCategoryNames() {
        List<String> names = new ArrayList<>();
        String query = "SELECT TenDM FROM DanhMuc ORDER BY TenDM";

        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            while (rs.next()) {
                names.add(rs.getString("TenDM"));
            }
        } catch (SQLException e) {
            logger.severe("❌ Lỗi lấy tên danh mục: " + e.getMessage());
        }

        return names;
    }
}

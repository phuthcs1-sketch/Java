package CoffeeShop.dao;

import CoffeeShop.DBConnection;
import CoffeeShop.util.LoggerUtil;
import java.sql.*;
import java.time.LocalDate;
import java.util.*;
import java.util.logging.Logger;

/**
 * DAO cho báo cáo doanh thu
 * Xử lý truy vấn doanh thu hàng ngày, tháng, năm từ bảng HoaDon
 */
public class RevenueReportDAO {

    private static final Logger logger = LoggerUtil.getLogger(RevenueReportDAO.class.getName());

    /**
     * Lấy doanh thu của ngày hôm nay
     */
    public double getTodayRevenue() {
        String query = "SELECT ISNULL(SUM(TongTien), 0) as total FROM HoaDon WHERE CAST(NgayLap AS DATE) = CAST(GETDATE() AS DATE)";

        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            if (rs.next()) {
                double total = rs.getDouble("total");
                logger.info("✅ Doanh thu hôm nay: " + total);
                return total;
            }
        } catch (SQLException e) {
            logger.severe("❌ Lỗi lấy doanh thu hôm nay: " + e.getMessage());
        }

        return 0;
    }

    /**
     * Lấy doanh thu theo ngày
     */
    public double getRevenueByDate(LocalDate date) {
        String query = "SELECT ISNULL(SUM(TongTien), 0) as total FROM HoaDon WHERE CAST(NgayLap AS DATE) = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setDate(1, java.sql.Date.valueOf(date));

            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    double total = rs.getDouble("total");
                    logger.info("✅ Doanh thu ngày " + date + ": " + total);
                    return total;
                }
            }
        } catch (SQLException e) {
            logger.severe("❌ Lỗi lấy doanh thu: " + e.getMessage());
        }

        return 0;
    }

    /**
     * Lấy doanh thu theo tháng
     */
    public double getRevenueByMonth(int year, int month) {
        String query = "SELECT ISNULL(SUM(TongTien), 0) as total FROM HoaDon WHERE YEAR(NgayLap) = ? AND MONTH(NgayLap) = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setInt(1, year);
            pstmt.setInt(2, month);

            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    double total = rs.getDouble("total");
                    logger.info("✅ Doanh thu tháng " + month + "/" + year + ": " + total);
                    return total;
                }
            }
        } catch (SQLException e) {
            logger.severe("❌ Lỗi lấy doanh thu tháng: " + e.getMessage());
        }

        return 0;
    }

    /**
     * Lấy doanh thu theo năm
     */
    public double getRevenueByYear(int year) {
        String query = "SELECT ISNULL(SUM(TongTien), 0) as total FROM HoaDon WHERE YEAR(NgayLap) = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setInt(1, year);

            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    double total = rs.getDouble("total");
                    logger.info("✅ Doanh thu năm " + year + ": " + total);
                    return total;
                }
            }
        } catch (SQLException e) {
            logger.severe("❌ Lỗi lấy doanh thu năm: " + e.getMessage());
        }

        return 0;
    }

    /**
     * Lấy doanh thu 7 ngày gần đây
     */
    public List<Map<String, Object>> getLast7DaysRevenue() {
        List<Map<String, Object>> revenues = new ArrayList<>();
        String query = "SELECT TOP 7 CAST(NgayLap AS DATE) as date, " +
                      "SUM(TongTien) as revenue, COUNT(*) as orders " +
                      "FROM HoaDon " +
                      "GROUP BY CAST(NgayLap AS DATE) " +
                      "ORDER BY CAST(NgayLap AS DATE) DESC";

        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            while (rs.next()) {
                Map<String, Object> data = new HashMap<>();
                data.put("date", rs.getDate("date"));
                data.put("revenue", rs.getDouble("revenue"));
                data.put("orders", rs.getInt("orders"));
                revenues.add(data);
            }

            logger.info("✅ Lấy doanh thu 7 ngày: " + revenues.size() + " ngày");
        } catch (SQLException e) {
            logger.severe("❌ Lỗi lấy doanh thu 7 ngày: " + e.getMessage());
        }

        return revenues;
    }

    /**
     * Lấy top 10 sản phẩm bán chạy
     */
    public List<Map<String, Object>> getTopSellingProducts() {
        List<Map<String, Object>> products = new ArrayList<>();
        String query = "SELECT TOP 10 sp.TenSP, sp.Loai, " +
                      "SUM(ctd.SoLuong) as quantity, SUM(ctd.ThanhTien) as total " +
                      "FROM ChiTietHoaDon ctd " +
                      "JOIN SanPham sp ON ctd.MaSP = sp.MaSP " +
                      "GROUP BY sp.MaSP, sp.TenSP, sp.Loai " +
                      "ORDER BY quantity DESC";

        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            while (rs.next()) {
                Map<String, Object> data = new HashMap<>();
                data.put("name", rs.getString("TenSP"));
                data.put("category", rs.getString("Loai"));
                data.put("quantity", rs.getInt("quantity"));
                data.put("total", rs.getDouble("total"));
                products.add(data);
            }

            logger.info("✅ Lấy top 10 sản phẩm bán chạy");
        } catch (SQLException e) {
            logger.severe("❌ Lỗi lấy top products: " + e.getMessage());
        }

        return products;
    }

    /**
     * Lấy doanh thu theo từng ca làm
     */
    public List<Map<String, Object>> getRevenueByShift() {
        List<Map<String, Object>> shifts = new ArrayList<>();
        // Dùng HoaDon join CaLam, bỏ qua hóa đơn không có ca (MaCa IS NULL)
        String query = "SELECT hd.MaCa, cl.GioBatDau, cl.GioKetThuc, " +
                      "COUNT(hd.MaHD) as invoices, SUM(hd.TongTien) as total " +
                      "FROM HoaDon hd " +
                      "JOIN CaLam cl ON hd.MaCa = cl.MaCa " +
                      "GROUP BY hd.MaCa, cl.GioBatDau, cl.GioKetThuc " +
                      "ORDER BY total DESC";

        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            while (rs.next()) {
                Map<String, Object> data = new HashMap<>();
                data.put("shiftId", rs.getInt("MaCa"));
                data.put("startTime", rs.getString("GioBatDau"));
                data.put("endTime", rs.getString("GioKetThuc"));
                data.put("invoices", rs.getInt("invoices"));
                data.put("total", rs.getDouble("total"));
                shifts.add(data);
            }

            logger.info("✅ Lấy doanh thu theo ca làm");
        } catch (SQLException e) {
            logger.severe("❌ Lỗi lấy doanh thu theo ca: " + e.getMessage());
        }

        return shifts;
    }
}

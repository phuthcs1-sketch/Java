package CoffeeShop.dao;

import CoffeeShop.DBConnection;
import CoffeeShop.util.LoggerUtil;
import java.sql.*;
import java.util.*;
import java.util.logging.Logger;

/**
 * DAO cho quản lý bàn ăn
 */
public class TableDAO {
    
    private static final Logger logger = LoggerUtil.getLogger(TableDAO.class.getName());
    
    /**
     * Lấy tất cả bàn
     */
    public List<Map<String, Object>> getAllTables() {
        List<Map<String, Object>> tables = new ArrayList<>();
        String query = "SELECT MaBan, TenBan, KhuVuc, TrangThai, SoCho FROM Ban ORDER BY MaBan";
        
        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            
            while (rs.next()) {
                Map<String, Object> table = new HashMap<>();
                table.put("id", rs.getInt("MaBan"));
                table.put("name", rs.getString("TenBan"));
                table.put("seats", rs.getInt("SoCho"));
                table.put("status", rs.getString("TrangThai"));
                table.put("area", rs.getString("KhuVuc"));
                tables.add(table);
            }
            logger.info("✅ Lấy " + tables.size() + " bàn");
        } catch (SQLException e) {
            logger.severe("❌ Lỗi lấy danh sách bàn: " + e.getMessage());
        }
        
        return tables;
    }
    
    /**
     * Thêm bàn mới
     */
    public boolean addTable(String name, int seats) {
        String query = "INSERT INTO Ban (TenBan, SoCho, TrangThai, KhuVuc) VALUES (?, ?, N'Trống', N'Tầng 1')";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            
            pstmt.setString(1, name);
            pstmt.setInt(2, seats);
            
            int result = pstmt.executeUpdate();
            if (result > 0) {
                logger.info("✅ Thêm bàn: " + name);
                return true;
            }
        } catch (SQLException e) {
            logger.severe("❌ Lỗi thêm bàn: " + e.getMessage());
        }
        
        return false;
    }
    
    /**
     * Cập nhật bàn
     */
    public boolean updateTable(int id, String name, int seats, String status) {
        String query = "UPDATE Ban SET TenBan = ?, SoCho = ?, TrangThai = ? WHERE MaBan = ?";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            
            pstmt.setString(1, name);
            pstmt.setInt(2, seats);
            pstmt.setString(3, status);
            pstmt.setInt(4, id);
            
            int result = pstmt.executeUpdate();
            if (result > 0) {
                logger.info("✅ Cập nhật bàn: " + name);
                return true;
            }
        } catch (SQLException e) {
            logger.severe("❌ Lỗi cập nhật bàn: " + e.getMessage());
        }
        
        return false;
    }
    
    /**
     * Xóa bàn
     */
    public boolean deleteTable(int id) {
        String query = "DELETE FROM Ban WHERE MaBan = ?";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            
            pstmt.setInt(1, id);
            
            int result = pstmt.executeUpdate();
            if (result > 0) {
                logger.info("✅ Xóa bàn #" + id);
                return true;
            }
        } catch (SQLException e) {
            logger.severe("❌ Lỗi xóa bàn: " + e.getMessage());
        }
        
        return false;
    }
    
    /**
     * Thay đổi trạng thái bàn
     */
    public boolean updateTableStatus(int id, String status) {
        String query = "UPDATE Ban SET TrangThai = ? WHERE MaBan = ?";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            
            pstmt.setString(1, status);
            pstmt.setInt(2, id);
            
            int result = pstmt.executeUpdate();
            if (result > 0) {
                logger.info("✅ Cập nhật trạng thái bàn #" + id + ": " + status);
                return true;
            }
        } catch (SQLException e) {
            logger.severe("❌ Lỗi cập nhật trạng thái: " + e.getMessage());
        }
        
        return false;
    }
    
    /**
     * Đếm bàn trống
     */
    public int getAvailableTablesCount() {
        String query = "SELECT COUNT(*) as count FROM Ban WHERE TrangThai = N'Trống'";
        
        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            
            if (rs.next()) {
                return rs.getInt("count");
            }
        } catch (SQLException e) {
            logger.severe("❌ Lỗi đếm bàn trống: " + e.getMessage());
        }
        
        return 0;
    }
}

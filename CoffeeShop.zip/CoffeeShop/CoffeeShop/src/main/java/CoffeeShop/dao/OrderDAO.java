package CoffeeShop.dao;

import java.sql.*;
import java.time.LocalDate;
import java.util.*;
import java.util.logging.Logger;
import CoffeeShop.DBConnection;
import CoffeeShop.util.LoggerUtil;

/**
 * DAO cho quản lý đơn hàng và hóa đơn
 * Kết nối với bảng HoaDon và ChiTietHoaDon
 */
public class OrderDAO {
    private static final Logger logger = LoggerUtil.getLogger(OrderDAO.class.getName());
    
    /**
     * Lấy tất cả hóa đơn kèm tên nhân viên, khách hàng, bàn
     * @param fromDate ngày bắt đầu (null = không giới hạn)
     * @param toDate   ngày kết thúc (null = không giới hạn)
     */
    public List<Map<String, Object>> getAllInvoicesWithNames(LocalDate fromDate, LocalDate toDate) {
        List<Map<String, Object>> invoices = new ArrayList<>();

        StringBuilder sql = new StringBuilder(
            "SELECT hd.MaHD, hd.NgayLap, hd.TongTien, " +
            "ISNULL(nv.TenNV, N'N/A') as TenNV, " +
            "ISNULL(kh.TenKH, N'Khách vãng lai') as TenKH, " +
            "ISNULL(b.TenBan, N'Mang về') as TenBan, " +
            "ISNULL(cl.TenCa, N'N/A') as TenCa " +
            "FROM HoaDon hd " +
            "LEFT JOIN NhanVien  nv ON hd.MaNV  = nv.MaNV " +
            "LEFT JOIN KhachHang kh ON hd.MaKH  = kh.MaKH " +
            "LEFT JOIN Ban        b ON hd.MaBan  = b.MaBan " +
            "LEFT JOIN CaLam     cl ON hd.MaCa   = cl.MaCa " +
            "WHERE 1=1 "
        );
        if (fromDate != null) sql.append("AND CAST(hd.NgayLap AS DATE) >= ? ");
        if (toDate   != null) sql.append("AND CAST(hd.NgayLap AS DATE) <= ? ");
        sql.append("ORDER BY hd.NgayLap DESC");

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql.toString())) {

            int idx = 1;
            if (fromDate != null) pstmt.setDate(idx++, java.sql.Date.valueOf(fromDate));
            if (toDate   != null) pstmt.setDate(idx,   java.sql.Date.valueOf(toDate));

            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    Map<String, Object> inv = new HashMap<>();
                    inv.put("id",       rs.getInt("MaHD"));
                    inv.put("date",     rs.getString("NgayLap"));
                    inv.put("total",    rs.getDouble("TongTien"));
                    inv.put("employee", rs.getString("TenNV"));
                    inv.put("customer", rs.getString("TenKH"));
                    inv.put("table",    rs.getString("TenBan"));
                    inv.put("shift",    rs.getString("TenCa"));
                    invoices.add(inv);
                }
            }
            logger.info("✅ Tải " + invoices.size() + " hóa đơn");
        } catch (Exception e) {
            logger.severe("❌ Lỗi lấy hóa đơn: " + e.getMessage());
        }
        return invoices;
    }

    /**
     * Lấy tất cả đơn hàng
     */
    public List<Map<String, Object>> getAllOrders() {
        List<Map<String, Object>> orders = new ArrayList<>();
        String sql = "SELECT MaHD, MaNV, MaKH, MaBan, NgayLap, TongTien FROM HoaDon ORDER BY NgayLap DESC";
        
        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                Map<String, Object> order = new HashMap<>();
                order.put("orderId", rs.getInt("MaHD"));
                order.put("employeeId", rs.getInt("MaNV"));
                order.put("customerId", rs.getInt("MaKH"));
                order.put("tableId", rs.getInt("MaBan"));
                order.put("date", rs.getString("NgayLap"));
                order.put("total", rs.getDouble("TongTien"));
                orders.add(order);
            }
            logger.info("✅ Tải " + orders.size() + " đơn hàng");
        } catch (Exception e) {
            logger.severe("❌ Lỗi lấy đơn hàng: " + e.getMessage());
        }
        
        return orders;
    }
    
    /**
     * Lấy chi tiết đơn hàng
     */
    public List<Map<String, Object>> getOrderDetails(int orderId) {
        List<Map<String, Object>> details = new ArrayList<>();
        String sql = "SELECT cd.MaSP, sp.TenSP, cd.SoLuong, cd.Gia, cd.ThanhTien " +
                    "FROM ChiTietHoaDon cd " +
                    "JOIN SanPham sp ON cd.MaSP = sp.MaSP " +
                    "WHERE cd.MaHD = ?";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, orderId);
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    Map<String, Object> detail = new HashMap<>();
                    detail.put("productId", rs.getInt("MaSP"));
                    detail.put("productName", rs.getString("TenSP"));
                    detail.put("quantity", rs.getInt("SoLuong"));
                    detail.put("price", rs.getDouble("Gia"));
                    detail.put("total", rs.getDouble("ThanhTien"));
                    details.add(detail);
                }
                logger.info("✅ Tải " + details.size() + " mục trong đơn hàng " + orderId);
            }
        } catch (Exception e) {
            logger.severe("❌ Lỗi lấy chi tiết đơn hàng: " + e.getMessage());
        }
        
        return details;
    }
    
    /**
     * Tạo đơn hàng mới
     * @param customerId null nếu là khách vãng lai
     * @param tableId null nếu là đơn mang về
     */
    public int createOrder(int employeeId, Integer customerId, Integer tableId, double total) {
        String sql = "INSERT INTO HoaDon (MaNV, MaKH, MaBan, NgayLap, TongTien) VALUES (?, ?, ?, GETDATE(), ?)";
        int orderId = -1;

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            pstmt.setInt(1, employeeId);
            if (customerId == null) pstmt.setNull(2, java.sql.Types.INTEGER);
            else pstmt.setInt(2, customerId);
            if (tableId == null) pstmt.setNull(3, java.sql.Types.INTEGER);
            else pstmt.setInt(3, tableId);
            pstmt.setDouble(4, total);
            
            int affectedRows = pstmt.executeUpdate();
            if (affectedRows > 0) {
                try (ResultSet generatedKeys = pstmt.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        orderId = generatedKeys.getInt(1);
                        logger.info("✅ Tạo đơn hàng #" + orderId);
                    }
                }
            }
        } catch (Exception e) {
            logger.severe("❌ Lỗi tạo đơn hàng: " + e.getMessage());
        }
        
        return orderId;
    }
    
    /**
     * Thêm chi tiết vào đơn hàng
     */
    public boolean addOrderDetail(int orderId, int productId, int quantity, double price) {
        String sql = "INSERT INTO ChiTietHoaDon (MaHD, MaSP, SoLuong, Gia, ThanhTien) VALUES (?, ?, ?, ?, ?)";
        double total = quantity * price;
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, orderId);
            pstmt.setInt(2, productId);
            pstmt.setInt(3, quantity);
            pstmt.setDouble(4, price);
            pstmt.setDouble(5, total);
            
            pstmt.executeUpdate();
            logger.info("✅ Thêm sản phẩm #" + productId + " vào đơn hàng #" + orderId);
            return true;
        } catch (Exception e) {
            logger.severe("❌ Lỗi thêm chi tiết đơn hàng: " + e.getMessage());
            return false;
        }
    }
    
    /**
     * Lấy tổng doanh thu
     */
    public double getTotalRevenue() {
        String sql = "SELECT SUM(TongTien) as Total FROM HoaDon";
        
        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            if (rs.next()) {
                double total = rs.getDouble("Total");
                logger.info("✅ Tổng doanh thu: " + total);
                return total;
            }
        } catch (Exception e) {
            logger.severe("❌ Lỗi lấy doanh thu: " + e.getMessage());
        }
        
        return 0;
    }
    
    /**
     * Lấy số lượng đơn hàng
     */
    public int getTotalOrders() {
        String sql = "SELECT COUNT(*) as Count FROM HoaDon";
        
        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            if (rs.next()) {
                int count = rs.getInt("Count");
                logger.info("✅ Tổng đơn hàng: " + count);
                return count;
            }
        } catch (Exception e) {
            logger.severe("❌ Lỗi lấy số lượng đơn hàng: " + e.getMessage());
        }
        
        return 0;
    }
    
    /**
     * Lấy doanh thu theo ngày
     */
    public Map<String, Double> getDailyRevenue(int days) {
        Map<String, Double> revenue = new LinkedHashMap<>();
        String sql = "SELECT CONVERT(DATE, NgayLap) as Date, SUM(TongTien) as Total " +
                    "FROM HoaDon " +
                    "WHERE NgayLap >= DATEADD(DAY, ?, GETDATE()) " +
                    "GROUP BY CONVERT(DATE, NgayLap) " +
                    "ORDER BY Date DESC";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, -days);
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    revenue.put(rs.getString("Date"), rs.getDouble("Total"));
                }
                logger.info("✅ Tải doanh thu " + days + " ngày");
            }
        } catch (Exception e) {
            logger.severe("❌ Lỗi lấy doanh thu theo ngày: " + e.getMessage());
        }
        
        return revenue;
    }
    
    /**
     * Cập nhật trạng thái đơn hàng
     */
    public boolean updateOrderTotal(int orderId, double newTotal) {
        String sql = "UPDATE HoaDon SET TongTien = ? WHERE MaHD = ?";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setDouble(1, newTotal);
            pstmt.setInt(2, orderId);
            
            pstmt.executeUpdate();
            logger.info("✅ Cập nhật tổng tiền đơn hàng #" + orderId);
            return true;
        } catch (Exception e) {
            logger.severe("❌ Lỗi cập nhật đơn hàng: " + e.getMessage());
            return false;
        }
    }
}

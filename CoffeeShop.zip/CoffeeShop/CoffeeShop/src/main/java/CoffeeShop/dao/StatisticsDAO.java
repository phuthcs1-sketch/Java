package CoffeeShop.dao;

import CoffeeShop.DBConnection;
import CoffeeShop.util.LoggerUtil;
import java.sql.*;
import java.util.*;
import java.util.logging.Logger;

/**
 * DAO cho thống kê bán hàng
 * Xử lý truy vấn thống kê các chỉ số kinh doanh từ bảng HoaDon
 */
public class StatisticsDAO {

    private static final Logger logger = LoggerUtil.getLogger(StatisticsDAO.class.getName());

    /**
     * Thống kê hôm nay
     */
    public Map<String, Object> getTodayStatistics() {
        Map<String, Object> stats = new HashMap<>();
        stats.put("revenue", 0.0);
        stats.put("invoices", 0);
        stats.put("products_sold", 0);

        try (Connection conn = DBConnection.getConnection()) {
            // Tổng doanh thu hôm nay từ HoaDon (NgayLap là tên đúng)
            String revenueQuery = "SELECT ISNULL(SUM(TongTien), 0) as total FROM HoaDon " +
                                  "WHERE CAST(NgayLap AS DATE) = CAST(GETDATE() AS DATE)";
            try (Statement stmt = conn.createStatement();
                 ResultSet rs = stmt.executeQuery(revenueQuery)) {
                if (rs.next()) {
                    stats.put("revenue", rs.getDouble("total"));
                }
            }

            // Tổng hóa đơn hôm nay
            String invoiceQuery = "SELECT COUNT(*) as count FROM HoaDon " +
                                  "WHERE CAST(NgayLap AS DATE) = CAST(GETDATE() AS DATE)";
            try (Statement stmt = conn.createStatement();
                 ResultSet rs = stmt.executeQuery(invoiceQuery)) {
                if (rs.next()) {
                    stats.put("invoices", rs.getInt("count"));
                }
            }

            // Tổng sản phẩm bán hôm nay
            String productQuery = "SELECT ISNULL(SUM(ctd.SoLuong), 0) as count " +
                                  "FROM ChiTietHoaDon ctd " +
                                  "JOIN HoaDon hd ON ctd.MaHD = hd.MaHD " +
                                  "WHERE CAST(hd.NgayLap AS DATE) = CAST(GETDATE() AS DATE)";
            try (Statement stmt = conn.createStatement();
                 ResultSet rs = stmt.executeQuery(productQuery)) {
                if (rs.next()) {
                    stats.put("products_sold", rs.getInt("count"));
                }
            }

            logger.info("✅ Lấy thống kê hôm nay");
        } catch (SQLException e) {
            logger.severe("❌ Lỗi lấy thống kê hôm nay: " + e.getMessage());
        }

        return stats;
    }

    /**
     * Thống kê tháng này
     */
    public Map<String, Object> getMonthlyStatistics() {
        Map<String, Object> stats = new HashMap<>();
        stats.put("revenue", 0.0);
        stats.put("invoices", 0);
        stats.put("customers", 0);

        try (Connection conn = DBConnection.getConnection()) {
            // Tổng doanh thu tháng này từ HoaDon
            String revenueQuery = "SELECT ISNULL(SUM(TongTien), 0) as total FROM HoaDon " +
                                  "WHERE YEAR(NgayLap) = YEAR(GETDATE()) AND MONTH(NgayLap) = MONTH(GETDATE())";
            try (Statement stmt = conn.createStatement();
                 ResultSet rs = stmt.executeQuery(revenueQuery)) {
                if (rs.next()) {
                    stats.put("revenue", rs.getDouble("total"));
                }
            }

            // Tổng hóa đơn tháng này
            String invoiceQuery = "SELECT COUNT(*) as count FROM HoaDon " +
                                  "WHERE YEAR(NgayLap) = YEAR(GETDATE()) AND MONTH(NgayLap) = MONTH(GETDATE())";
            try (Statement stmt = conn.createStatement();
                 ResultSet rs = stmt.executeQuery(invoiceQuery)) {
                if (rs.next()) {
                    stats.put("invoices", rs.getInt("count"));
                }
            }

            // Tổng khách hàng có hóa đơn tháng này (MaKH NOT NULL)
            String customerQuery = "SELECT COUNT(DISTINCT MaKH) as count FROM HoaDon " +
                                   "WHERE YEAR(NgayLap) = YEAR(GETDATE()) AND MONTH(NgayLap) = MONTH(GETDATE()) " +
                                   "AND MaKH IS NOT NULL";
            try (Statement stmt = conn.createStatement();
                 ResultSet rs = stmt.executeQuery(customerQuery)) {
                if (rs.next()) {
                    stats.put("customers", rs.getInt("count"));
                }
            }

            logger.info("✅ Lấy thống kê tháng này");
        } catch (SQLException e) {
            logger.severe("❌ Lỗi lấy thống kê tháng: " + e.getMessage());
        }

        return stats;
    }

    /**
     * Tỷ lệ danh mục bán hàng
     */
    public List<Map<String, Object>> getCategoryStatistics() {
        List<Map<String, Object>> categories = new ArrayList<>();
        String query = "SELECT sp.Loai, SUM(ctd.SoLuong) as quantity, SUM(ctd.ThanhTien) as total, " +
                      "CAST(SUM(ctd.SoLuong) * 100.0 / NULLIF((SELECT SUM(SoLuong) FROM ChiTietHoaDon), 0) AS DECIMAL(5, 2)) as percentage " +
                      "FROM ChiTietHoaDon ctd " +
                      "JOIN SanPham sp ON ctd.MaSP = sp.MaSP " +
                      "GROUP BY sp.Loai " +
                      "ORDER BY quantity DESC";

        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            while (rs.next()) {
                Map<String, Object> data = new HashMap<>();
                data.put("category", rs.getString("Loai"));
                data.put("quantity", rs.getInt("quantity"));
                data.put("total", rs.getDouble("total"));
                data.put("percentage", rs.getDouble("percentage"));
                categories.add(data);
            }

            logger.info("✅ Lấy thống kê danh mục: " + categories.size());
        } catch (SQLException e) {
            logger.severe("❌ Lỗi lấy thống kê danh mục: " + e.getMessage());
        }

        return categories;
    }

    /**
     * Thống kê nhân viên bán hàng
     */
    public List<Map<String, Object>> getEmployeeSalesStatistics() {
        List<Map<String, Object>> employees = new ArrayList<>();
        // Dùng LEFT JOIN để hiện tất cả nhân viên kể cả chưa có hóa đơn tháng này
        String query = "SELECT nv.MaNV, nv.TenNV, " +
                      "COUNT(hd.MaHD) as invoices, ISNULL(SUM(hd.TongTien), 0) as total " +
                      "FROM NhanVien nv " +
                      "LEFT JOIN HoaDon hd ON hd.MaNV = nv.MaNV " +
                      "AND YEAR(hd.NgayLap) = YEAR(GETDATE()) AND MONTH(hd.NgayLap) = MONTH(GETDATE()) " +
                      "GROUP BY nv.MaNV, nv.TenNV " +
                      "ORDER BY total DESC";

        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            while (rs.next()) {
                Map<String, Object> data = new HashMap<>();
                data.put("employeeId", rs.getInt("MaNV"));
                data.put("name", rs.getString("TenNV"));
                data.put("invoices", rs.getInt("invoices"));
                data.put("total", rs.getDouble("total"));
                employees.add(data);
            }

            logger.info("✅ Lấy thống kê nhân viên: " + employees.size());
        } catch (SQLException e) {
            logger.severe("❌ Lỗi lấy thống kê nhân viên: " + e.getMessage());
        }

        return employees;
    }

    /**
     * Tỷ lệ thanh toán theo phương thức
     * HoaDon không có cột PhuongThuc nên trả về dữ liệu mặc định "Tiền mặt"
     */
    public List<Map<String, Object>> getPaymentMethodStatistics() {
        List<Map<String, Object>> methods = new ArrayList<>();

        String query = "SELECT ISNULL(SUM(TongTien), 0) as total, COUNT(*) as count FROM HoaDon " +
                       "WHERE YEAR(NgayLap) = YEAR(GETDATE()) AND MONTH(NgayLap) = MONTH(GETDATE())";

        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            if (rs.next()) {
                double total = rs.getDouble("total");
                int count = rs.getInt("count");
                if (count > 0) {
                    Map<String, Object> data = new HashMap<>();
                    data.put("method", "Tiền mặt");
                    data.put("count", count);
                    data.put("total", total);
                    methods.add(data);
                }
            }

            logger.info("✅ Lấy thống kê phương thức thanh toán");
        } catch (SQLException e) {
            logger.severe("❌ Lỗi lấy thống kê thanh toán: " + e.getMessage());
        }

        return methods;
    }
}

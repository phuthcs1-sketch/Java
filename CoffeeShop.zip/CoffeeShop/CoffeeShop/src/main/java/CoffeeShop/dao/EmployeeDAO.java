package CoffeeShop.dao;

import CoffeeShop.DBConnection;
import CoffeeShop.util.LoggerUtil;
import java.sql.*;
import java.util.*;
import java.util.logging.Logger;

/**
 * DAO cho bảng Employees
 * Xử lý truy vấn liên quan đến nhân viên
 */
public class EmployeeDAO {
    
    private static final Logger logger = LoggerUtil.getLogger(EmployeeDAO.class.getName());
    
    /**
     * Lấy tổng số nhân viên
     */
    public int getTotalEmployees() {
        String sql = "SELECT COUNT(*) as Count FROM NhanVien";
        
        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            if (rs.next()) {
                int count = rs.getInt("Count");
                logger.info("✅ Tổng nhân viên: " + count);
                return count;
            }
        } catch (Exception e) {
            logger.severe("❌ Lỗi lấy số lượng nhân viên: " + e.getMessage());
        }
        
        return 0;
    }
    
    /**
     * Lấy tất cả nhân viên
     */
    public List<Map<String, Object>> getAllEmployees() {
        List<Map<String, Object>> employees = new ArrayList<>();
        String sql = "SELECT MaNV, TenNV, ChucVu, DienThoai, Luong, TrangThai FROM NhanVien ORDER BY MaNV";
        
        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                Map<String, Object> emp = new HashMap<>();
                emp.put("id", rs.getInt("MaNV"));
                emp.put("name", rs.getString("TenNV"));
                emp.put("position", rs.getString("ChucVu"));
                emp.put("phone", rs.getString("DienThoai"));
                emp.put("salary", rs.getDouble("Luong"));
                emp.put("status", rs.getString("TrangThai"));
                employees.add(emp);
            }
            logger.info("✅ Tải " + employees.size() + " nhân viên");
        } catch (Exception e) {
            logger.severe("❌ Lỗi lấy danh sách nhân viên: " + e.getMessage());
        }
        
        return employees;
    }
    
    /**
     * Xóa nhân viên
     */
    public boolean deleteEmployee(int employeeId) {
        String sql = "DELETE FROM NhanVien WHERE MaNV = ?";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, employeeId);
            int rows = pstmt.executeUpdate();
            if (rows > 0) {
                logger.info("✅ Xóa nhân viên #" + employeeId);
                return true;
            }
        } catch (Exception e) {
            logger.severe("❌ Lỗi xóa nhân viên: " + e.getMessage());
        }
        
        return false;
    }
    
    /**
     * Cập nhật nhân viên
     */
    public boolean updateEmployee(int id, String name, String position, String phone, double salary, String status) {
        String sql = "UPDATE NhanVien SET TenNV = ?, ChucVu = ?, DienThoai = ?, Luong = ?, TrangThai = ? WHERE MaNV = ?";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, name);
            pstmt.setString(2, position);
            pstmt.setString(3, phone);
            pstmt.setDouble(4, salary);
            pstmt.setString(5, status);
            pstmt.setInt(6, id);
            
            int rows = pstmt.executeUpdate();
            if (rows > 0) {
                logger.info("✅ Cập nhật nhân viên #" + id);
                return true;
            }
        } catch (Exception e) {
            logger.severe("❌ Lỗi cập nhật nhân viên: " + e.getMessage());
        }
        
        return false;
    }
    
    /**
     * Thêm nhân viên mới
     */
    public boolean addEmployee(String name, String position, String phone, double salary, String status) {
        String sql = "INSERT INTO NhanVien (TenNV, ChucVu, DienThoai, Luong, TrangThai) VALUES (?, ?, ?, ?, ?)";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, name);
            pstmt.setString(2, position);
            pstmt.setString(3, phone);
            pstmt.setDouble(4, salary);
            pstmt.setString(5, status);
            
            int rows = pstmt.executeUpdate();
            if (rows > 0) {
                logger.info("✅ Thêm nhân viên: " + name);
                return true;
            }
        } catch (Exception e) {
            logger.severe("❌ Lỗi thêm nhân viên: " + e.getMessage());
        }
        
        return false;
    }
}

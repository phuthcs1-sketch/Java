package CoffeeShop.dao;

import CoffeeShop.DBConnection;
import CoffeeShop.util.LoggerUtil;
import java.sql.*;
import java.time.LocalDate;
import java.util.*;
import java.util.logging.Logger;

/**
 * DAO cho chấm công nhân viên
 * Xử lý truy vấn giờ vào, giờ ra, tính công
 */
public class AttendanceDAO {
    
    private static final Logger logger = LoggerUtil.getLogger(AttendanceDAO.class.getName());
    
    /**
     * Ghi nhận giờ vào
     */
    public boolean checkIn(int employeeId, int shiftId, LocalDate date) {
        String query = "INSERT INTO ChamCong (MaNV, MaCa, NgayLam, GioVao) VALUES (?, ?, ?, GETDATE())";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            
            pstmt.setInt(1, employeeId);
            pstmt.setInt(2, shiftId);
            pstmt.setDate(3, java.sql.Date.valueOf(date));
            
            int result = pstmt.executeUpdate();
            if (result > 0) {
                logger.info("✅ Ghi nhận giờ vào - NV#" + employeeId);
                return true;
            }
        } catch (SQLException e) {
            logger.severe("❌ Lỗi ghi giờ vào: " + e.getMessage());
        }
        
        return false;
    }
    
    /**
     * Ghi nhận giờ ra
     */
    public boolean checkOut(int employeeId, LocalDate date) {
        String query = "UPDATE ChamCong SET GioRa = GETDATE() WHERE MaNV = ? AND CAST(NgayLam AS DATE) = ? AND GioRa IS NULL";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            
            pstmt.setInt(1, employeeId);
            pstmt.setDate(2, java.sql.Date.valueOf(date));
            
            int result = pstmt.executeUpdate();
            if (result > 0) {
                logger.info("✅ Ghi nhận giờ ra - NV#" + employeeId);
                return true;
            }
        } catch (SQLException e) {
            logger.severe("❌ Lỗi ghi giờ ra: " + e.getMessage());
        }
        
        return false;
    }
    
    /**
     * Lấy chấm công theo ngày
     */
    public List<Map<String, Object>> getAttendanceByDate(LocalDate date) {
        List<Map<String, Object>> attendance = new ArrayList<>();
        String query = "SELECT cc.MaCC, nv.MaNV, nv.TenNV, cl.GioBatDau, cl.GioKetThuc, cc.GioVao, cc.GioRa, " +
                      "CASE WHEN cc.GioVao <= cl.GioBatDau THEN N'✓' ELSE N'✗' END as onTime " +
                      "FROM ChamCong cc " +
                      "JOIN NhanVien nv ON cc.MaNV = nv.MaNV " +
                      "JOIN CaLam cl ON cc.MaCa = cl.MaCa " +
                      "WHERE CAST(cc.NgayLam AS DATE) = ? " +
                      "ORDER BY nv.MaNV";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            
            pstmt.setDate(1, java.sql.Date.valueOf(date));
            
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    Map<String, Object> data = new HashMap<>();
                    data.put("id", rs.getInt("MaCC"));
                    data.put("employeeId", rs.getInt("MaNV"));
                    data.put("name", rs.getString("TenNV"));
                    data.put("shiftStart", rs.getString("GioBatDau"));
                    data.put("shiftEnd", rs.getString("GioKetThuc"));
                    data.put("checkIn", rs.getTime("GioVao"));
                    data.put("checkOut", rs.getTime("GioRa"));
                    data.put("onTime", rs.getString("onTime"));
                    attendance.add(data);
                }
            }
            
            logger.info("✅ Lấy chấm công ngày " + date + ": " + attendance.size());
        } catch (SQLException e) {
            logger.severe("❌ Lỗi lấy chấm công: " + e.getMessage());
        }
        
        return attendance;
    }
    
    /**
     * Lấy chấm công của nhân viên trong tháng
     */
    public List<Map<String, Object>> getEmployeeMonthlyAttendance(int employeeId) {
        List<Map<String, Object>> attendance = new ArrayList<>();
        String query = "SELECT CAST(cc.NgayLam AS DATE) as date, cc.GioVao, cc.GioRa, cc.MaCa, " +
                      "CASE WHEN cc.GioVao IS NULL THEN 'Vắng' WHEN cc.GioRa IS NULL THEN 'Chưa ra' ELSE 'Đủ công' END as status " +
                      "FROM ChamCong cc " +
                      "WHERE cc.MaNV = ? AND YEAR(cc.NgayLam) = YEAR(GETDATE()) AND MONTH(cc.NgayLam) = MONTH(GETDATE()) " +
                      "ORDER BY cc.NgayLam DESC";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            
            pstmt.setInt(1, employeeId);
            
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    Map<String, Object> data = new HashMap<>();
                    data.put("date", rs.getDate("date"));
                    data.put("checkIn", rs.getTime("GioVao"));
                    data.put("checkOut", rs.getTime("GioRa"));
                    data.put("shiftId", rs.getInt("MaCa"));
                    data.put("status", rs.getString("status"));
                    attendance.add(data);
                }
            }
            
            logger.info("✅ Lấy chấm công tháng của NV#" + employeeId);
        } catch (SQLException e) {
            logger.severe("❌ Lỗi lấy chấm công nhân viên: " + e.getMessage());
        }
        
        return attendance;
    }
    
    /**
     * Thống kê vắng mặt trong tháng
     */
    public List<Map<String, Object>> getAbsenteeismStatistics() {
        List<Map<String, Object>> stats = new ArrayList<>();
        String query = "SELECT nv.MaNV, nv.TenNV, " +
                      "COUNT(CASE WHEN cc.GioVao IS NULL THEN 1 END) as absent_days, " +
                      "COUNT(CASE WHEN cc.GioVao > cl.GioBatDau THEN 1 END) as late_days " +
                      "FROM NhanVien nv " +
                      "LEFT JOIN ChamCong cc ON nv.MaNV = cc.MaNV " +
                      "LEFT JOIN CaLam cl ON cc.MaCa = cl.MaCa " +
                      "WHERE YEAR(cc.NgayLam) = YEAR(GETDATE()) AND MONTH(cc.NgayLam) = MONTH(GETDATE()) " +
                      "GROUP BY nv.MaNV, nv.TenNV " +
                      "ORDER BY absent_days DESC";
        
        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            
            while (rs.next()) {
                Map<String, Object> data = new HashMap<>();
                data.put("employeeId", rs.getInt("MaNV"));
                data.put("name", rs.getString("TenNV"));
                data.put("absentDays", rs.getInt("absent_days"));
                data.put("lateDays", rs.getInt("late_days"));
                stats.add(data);
            }
            
            logger.info("✅ Lấy thống kê vắng mặt: " + stats.size());
        } catch (SQLException e) {
            logger.severe("❌ Lỗi lấy thống kê vắng: " + e.getMessage());
        }
        
        return stats;
    }
    
    /**
     * Tính tổng công trong tháng
     */
    public int getTotalWorkDaysInMonth(int employeeId) {
        String query = "SELECT COUNT(*) as count FROM ChamCong WHERE MaNV = ? AND GioRa IS NOT NULL " +
                      "AND YEAR(NgayLam) = YEAR(GETDATE()) AND MONTH(NgayLam) = MONTH(GETDATE())";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            
            pstmt.setInt(1, employeeId);
            
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt("count");
                }
            }
        } catch (SQLException e) {
            logger.severe("❌ Lỗi tính tổng công: " + e.getMessage());
        }
        
        return 0;
    }
}

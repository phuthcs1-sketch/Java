package CoffeeShop.dao;

import CoffeeShop.DBConnection;
import CoffeeShop.util.LoggerUtil;
import java.sql.*;
import java.util.logging.Logger;

/**
 * DAO cho bảng Users
 * Xử lý truy vấn liên quan đến người dùng
 */
public class UserDAO {
    
    private static final Logger logger = LoggerUtil.getLogger(UserDAO.class.getName());
    
    /**
     * Xác thực người dùng
     * @param username Tên đăng nhập
     * @param password Mật khẩu
     * @return User ID nếu thành công, -1 nếu thất bại
     */
    public int authenticate(String username, String password) {
        String query = "SELECT UserId, Role FROM USERS WHERE Username = ? AND Password = ?";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            
            pstmt.setString(1, username);
            pstmt.setString(2, password);
            
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    int userId = rs.getInt("UserId");
                    String role = rs.getString("Role");
                    logger.info("✅ Xác thực thành công: " + username + " (Role: " + role + ")");
                    return userId;
                }
            }
            
            logger.warning("❌ Xác thực thất bại: " + username);
            return -1;
            
        } catch (SQLException e) {
            logger.severe("❌ Lỗi xác thực: " + e.getMessage());
            e.printStackTrace();
            return -1;
        }
    }
    
    /**
     * Lấy tên và role người dùng
     */
    public String[] getUserInfo(String username) {
        String query = "SELECT Username, Role FROM USERS WHERE Username = ?";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            
            pstmt.setString(1, username);
            
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return new String[] {
                        rs.getString("Username"),
                        rs.getString("Role")
                    };
                }
            }
            
        } catch (SQLException e) {
            logger.severe("❌ Lỗi lấy info: " + e.getMessage());
            e.printStackTrace();
        }
        
        return new String[] {"Unknown", "employee"};
    }
    
    /**
     * Đếm tổng số nhân viên
     */
    public int getTotalUsers() {
        String query = "SELECT COUNT(*) as count FROM NhanVien WHERE TrangThai = N'Dang lam'";
        
        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            
            if (rs.next()) {
                return rs.getInt("count");
            }
            
        } catch (SQLException e) {
            logger.severe("❌ Lỗi đếm users: " + e.getMessage());
        }
        
        return 0;
    }
    
    /**
     * Tạo người dùng mới
     */
    public boolean createUser(String username, String password, String role) {
        String query = "INSERT INTO USERS (Username, Password, Role) VALUES (?, ?, ?)";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            
            pstmt.setString(1, username);
            pstmt.setString(2, password);
            pstmt.setString(3, role);
            
            int result = pstmt.executeUpdate();
            if (result > 0) {
                logger.info("✅ Tạo user thành công: " + username);
                return true;
            }
            
        } catch (SQLException e) {
            logger.severe("❌ Lỗi tạo user: " + e.getMessage());
            e.printStackTrace();
        }
        
        return false;
    }
}

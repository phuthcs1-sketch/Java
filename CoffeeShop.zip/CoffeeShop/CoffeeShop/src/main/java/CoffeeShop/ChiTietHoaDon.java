package CoffeeShop;

import java.sql.*;
import javax.swing.*;

public class ChiTietHoaDon {
    public static void themChiTiet(int maHD, int maSP, int soLuong, java.math.BigDecimal donGia) {
        try (Connection con = DBConnection.getConnection();
             PreparedStatement p = con.prepareStatement("INSERT INTO ChiTietHoaDon(MaHD,MaSP,SoLuong,DonGia) VALUES(?,?,?,?)")) {
            p.setInt(1, maHD);
            p.setInt(2, maSP);
            p.setInt(3, soLuong);
            p.setBigDecimal(4, donGia);
            p.executeUpdate();
            JOptionPane.showMessageDialog(null, "Thêm chi tiết hóa đơn OK");
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Lỗi thêm chi tiết: " + e.getMessage());
        }
    }
}
package CoffeeShop;

import java.sql.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.math.BigDecimal;

public class DoanhThu {
    public static void hienThiDoanhThuGui(Frame parent) {
        try (Connection con = DBConnection.getConnection();
             PreparedStatement p = con.prepareStatement("SELECT MaDT, Ngay, MaCa, MaNV, TongHoaDon, TongDoanhThu FROM DoanhThu ORDER BY Ngay DESC");
             ResultSet r = p.executeQuery()) {
            DefaultTableModel model = new DefaultTableModel();
            model.addColumn("MaDT"); model.addColumn("Ngay"); model.addColumn("MaCa"); model.addColumn("MaNV"); model.addColumn("TongHoaDon"); model.addColumn("TongDoanhThu");
            while (r.next()) model.addRow(new Object[] { r.getInt("MaDT"), r.getDate("Ngay"), r.getInt("MaCa"), r.getInt("MaNV"), r.getInt("TongHoaDon"), r.getBigDecimal("TongDoanhThu") });
            JOptionPane.showMessageDialog(parent, new JScrollPane(new javax.swing.JTable(model)), "Doanh thu", JOptionPane.INFORMATION_MESSAGE);
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(parent, "Lỗi: " + e.getMessage());
        }
    }

    public static void themDoanhThu(String ngayStr, int tongHD, String tongDoanhThuStr) {
        try (Connection con = DBConnection.getConnection();
             PreparedStatement p = con.prepareStatement("INSERT INTO DoanhThu(Ngay,MaCa,MaNV,TongHoaDon,TongDoanhThu) VALUES(?,?,?,?,?)")) {
            // Note: caller must supply MaCa and MaNV separately in full app; here we store minimal demo (MaCa= NULL, MaNV=NULL)
            p.setDate(1, java.sql.Date.valueOf(ngayStr));
            p.setNull(2, Types.INTEGER);
            p.setNull(3, Types.INTEGER);
            p.setInt(4, tongHD);
            p.setBigDecimal(5, new BigDecimal(tongDoanhThuStr));
            p.executeUpdate();
            JOptionPane.showMessageDialog(null, "Thêm doanh thu OK");
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Lỗi thêm doanh thu: " + e.getMessage());
        }
    }

    public static void xoaDoanhThu(int id) {
        try (Connection con = DBConnection.getConnection();
             PreparedStatement p = con.prepareStatement("DELETE FROM DoanhThu WHERE MaDT=?")) {
            p.setInt(1, id); int n = p.executeUpdate();
            JOptionPane.showMessageDialog(null, n>0 ? "Xóa OK" : "Không tìm thấy");
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Lỗi xóa: " + e.getMessage());
        }
    }

    public static void timDoanhThuTheoNgayGui(Frame parent, String ngayStr) {
        try (Connection con = DBConnection.getConnection();
             PreparedStatement p = con.prepareStatement("SELECT MaDT, Ngay, MaCa, MaNV, TongHoaDon, TongDoanhThu FROM DoanhThu WHERE Ngay = ?")) {
            p.setDate(1, java.sql.Date.valueOf(ngayStr));
            try (ResultSet r = p.executeQuery()) {
                DefaultTableModel model = new DefaultTableModel();
                model.addColumn("MaDT"); model.addColumn("Ngay"); model.addColumn("MaCa"); model.addColumn("MaNV"); model.addColumn("TongHoaDon"); model.addColumn("TongDoanhThu");
                boolean found = false;
                while (r.next()) { found = true; model.addRow(new Object[] { r.getInt("MaDT"), r.getDate("Ngay"), r.getInt("MaCa"), r.getInt("MaNV"), r.getInt("TongHoaDon"), r.getBigDecimal("TongDoanhThu") }); }
                if (!found) { JOptionPane.showMessageDialog(parent, "Không tìm thấy doanh thu ngày: " + ngayStr); return; }
                JOptionPane.showMessageDialog(parent, new JScrollPane(new javax.swing.JTable(model)), "Kết quả", JOptionPane.INFORMATION_MESSAGE);
            }
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(parent, "Lỗi: " + e.getMessage());
        }
    }
}
package CoffeeShop;

/**
 * Model để lưu trữ thông tin một item trong giỏ hàng
 */
public class CartItem {
    private int productId;
    private String productName;
    private double price;
    private int quantity;
    
    public CartItem(int productId, String productName, double price, int quantity) {
        this.productId = productId;
        this.productName = productName;
        this.price = price;
        this.quantity = quantity;
    }
    
    // Getters and Setters
    public int getProductId() {
        return productId;
    }
    
    public void setProductId(int productId) {
        this.productId = productId;
    }
    
    public String getProductName() {
        return productName;
    }
    
    public void setProductName(String productName) {
        this.productName = productName;
    }
    
    public double getPrice() {
        return price;
    }
    
    public void setPrice(double price) {
        this.price = price;
    }
    
    public int getQuantity() {
        return quantity;
    }
    
    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
    
    /**
     * Tính thành tiền của item
     */
    public double getTotal() {
        return price * quantity;
    }
    
    @Override
    public String toString() {
        return productName + " x" + quantity + " = " + String.format("%.0f ₫", getTotal());
    }
}

package CoffeeShop;

import javax.swing.*;
import java.awt.*;
import java.sql.*;

public class LoginDialog extends JDialog {
    private final JTextField txtUser = new JTextField();
    private final JPasswordField txtPass = new JPasswordField();
    private final JComboBox<String> cmbRole = new JComboBox<>(new String[] {"employee", "admin"});

    private boolean authenticated = false;
    private String authenticatedUser;
    private String authenticatedRole;
    private int authenticatedMaNV = -1;

    public LoginDialog(Frame owner) {
        super(owner, "Login", true);
        initUI();
        pack();
        setLocationRelativeTo(owner);
    }

    private void initUI() {
        JPanel p = new JPanel(new BorderLayout(6,6));
        JPanel f = new JPanel(new GridLayout(3,2,6,6));
        f.add(new JLabel("Username:")); f.add(txtUser);
        f.add(new JLabel("Password:")); f.add(txtPass);
        f.add(new JLabel("Role:")); f.add(cmbRole);
        p.add(f, BorderLayout.CENTER);

        JPanel btns = new JPanel();
        JButton bLogin = new JButton("Login"); 
        JButton bReg = new JButton("Regist"); 
        JButton bExit = new JButton("Exit");
        btns.add(bLogin); btns.add(bReg); btns.add(bExit);
        p.add(btns, BorderLayout.SOUTH);
        setContentPane(p);

        bExit.addActionListener(e -> { authenticated = false; dispose(); });
        bLogin.addActionListener(e -> doLogin());
        bReg.addActionListener(e -> doRegister());
    }

    private void doLogin() {
        String username = txtUser.getText().trim();
        String password = new String(txtPass.getPassword());
        String selectedRole = (String) cmbRole.getSelectedItem();
        
        if (username.isEmpty() || password.isEmpty()) { 
            JOptionPane.showMessageDialog(this, "Nhập username và password"); 
            return; 
        }

        boolean ok = false;
        try (Connection con = DBConnection.getConnection();
             PreparedStatement st = con.prepareStatement(
                 "SELECT Username, Password, Role FROM USERS WHERE Username = ? AND Password = ?")) {
            st.setString(1, username);
            st.setString(2, password);
            
            try (ResultSet r = st.executeQuery()) {
                if (r.next()) {
                    String dbRole = r.getString("Role");
                    if (dbRole.equalsIgnoreCase(selectedRole)) {
                        ok = true;
                        authenticatedRole = dbRole;
                        
                        // Tìm MaNV từ bảng NhanVien dựa trên username
                        try (PreparedStatement empSt = con.prepareStatement(
                             "SELECT MaNV FROM NhanVien WHERE TenNV LIKE ?")) {
                            empSt.setString(1, "%" + username + "%");
                            try (ResultSet empRs = empSt.executeQuery()) {
                                if (empRs.next()) {
                                    authenticatedMaNV = empRs.getInt("MaNV");
                                }
                            }
                        }
                    } else {
                        JOptionPane.showMessageDialog(this, "Role không khớp! Vui lòng chọn đúng role.");
                        return;
                    }
                }
            }
        } catch (Exception ex) { 
            ex.printStackTrace(); 
        }

        // fallback admin/admin
        if (!ok && "admin".equals(username) && "admin".equals(password) && "admin".equalsIgnoreCase(selectedRole)) {
            ok = true; 
            authenticatedRole = "admin";
            authenticatedMaNV = -1;
        }

        if (ok) {
            authenticated = true; 
            authenticatedUser = username; 
            
            // Nếu là employee nhưng không tìm thấy MaNV, hiển thị cảnh báo
            if ("employee".equals(authenticatedRole) && authenticatedMaNV == -1) {
                JOptionPane.showMessageDialog(this, 
                    "Không tìm thấy mã nhân viên. Một số chức năng có thể bị hạn chế.");
            }
            
            dispose();
        } else {
            JOptionPane.showMessageDialog(this, "Đăng nhập thất bại. Kiểm tra username/password.");
            txtPass.setText("");
        }
    }

    private void doRegister() {
        String username = txtUser.getText().trim();
        String password = new String(txtPass.getPassword());
        String role = (String) cmbRole.getSelectedItem();
        
        if (username.isEmpty() || password.isEmpty()) { 
            JOptionPane.showMessageDialog(this, "Nhập username và password"); 
            return; 
        }
        
        // Nếu đăng ký employee, kiểm tra có nhân viên trong hệ thống không
        if ("employee".equals(role)) {
            try (Connection con = DBConnection.getConnection();
                 PreparedStatement checkSt = con.prepareStatement(
                     "SELECT MaNV, TenNV FROM NhanVien WHERE TenNV LIKE ?")) {
                checkSt.setString(1, "%" + username + "%");
                
                try (ResultSet rs = checkSt.executeQuery()) {
                    if (!rs.next()) {
                        int option = JOptionPane.showConfirmDialog(this, 
                            "Không tìm thấy nhân viên '" + username + "' trong hệ thống.\n" +
                            "Bạn có muốn tạo tài khoản admin thay vì employee không?",
                            "Xác nhận", JOptionPane.YES_NO_OPTION);
                        
                        if (option == JOptionPane.YES_OPTION) {
                            role = "admin";
                        } else {
                            JOptionPane.showMessageDialog(this, 
                                "Vui lòng thêm nhân viên vào hệ thống trước khi đăng ký tài khoản employee.");
                            return;
                        }
                    }
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
        
        try (Connection con = DBConnection.getConnection();
             PreparedStatement st = con.prepareStatement(
                 "INSERT INTO USERS(Username, Password, Role) VALUES(?, ?, ?)")) {
            st.setString(1, username); 
            st.setString(2, password); 
            st.setString(3, role);
            st.executeUpdate();
            JOptionPane.showMessageDialog(this, "Đăng ký thành công!");
        } catch (SQLException ex) {
            if (ex.getMessage().contains("PRIMARY KEY") || ex.getMessage().contains("duplicate")) {
                JOptionPane.showMessageDialog(this, "Username đã tồn tại!");
            } else {
                JOptionPane.showMessageDialog(this, "Lỗi đăng ký: " + ex.getMessage());
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public boolean isAuthenticated() { return authenticated; }
    public String getAuthenticatedUser() { return authenticatedUser; }
    public String getAuthenticatedRole() { return authenticatedRole; }
    public int getAuthenticatedMaNV() { return authenticatedMaNV; }
}
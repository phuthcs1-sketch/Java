package CoffeeShop;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Rectangle2D;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.stage.Screen;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import CoffeeShop.util.LoggerUtil;
import CoffeeShop.util.SceneManager;
import java.util.logging.Logger;

/**
 * Coffee Shop Management System - JavaFX Application
 * Giao diện hiện đại với JavaFX 26
 * Color Theme: Coffee Brown (#6f4e37), Warm Gold (#d4a574), Clean White (#faf8f7)
 */
public class CoffeeShopApplication extends Application {
    
    private static final Logger logger = LoggerUtil.getLogger(CoffeeShopApplication.class.getName());
    
    @Override
    public void start(Stage primaryStage) throws Exception {
        try {
            logger.info("☕ Khởi động ứng dụng quản lý quán cà phê JavaFX");
            
            // Set primary stage
            SceneManager.setPrimaryStage(primaryStage);

            // Load Login FXML
            FXMLLoader loader = new FXMLLoader(
                getClass().getResource("/CoffeeShop/view/login.fxml")
            );
            
            Scene loginScene = new Scene(loader.load(), 1000, 650);
            
            // Thêm CSS stylesheet
            String css = getClass().getResource("/CoffeeShop/style/style.css").toExternalForm();
            loginScene.getStylesheets().add(css);
            
            // Configure primary stage
            primaryStage.setScene(loginScene);
            primaryStage.setTitle("☕ Coffee Shop Management System");
            primaryStage.setWidth(1000);
            primaryStage.setHeight(650);
            primaryStage.setResizable(true);
            primaryStage.setMinWidth(800);
            primaryStage.setMinHeight(600);
            
            // Center on screen
            Rectangle2D screenBounds = Screen.getPrimary().getVisualBounds();
            primaryStage.setX((screenBounds.getWidth() - 1000) / 2);
            primaryStage.setY((screenBounds.getHeight() - 650) / 2);
            
            // Set application icon (nếu có)
            try {
                // primaryStage.getIcons().add(new Image(getClass().getResourceAsStream("/CoffeeShop/assets/icon.png")));
            } catch (Exception e) {
                logger.info("⚠️ Không tìm thấy icon");
            }
            
            primaryStage.show();
            
            logger.info("✅ Ứng dụng JavaFX khởi động thành công");
            
        } catch (Exception e) {
            logger.severe("❌ Lỗi khởi động ứng dụng: " + e.getMessage());
            e.printStackTrace();
            throw e;
        }
    }
    
    public static void main(String[] args) {
        logger.info("📋 Đang tải ứng dụng JavaFX Coffee Shop...");
        launch(args);
    }
}

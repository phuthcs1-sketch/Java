package CoffeeShop;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.math.BigDecimal;
import java.time.format.DateTimeFormatter;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.io.File;

public class MainCafeSwing extends JFrame {
    private JTable tblCategories;
    private DefaultTableModel catModel;
    private JPanel productsPanel;
    private DefaultTableModel cartModel;
    private JLabel lblTotal;
    private JLabel lblUser;
    private BigDecimal total = BigDecimal.ZERO;
    private JLabel backgroundLabel;
    private ImageIcon backgroundImage;

    // Menu items
    private JMenuItem miThemSP, miXoaSP;
    private JMenuItem miThemKH, miXoaKH;
    private JMenuItem miThemNV, miXoaNV;
    private JMenuItem miThemBan, miXoaBan;
    private JMenuItem miThemCa, miXoaCa;
    private JMenuItem miThemDT, miXoaDT;
    private JMenuItem miThemHD, miThemSPvaoHD;
    private JMenuItem miChamCong;
    private JMenuItem miTongHopDoanhThu;
    private JMenuItem miHienSP, miHienKH, miHienNV, miHienBan, miHienCa, miHienDT, miHienHD, miHienChamCong;
    private JMenuItem miXemDiem;
    
    // Thêm các menu item mới cho Bàn
    private JMenuItem miCapNhatBan, miTimBan, miDoiTTBan, miBanTrong, miBanDangSD, miBanDatTruoc, miSoDoBan;
    
    // Thêm menu item mới cho đổi trạng thái nhân viên
    private JMenuItem miDoiTTNV;

    private String currentUser = null;
    private String currentRole = null;
    private int currentMaNV = -1;

    // Biến cho Dashboard Admin
    private JPanel adminDashboardPanel;

    public MainCafeSwing() {
        super("Hệ thống quản lý quán cà phê");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(1100, 720);
        setLocationRelativeTo(null);
        
        // Khởi tạo backgroundLabel với màu nền mặc định
        backgroundLabel = new JLabel();
        backgroundLabel.setBackground(new Color(240, 245, 250));
        backgroundLabel.setOpaque(true);
        backgroundLabel.setLayout(new BorderLayout());
        setContentPane(backgroundLabel);
        
        initUI();
        doLogin();
        if (currentUser == null) System.exit(0);
        applyRolePermissions();
        setVisible(true);
    }
    
    private void setupBackground(boolean showBackground) {
        try {
            if (showBackground) {
                // Employee UI: CÓ background hình ảnh
                String imagePath = "C:\\Users\\PHU\\Desktop\\hinh-nen-may-tinh-chill-7.jpeg";
                
                File file = new File(imagePath);
                if (!file.exists()) {
                    // Thử tìm trong thư mục project
                    imagePath = "hinh-nen-may-tinh-chill-7.jpeg";
                    file = new File(imagePath);
                    
                    if (!file.exists()) {
                        throw new Exception("Không tìm thấy file hình nền. Đặt file tại: " + 
                            "1. C:\\Users\\PHU\\Desktop\\hinh-nen-may-tinh-chill-7.jpeg\n" +
                            "2. Hoặc trong thư mục project với tên: hinh-nen-may-tinh-chill-7.jpeg");
                    }
                }
                
                System.out.println("Đang load hình nền từ: " + file.getAbsolutePath());
                
                // Load hình ảnh
                backgroundImage = new ImageIcon(file.getAbsolutePath());
                
                // Scale hình ảnh
                Image scaledImage = backgroundImage.getImage().getScaledInstance(
                    getWidth(), getHeight(), Image.SCALE_SMOOTH
                );
                backgroundImage = new ImageIcon(scaledImage);
                
                // Tạo JLabel với hình nền
                backgroundLabel = new JLabel(backgroundImage);
                backgroundLabel.setLayout(new BorderLayout());
                
                // Đặt JLabel làm contentPane
                setContentPane(backgroundLabel);
                
            } else {
                // Dashboard Admin: màu nền mặc định
                backgroundLabel = new JLabel();
                backgroundLabel.setBackground(new Color(240, 245, 250));
                backgroundLabel.setOpaque(true);
                backgroundLabel.setLayout(new BorderLayout());
                setContentPane(backgroundLabel);
            }
            
        } catch (Exception e) {
            System.err.println("Lỗi khi đặt background: " + e.getMessage());
            e.printStackTrace();
            
            // màu nền mặc định
            backgroundLabel = new JLabel();
            backgroundLabel.setBackground(new Color(240, 245, 250));
            backgroundLabel.setOpaque(true);
            backgroundLabel.setLayout(new BorderLayout());
            setContentPane(backgroundLabel);
        }
    }
    
    private void initUI() {
        initMenuBar();
        initCommonComponents();
    }

    private void initMenuBar() {
        JMenuBar menuBar = new JMenuBar();

        // Menu Sản phẩm
        JMenu mnSP = new JMenu("Sản phẩm");
        miHienSP = new JMenuItem("Hiển thị");
        miThemSP = new JMenuItem("Thêm");
        miXoaSP = new JMenuItem("Xóa");
        mnSP.add(miHienSP); mnSP.add(miThemSP); mnSP.add(miXoaSP);

        // Menu Khách hàng
        JMenu mnKH = new JMenu("Khách hàng");
        miHienKH = new JMenuItem("Hiển thị");
        miThemKH = new JMenuItem("Thêm");
        miXoaKH = new JMenuItem("Xóa");
        miXemDiem = new JMenuItem("Xem/Đổi điểm");
        mnKH.add(miHienKH); mnKH.add(miThemKH); mnKH.add(miXoaKH);
        mnKH.add(new JSeparator());
        mnKH.add(miXemDiem);

        // Menu Nhân viên
        JMenu mnNV = new JMenu("Nhân viên");
        miHienNV = new JMenuItem("Hiển thị");
        miThemNV = new JMenuItem("Thêm");
        miXoaNV = new JMenuItem("Xóa");
        miDoiTTNV = new JMenuItem("Đổi trạng thái"); // THÊM MỚI
        mnNV.add(miHienNV); 
        mnNV.add(miThemNV); 
        mnNV.add(miXoaNV);
        mnNV.add(new JSeparator()); // Thêm phân cách
        mnNV.add(miDoiTTNV); // Thêm item mới

        // Menu Bàn
        JMenu mnBan = new JMenu("Bàn");
        miHienBan = new JMenuItem("Hiển thị");
        miThemBan = new JMenuItem("Thêm");
        miXoaBan = new JMenuItem("Xóa");
        miCapNhatBan = new JMenuItem("Cập nhật bàn");
        miTimBan = new JMenuItem("Tìm bàn");
        miDoiTTBan = new JMenuItem("Đổi trạng thái bàn");
        miBanTrong = new JMenuItem("Bàn trống");
        miBanDangSD = new JMenuItem("Bàn đang sử dụng");
        miBanDatTruoc = new JMenuItem("Bàn đặt trước");
        miSoDoBan = new JMenuItem("Sơ đồ bàn");

        mnBan.add(miHienBan);
        mnBan.add(miThemBan);
        mnBan.add(miXoaBan);
        mnBan.add(miCapNhatBan);
        mnBan.add(new JSeparator());
        mnBan.add(miTimBan);
        mnBan.add(miDoiTTBan);
        mnBan.add(new JSeparator());
        mnBan.add(miBanTrong);
        mnBan.add(miBanDangSD);
        mnBan.add(miBanDatTruoc);
        mnBan.add(new JSeparator());
        mnBan.add(miSoDoBan);

        // Menu Ca làm
        JMenu mnCa = new JMenu("Ca làm");
        miHienCa = new JMenuItem("Hiển thị");
        miThemCa = new JMenuItem("Thêm");
        miXoaCa = new JMenuItem("Xóa");
        mnCa.add(miHienCa); mnCa.add(miThemCa); mnCa.add(miXoaCa);

        // Menu Doanh thu
        JMenu mnDT = new JMenu("Doanh thu");
        miHienDT = new JMenuItem("Hiển thị");
        miThemDT = new JMenuItem("Thêm");
        miXoaDT = new JMenuItem("Xóa");
        miTongHopDoanhThu = new JMenuItem("Tổng hợp doanh thu");
        mnDT.add(miHienDT); 
        mnDT.add(miThemDT); 
        mnDT.add(miXoaDT);
        mnDT.add(new JSeparator());
        mnDT.add(miTongHopDoanhThu);

        // Menu Hoá đơn
        JMenu mnHD = new JMenu("Hóa đơn");
        miHienHD = new JMenuItem("Hiển thị");
        miThemHD = new JMenuItem("Thêm hóa đơn");
        miThemSPvaoHD = new JMenuItem("Thêm SP vào HĐ");
        JMenuItem miXemCT = new JMenuItem("Xem chi tiết");
        mnHD.add(miHienHD); mnHD.add(miThemHD); mnHD.add(miThemSPvaoHD); mnHD.add(miXemCT);

        // Menu Chấm công
        JMenu mnChamCong = new JMenu("Chấm công");
        miChamCong = new JMenuItem("Chấm công");
        miHienChamCong = new JMenuItem("Xem chấm công");
        mnChamCong.add(miChamCong);
        mnChamCong.add(miHienChamCong);

        // Menu Tài khoản
        JMenu mnAccount = new JMenu("Tài khoản");
        JMenuItem miLogout = new JMenuItem("Đăng xuất");
        JMenuItem miRegister = new JMenuItem("Đăng ký user");
        JMenuItem miChangePass = new JMenuItem("Đổi mật khẩu");
        mnAccount.add(miRegister); mnAccount.add(miChangePass); mnAccount.add(miLogout);

        // Thêm menu vào thanh menu
        menuBar.add(mnSP); 
        menuBar.add(mnKH); 
        menuBar.add(mnNV); 
        menuBar.add(mnBan);
        menuBar.add(mnCa); 
        menuBar.add(mnDT); 
        menuBar.add(mnHD); 
        menuBar.add(mnChamCong);
        menuBar.add(mnAccount);
        setJMenuBar(menuBar);

        setupMenuListeners();
        
        miChangePass.addActionListener(ev -> changePassword());
        miRegister.addActionListener(ev -> registerUser());
        miLogout.addActionListener(ev -> doLogin());
        
        miXemCT.addActionListener(ev -> {
            String maHD = JOptionPane.showInputDialog(this, "Nhập Mã Hóa Đơn:");
            if (maHD != null && !maHD.trim().isEmpty()) {
                try {
                    HoaDon.hienThiChiTietHoaDonGui(this, Integer.parseInt(maHD));
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(this, "Lỗi: " + ex.getMessage());
                }
            }
        });
        
        // Xử lý xem/đổi điểm
        miXemDiem.addActionListener(ev -> xemVaDoiDiem());
    }

    private void initCommonComponents() {
        // Header chung - Gradient màu cà phê
        JPanel top = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                
                // Gradient từ nâu đậm đến nâu nhạt
                GradientPaint gradient = new GradientPaint(0, 0, new Color(111, 78, 55), 
                                                          getWidth(), 0, new Color(139, 111, 71));
                g2d.setPaint(gradient);
                g2d.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        top.setLayout(new BorderLayout(15, 8));
        top.setBorder(new EmptyBorder(12, 15, 12, 15));
        
        JLabel title = new JLabel("☕ Hệ thống quản lý quán cà phê");
        title.setFont(new Font("Segoe UI", Font.BOLD, 22));
        title.setForeground(new Color(255, 250, 240));
        
        lblUser = new JLabel("Đăng nhập: (chưa)");
        lblUser.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        lblUser.setForeground(new Color(230, 220, 200));
        
        top.add(title, BorderLayout.WEST);
        
        JPanel rightTop = new JPanel(new FlowLayout(FlowLayout.RIGHT, 15, 0));
        rightTop.setOpaque(false);
        
        JLabel lblDate = new JLabel("📅 " + LocalDate.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy")));
        lblDate.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        lblDate.setForeground(new Color(230, 220, 200));
        
        rightTop.add(lblDate);
        JSeparator sep = new JSeparator(SwingConstants.VERTICAL);
        sep.setForeground(new Color(200, 130, 78));
        rightTop.add(sep);
        rightTop.add(lblUser);
        
        top.add(rightTop, BorderLayout.EAST);
        
        // Thêm vào backgroundLabel
        backgroundLabel.add(top, BorderLayout.NORTH);
    }

    // ==================== GIAO DIỆN EMPLOYEE (iPOS) ====================
    private void initEmployeeUI() {
        // Xóa nội dung cũ
        backgroundLabel.removeAll();
        initCommonComponents();
        
        // Danh mục sản phẩm
        catModel = new DefaultTableModel(new Object[] {"Loại"}, 0) { 
            public boolean isCellEditable(int r,int c){ return false; } 
        };
        tblCategories = new JTable(catModel);
        tblCategories.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        tblCategories.setOpaque(false);
        tblCategories.getTableHeader().setOpaque(false);
        tblCategories.getTableHeader().setBackground(new Color(255, 255, 255, 200));
        
        tblCategories.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                int r = tblCategories.getSelectedRow();
                if (r >= 0) {
                    String loai = (String) catModel.getValueAt(r, 0);
                    loadProducts(loai.equals("Tất cả") ? null : loai);
                }
            }
        });
        
        JScrollPane catScroll = new JScrollPane(tblCategories);
        catScroll.setPreferredSize(new Dimension(170,0));
        catScroll.setBorder(BorderFactory.createTitledBorder("Danh mục"));
        catScroll.setOpaque(false);
        catScroll.getViewport().setOpaque(false);
        
        JPanel leftPanel = new JPanel(new BorderLayout(6,6));
        leftPanel.setOpaque(false);
        leftPanel.add(catScroll, BorderLayout.CENTER);
        
        JButton btnRefreshCat = new JButton("Làm mới");
        btnRefreshCat.addActionListener(e -> loadCategories());
        leftPanel.add(btnRefreshCat, BorderLayout.SOUTH);

        // Panel sản phẩm
        productsPanel = new JPanel();
        productsPanel.setBorder(BorderFactory.createTitledBorder("Sản phẩm"));
        productsPanel.setOpaque(false);
        
        JScrollPane prodScroll = new JScrollPane(productsPanel);
        prodScroll.setOpaque(false);
        prodScroll.getViewport().setOpaque(false);

        // Giỏ hàng
        cartModel = new DefaultTableModel(new Object[] {"Mã SP","Tên SP","SL","Đơn giá","Thành tiền"}, 0) {
            public boolean isCellEditable(int r,int c){ return c==2; }
            public Class<?> getColumnClass(int col){ 
                if (col==0||col==2) return Integer.class; 
                if (col==3||col==4) return BigDecimal.class; 
                return Object.class; 
            }
        };
        
        JTable cartTable = new JTable(cartModel);
        cartTable.putClientProperty("terminateEditOnFocusLost", Boolean.TRUE);
        cartTable.setOpaque(false);
        cartTable.getTableHeader().setOpaque(false);
        cartTable.getTableHeader().setBackground(new Color(255, 255, 255, 200));
        
        cartModel.addTableModelListener(e -> recalcTotal());
        
        JScrollPane cartScroll = new JScrollPane(cartTable);
        cartScroll.setPreferredSize(new Dimension(360,420));
        cartScroll.setBorder(BorderFactory.createTitledBorder("Giỏ hàng"));
        cartScroll.setOpaque(false);
        cartScroll.getViewport().setOpaque(false);

        // Panel thanh toán
        JButton btnRemove = createStyledButton("🗑️  Xóa", new Color(220, 100, 100));
        JButton btnClear = createStyledButton("❌ Xóa hết", new Color(200, 80, 80));
        JButton btnDoiDiem = createStyledButton("⭐ Đổi điểm", new Color(255, 165, 0));
        JButton btnCheckout = createStyledButton("✓ Thanh toán", new Color(70, 160, 70));
     
        JPanel cartButtons = new JPanel(new GridLayout(1, 4, 10, 0));
        cartButtons.setOpaque(false);
        cartButtons.add(btnRemove);
        cartButtons.add(btnClear);
        cartButtons.add(btnDoiDiem);
        cartButtons.add(btnCheckout);
        
        lblTotal = new JLabel("0 đ");
        lblTotal.setFont(new Font("Arial", Font.BOLD, 20));
        lblTotal.setForeground(new Color(200, 0, 0));
        
        JLabel totalLabel = new JLabel("Tổng tiền: ");
        totalLabel.setFont(new Font("Arial", Font.PLAIN, 16));
        totalLabel.setForeground(Color.BLACK);
        
        JPanel totalPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 0));
        totalPanel.setOpaque(true);
        totalPanel.add(totalLabel);
        totalPanel.add(lblTotal);
        
        JSeparator separator = new JSeparator();
        separator.setForeground(new Color(180, 180, 180));
    
        JPanel bottomRight = new JPanel();
        bottomRight.setLayout(new BoxLayout(bottomRight, BoxLayout.Y_AXIS));
        bottomRight.setOpaque(false);
        bottomRight.add(totalPanel);
        bottomRight.add(Box.createVerticalStrut(8));
        bottomRight.add(separator);
        bottomRight.add(Box.createVerticalStrut(10));
        bottomRight.add(cartButtons);
        bottomRight.setBorder(BorderFactory.createEmptyBorder(15, 10, 15, 10));
        
        JPanel right = new JPanel(new BorderLayout(8,8));
        right.setOpaque(false);
        right.setBorder(new EmptyBorder(8,8,8,8));
        right.add(cartScroll, BorderLayout.CENTER);
        right.add(bottomRight, BorderLayout.SOUTH);

        JSplitPane leftSplit = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, leftPanel, prodScroll);
        leftSplit.setOpaque(false);
        leftSplit.setResizeWeight(0);
        
        JSplitPane mainSplit = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, leftSplit, right);
        mainSplit.setOpaque(false);
        mainSplit.setDividerLocation(720);
        
        // Thêm vào backgroundLabel
        backgroundLabel.add(mainSplit, BorderLayout.CENTER);

        // Xử lý sự kiện
        btnRemove.addActionListener(e -> { 
            int r = cartTable.getSelectedRow(); 
            if (r>=0) cartModel.removeRow(r); 
            recalcTotal(); 
        });
        btnClear.addActionListener(e -> { 
            cartModel.setRowCount(0); 
            recalcTotal(); 
        });
        btnDoiDiem.addActionListener(e -> doiDiemKhachHang());
        btnCheckout.addActionListener(e -> doCheckout());

        loadCategories();
        loadProducts(null);
        
        revalidate();
        repaint();
    }

    // ==================== DASHBOARD ADMIN ====================
    private void initAdminDashboard() {
        // Xóa nội dung cũ
        backgroundLabel.removeAll();
        initCommonComponents();
        
        // Tạo Dashboard - KHÔNG CẦN TRONG SUỐT vì đã có màu nền riêng
        adminDashboardPanel = new JPanel(new BorderLayout(10, 10));
        adminDashboardPanel.setBackground(new Color(240, 245, 250)); // Màu nền xanh nhạt
        adminDashboardPanel.setBorder(new EmptyBorder(20, 20, 20, 20));
        
        // Tiêu đề Dashboard
        JLabel titleLabel = new JLabel("ADMIN DASHBOARD - QUẢN LÝ HỆ THỐNG");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        titleLabel.setForeground(new Color(0, 80, 180));
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
        adminDashboardPanel.add(titleLabel, BorderLayout.NORTH);
        
        // Panel thống kê chính
        JPanel mainStatsPanel = new JPanel(new GridLayout(2, 3, 20, 20));
        mainStatsPanel.setBorder(BorderFactory.createEmptyBorder(30, 20, 30, 20));
        mainStatsPanel.setBackground(new Color(240, 245, 250));
        
        // Tạo 6 ô thống kê
        String[] statTitles = {
            "TỔNG SẢN PHẨM",
            "TỔNG NHÂN VIÊN", 
            "DOANH THU HÔM NAY",
            "TỔNG HÓA ĐƠN",
            "KHÁCH HÀNG",
            "BÀN TRỐNG"
        };
        
        Color[] statColors = {
            new Color(70, 130, 180),
            new Color(60, 179, 113),
            new Color(220, 20, 60),
            new Color(255, 140, 0),
            new Color(138, 43, 226),
            new Color(34, 139, 34)
        };
        
        for (int i = 0; i < 6; i++) {
            JPanel statPanel = createStatPanel(statTitles[i], "0", statColors[i]);
            mainStatsPanel.add(statPanel);
        }
        
        adminDashboardPanel.add(mainStatsPanel, BorderLayout.CENTER);
        
        // Thêm vào backgroundLabel
        backgroundLabel.add(adminDashboardPanel, BorderLayout.CENTER);
        
        // Tải dữ liệu thống kê
        loadDashboardStats();
        
        revalidate();
        repaint();
    }
    
    private JPanel createStatPanel(String title, String value, Color color) {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(color, 2),
            BorderFactory.createEmptyBorder(20, 15, 20, 15)
        ));
        panel.setBackground(Color.WHITE);
        
        JLabel titleLabel = new JLabel(title);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 14));
        titleLabel.setForeground(new Color(80, 80, 80));
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
        
        JLabel valueLabel = new JLabel(value);
        valueLabel.setFont(new Font("Arial", Font.BOLD, 28));
        valueLabel.setForeground(color);
        valueLabel.setHorizontalAlignment(SwingConstants.CENTER);
        
        panel.add(titleLabel, BorderLayout.NORTH);
        panel.add(valueLabel, BorderLayout.CENTER);
        
        return panel;
    }
    
    private void loadDashboardStats() {
        try (Connection conn = DBConnection.getConnection()) {
            // 1. Tổng sản phẩm
            String sql1 = "SELECT COUNT(*) FROM SanPham";
            try (Statement stmt = conn.createStatement();
                 ResultSet rs = stmt.executeQuery(sql1)) {
                if (rs.next()) {
                    updateStatLabel(0, rs.getInt(1));
                }
            }
            
            // 2. Tổng nhân viên
            String sql2 = "SELECT COUNT(*) FROM NhanVien";
            try (Statement stmt = conn.createStatement();
                 ResultSet rs = stmt.executeQuery(sql2)) {
                if (rs.next()) {
                    updateStatLabel(1, rs.getInt(1));
                }
            }
            
            // 3. Doanh thu hôm nay
            String today = LocalDate.now().toString();
            String sql3 = "SELECT ISNULL(SUM(TongTien), 0) FROM HoaDon WHERE CONVERT(date, NgayLap) = ?";
            try (PreparedStatement pstmt = conn.prepareStatement(sql3)) {
                pstmt.setString(1, today);
                try (ResultSet rs = pstmt.executeQuery()) {
                    if (rs.next()) {
                        BigDecimal revenue = rs.getBigDecimal(1);
                        updateStatLabel(2, revenue != null ? revenue : BigDecimal.ZERO);
                    }
                }
            }
            
            // 4. Tổng hóa đơn hôm nay
            String sql4 = "SELECT COUNT(*) FROM HoaDon WHERE CONVERT(date, NgayLap) = ?";
            try (PreparedStatement pstmt = conn.prepareStatement(sql4)) {
                pstmt.setString(1, today);
                try (ResultSet rs = pstmt.executeQuery()) {
                    if (rs.next()) {
                        updateStatLabel(3, rs.getInt(1));
                    }
                }
            }
            
            // 5. Tổng khách hàng
            String sql5 = "SELECT COUNT(*) FROM KhachHang";
            try (Statement stmt = conn.createStatement();
                 ResultSet rs = stmt.executeQuery(sql5)) {
                if (rs.next()) {
                    updateStatLabel(4, rs.getInt(1));
                }
            }
            
            // 6. BÀN TRỐNG 
            String sql6 = "SELECT COUNT(*) FROM Ban WHERE TrangThai LIKE 'Trống'";        
            try (Statement stmt = conn.createStatement();
                 ResultSet rs = stmt.executeQuery(sql6)) {
                if (rs.next()) {
                    updateStatLabel(5, rs.getInt(1));
                }
            }
            
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Lỗi tải thống kê: " + ex.getMessage());
        }
    }
    
    private void updateStatLabel(int index, int value) {
        if (adminDashboardPanel != null) {
            Component[] components = ((JPanel)adminDashboardPanel.getComponent(1)).getComponents();
            if (index < components.length) {
                JPanel statPanel = (JPanel) components[index];
                JLabel valueLabel = (JLabel) statPanel.getComponent(1);
                valueLabel.setText(String.format("%,d", value));
            }
        }
    }
    
    private void updateStatLabel(int index, BigDecimal value) {
        if (adminDashboardPanel != null) {
            Component[] components = ((JPanel)adminDashboardPanel.getComponent(1)).getComponents();
            if (index < components.length) {
                JPanel statPanel = (JPanel) components[index];
                JLabel valueLabel = (JLabel) statPanel.getComponent(1);
                valueLabel.setText(String.format("%,.0f đ", value));
            }
        }
    }

    // ==================== PHÂN QUYỀN ====================
    private void applyRolePermissions() {
        boolean isAdmin = "admin".equals(currentRole);
        
        if (isAdmin) {
            // Dashboard Admin: KHÔNG có background hình ảnh
            setupBackground(false);
            initAdminDashboard();
            setTitle("Admin Dashboard - Quản lý hệ thống");
            JOptionPane.showMessageDialog(this, 
                "Chào mừng Admin!\nBạn đang ở chế độ quản lý hệ thống.",
                "Thông báo", JOptionPane.INFORMATION_MESSAGE);
            
            enableAllMenuItems(true);
        } else {
            // Employee UI: CÓ background hình ảnh
            setupBackground(true);
            initEmployeeUI();
            setTitle("iPOS - Bán hàng");
            applyEmployeePermissions();
        }
    }
    
    private void applyEmployeePermissions() {
        boolean isEmployee = "employee".equals(currentRole);
        
        if (isEmployee) {
            // Sản phẩm: chỉ xem
            miThemSP.setEnabled(false);
            miXoaSP.setEnabled(false);
            
            // Khách hàng: được xem, thêm, xem điểm (không xóa)
            miHienKH.setEnabled(true);
            miThemKH.setEnabled(true);
            miXoaKH.setEnabled(false);
            miXemDiem.setEnabled(true);
            
            // Nhân viên: không được xem và đổi trạng thái
            miHienNV.setEnabled(false);
            miThemNV.setEnabled(false);
            miXoaNV.setEnabled(false);
            miDoiTTNV.setEnabled(false); // Không cho phép đổi trạng thái
            
            // Bàn: được xem và các chức năng phục vụ
            miHienBan.setEnabled(true);
            miThemBan.setEnabled(true);
            miXoaBan.setEnabled(false);
            miCapNhatBan.setEnabled(true);
            miTimBan.setEnabled(true);
            miDoiTTBan.setEnabled(true);
            miBanTrong.setEnabled(true);
            miBanDangSD.setEnabled(true);
            miBanDatTruoc.setEnabled(true);
            miSoDoBan.setEnabled(true);
            
            // Ca làm: chỉ xem
            miHienCa.setEnabled(true);
            miThemCa.setEnabled(false);
            miXoaCa.setEnabled(false);
            
            // Doanh thu: không được xem
            miHienDT.setEnabled(false);
            miThemDT.setEnabled(false);
            miXoaDT.setEnabled(false);
            miTongHopDoanhThu.setEnabled(false);
            
            // Hóa đơn: được xem và thêm
            miHienHD.setEnabled(true);
            miThemHD.setEnabled(true);
            miThemSPvaoHD.setEnabled(true);
            
            // Chấm công: được chấm công và xem
            miChamCong.setEnabled(true);
            miHienChamCong.setEnabled(true);
        }
    }

    private void enableAllMenuItems(boolean enabled) {
        JMenuItem[] allItems = { 
            miThemSP, miXoaSP, miThemKH, miXoaKH, 
            miThemNV, miXoaNV, miDoiTTNV, // Thêm miDoiTTNV
            miThemBan, miXoaBan, 
            miThemCa, miXoaCa, miThemDT, miXoaDT, 
            miThemHD, miThemSPvaoHD, miChamCong, miTongHopDoanhThu,
            miXemDiem, miCapNhatBan, miTimBan, miDoiTTBan,
            miBanTrong, miBanDangSD, miBanDatTruoc, miSoDoBan
        };
        for (JMenuItem it : allItems) {
            if (it != null) it.setEnabled(enabled);
        }
    }

    private void doLogin() {
        LoginDialog dlg = new LoginDialog(this);
        dlg.setVisible(true);
        if (!dlg.isAuthenticated()) {
            currentUser = null;
            return;
        }
        currentUser = dlg.getAuthenticatedUser();
        currentRole = dlg.getAuthenticatedRole();
        currentMaNV = dlg.getAuthenticatedMaNV();
        lblUser.setText("Đăng nhập: " + currentUser + " (" + currentRole + ")" + 
                       (currentMaNV != -1 ? " [NV:" + currentMaNV + "]" : ""));
        applyRolePermissions();
    }

    private void setupMenuListeners() {
        // Sản phẩm
        miHienSP.addActionListener(ev -> Product.hienThiSanPhamGui(this));
        miThemSP.addActionListener(ev -> {
            if (!checkAdminPermission()) return;
            String ten = JOptionPane.showInputDialog(this, "Tên sản phẩm:");
            String gia = JOptionPane.showInputDialog(this, "Giá:");
            String loai = JOptionPane.showInputDialog(this, "Loại:");
            if (ten!=null && gia!=null) {
                Product.themSanPham(ten, gia, loai==null ? "" : loai);
            }
            if (currentRole.equals("admin")) {
                loadDashboardStats();
            } else {
                loadCategories(); 
                loadProducts(null);
            }
        });
        miXoaSP.addActionListener(ev -> {
            if (!checkAdminPermission()) return;
            String id = JOptionPane.showInputDialog(this, "Mã SP cần xóa:");
            try { 
                if (id!=null) Product.xoaSanPham(Integer.parseInt(id)); 
            } catch (Exception ex){ 
                JOptionPane.showMessageDialog(this,"Mã không hợp lệ"); 
            }
            if (currentRole.equals("admin")) {
                loadDashboardStats();
            } else {
                loadCategories(); 
                loadProducts(null);
            }
        });

        // Khách hàng
        miHienKH.addActionListener(ev -> Customer.hienThiKhachHangGui(this));
        miThemKH.addActionListener(ev -> {
            String ten = JOptionPane.showInputDialog(this, "Tên khách hàng:");
            String sdt = JOptionPane.showInputDialog(this, "Số điện thoại:");
            if (ten!=null && !ten.trim().isEmpty()) {
                Customer.themKhachHang(ten, sdt);
                if (currentRole.equals("admin")) loadDashboardStats();
            }
        });
        miXoaKH.addActionListener(ev -> {
            if (!checkAdminPermission()) return;
            String id = JOptionPane.showInputDialog(this, "Mã KH cần xóa:");
            try { 
                if (id!=null) Customer.xoaKhachHang(Integer.parseInt(id)); 
            } catch (Exception ex){ 
                JOptionPane.showMessageDialog(this,"Mã không hợp lệ"); 
            }
            if (currentRole.equals("admin")) loadDashboardStats();
        });

        // Nhân viên
        miHienNV.addActionListener(ev -> {
            if (!checkAdminPermission()) return;
            Employee.hienThiNhanVienGui(this);
        });
        
        miThemNV.addActionListener(ev -> {
            if (!checkAdminPermission()) return;
            String ten = JOptionPane.showInputDialog(this, "Tên nhân viên:");
            String chucVu = JOptionPane.showInputDialog(this, "Chức vụ:");
            String dt = JOptionPane.showInputDialog(this, "Điện thoại:");
            String luong = JOptionPane.showInputDialog(this, "Lương:");
            
            // Tạo combobox cho trạng thái
            JComboBox<String> cbTrangThai = new JComboBox<>(new String[]{"Đang làm", "Nghỉ", "Nghỉ phép", "Tạm nghỉ"});
            
            Object[] form = {
                "Tên nhân viên:", new JTextField(ten==null?"":ten),
                "Chức vụ:", new JTextField(chucVu==null?"":chucVu),
                "Điện thoại:", new JTextField(dt==null?"":dt),
                "Lương:", new JTextField(luong==null?"":luong),
                "Trạng thái:", cbTrangThai
            };
            
            int result = JOptionPane.showConfirmDialog(this, form, "Thêm nhân viên", 
                JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
            
            if (result == JOptionPane.OK_OPTION) {
                String tenNV = ((JTextField)form[1]).getText();
                String chucVuNV = ((JTextField)form[3]).getText();
                String dtNV = ((JTextField)form[5]).getText();
                String luongNV = ((JTextField)form[7]).getText();
                String trangThai = (String) cbTrangThai.getSelectedItem();
                
                if (!tenNV.isEmpty()) {
                    Employee.themNhanVien(tenNV, chucVuNV, dtNV, luongNV, trangThai);
                    if (currentRole.equals("admin")) loadDashboardStats();
                }
            }
        });
        
        miXoaNV.addActionListener(ev -> {
            if (!checkAdminPermission()) return;
            String id = JOptionPane.showInputDialog(this, "Mã NV cần xóa:");
            try { 
                if (id!=null) Employee.xoaNhanVien(Integer.parseInt(id)); 
            } catch (Exception ex){ 
                JOptionPane.showMessageDialog(this,"Mã không hợp lệ"); 
            }
            if (currentRole.equals("admin")) loadDashboardStats();
        });
        
        // THÊM XỬ LÝ SỰ KIỆN CHO ĐỔI TRẠNG THÁI NHÂN VIÊN
        miDoiTTNV.addActionListener(ev -> {
            if (!checkAdminPermission()) return;
            Employee.doiTrangThaiNhanVienGui(this);
        });

        // Bàn
        miHienBan.addActionListener(ev -> Ban.hienThiBanGui(this));
        miThemBan.addActionListener(ev -> {
            JTextField tfTen = new JTextField();
            JTextField tfKhuVuc = new JTextField();
            JComboBox<String> cbTrangThai = new JComboBox<>(new String[]{"Trống", "Đang sử dụng", "Đặt trước", "Bảo trì"});
            JTextField tfSoCho = new JTextField("4");
            JTextField tfGhiChu = new JTextField();
            
            Object[] form = {
                "Tên bàn:", tfTen,
                "Khu vực:", tfKhuVuc,
                "Trạng thái:", cbTrangThai,
                "Số chỗ:", tfSoCho,
                "Ghi chú:", tfGhiChu
            };
            
            int result = JOptionPane.showConfirmDialog(this, form, "Thêm bàn mới", 
                JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
            
            if (result == JOptionPane.OK_OPTION) {
                try {
                    String ten = tfTen.getText().trim();
                    String khuVuc = tfKhuVuc.getText().trim();
                    String trangThai = (String) cbTrangThai.getSelectedItem();
                    int soCho = Integer.parseInt(tfSoCho.getText().trim());
                    String ghiChu = tfGhiChu.getText().trim();
                    
                    if (!ten.isEmpty()) {
                        Ban.themBan(ten, khuVuc, trangThai, soCho, ghiChu);
                        if (currentRole.equals("admin")) loadDashboardStats();
                    }
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(this, "Số chỗ phải là số hợp lệ!");
                }
            }
        });
        
        miXoaBan.addActionListener(ev -> {
            if (!checkAdminPermission()) return;
            String id = JOptionPane.showInputDialog(this, "Mã bàn cần xóa:");
            try { 
                if (id!=null) Ban.xoaBan(Integer.parseInt(id)); 
            } catch (Exception ex){ 
                JOptionPane.showMessageDialog(this,"Mã không hợp lệ"); 
            }
            if (currentRole.equals("admin")) loadDashboardStats();
        });
        
        miCapNhatBan.addActionListener(ev -> {
            String maBanStr = JOptionPane.showInputDialog(this, "Nhập mã bàn cần cập nhật:");
            if (maBanStr == null || maBanStr.trim().isEmpty()) return;
            
            try {
                int maBan = Integer.parseInt(maBanStr.trim());
                
                try (Connection conn = DBConnection.getConnection();
                     PreparedStatement pstmt = conn.prepareStatement(
                         "SELECT TenBan, KhuVuc, TrangThai, SoCho, GhiChu FROM Ban WHERE MaBan = ?")) {
                    
                    pstmt.setInt(1, maBan);
                    try (ResultSet rs = pstmt.executeQuery()) {
                        if (rs.next()) {
                            JTextField tfTen = new JTextField(rs.getString("TenBan"));
                            JTextField tfKhuVuc = new JTextField(rs.getString("KhuVuc"));
                            JComboBox<String> cbTrangThai = new JComboBox<>(new String[]{"Trống", "Đang sử dụng", "Đặt trước", "Bảo trì"});
                            cbTrangThai.setSelectedItem(rs.getString("TrangThai"));
                            JTextField tfSoCho = new JTextField(String.valueOf(rs.getInt("SoCho")));
                            JTextField tfGhiChu = new JTextField(rs.getString("GhiChu"));
                            
                            Object[] form = {
                                "Tên bàn:", tfTen,
                                "Khu vực:", tfKhuVuc,
                                "Trạng thái:", cbTrangThai,
                                "Số chỗ:", tfSoCho,
                                "Ghi chú:", tfGhiChu
                            };
                            
                            int result = JOptionPane.showConfirmDialog(this, form, "Cập nhật bàn", 
                                JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
                            
                            if (result == JOptionPane.OK_OPTION) {
                                String ten = tfTen.getText().trim();
                                String khuVuc = tfKhuVuc.getText().trim();
                                String trangThai = (String) cbTrangThai.getSelectedItem();
                                int soCho = Integer.parseInt(tfSoCho.getText().trim());
                                String ghiChu = tfGhiChu.getText().trim();
                                
                                if (!ten.isEmpty()) {
                                    Ban.capNhatBan(maBan, ten, khuVuc, trangThai, soCho, ghiChu);
                                    if (currentRole.equals("admin")) loadDashboardStats();
                                }
                            }
                        } else {
                            JOptionPane.showMessageDialog(this, "Không tìm thấy bàn với mã: " + maBan);
                        }
                    }
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Mã bàn phải là số!");
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Lỗi: " + ex.getMessage());
            }
        });
        
        miTimBan.addActionListener(ev -> {
            String keyword = JOptionPane.showInputDialog(this, "Nhập tên bàn hoặc khu vực cần tìm:");
            if (keyword != null && !keyword.trim().isEmpty()) {
                Ban.timBan(this, keyword.trim());
            }
        });
        
        miDoiTTBan.addActionListener(ev -> {
            String maBanStr = JOptionPane.showInputDialog(this, "Nhập mã bàn:");
            if (maBanStr == null || maBanStr.trim().isEmpty()) return;
            
            try {
                int maBan = Integer.parseInt(maBanStr.trim());
                JComboBox<String> cbTrangThai = new JComboBox<>(new String[]{"Trống", "Đang sử dụng", "Đặt trước", "Bảo trì"});
                
                Object[] form = {
                    "Mã bàn:", new JLabel(maBanStr),
                    "Trạng thái mới:", cbTrangThai
                };
                
                int result = JOptionPane.showConfirmDialog(this, form, "Đổi trạng thái bàn", 
                    JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
                
                if (result == JOptionPane.OK_OPTION) {
                    String trangThaiMoi = (String) cbTrangThai.getSelectedItem();
                    Ban.doiTrangThaiBan(maBan, trangThaiMoi);
                    if (currentRole.equals("admin")) loadDashboardStats();
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Mã bàn phải là số!");
            }
        });
        
        miBanTrong.addActionListener(ev -> Ban.hienThiBanTheoTrangThai(this, "Trống"));
        miBanDangSD.addActionListener(ev -> Ban.hienThiBanTheoTrangThai(this, "Đang sử dụng"));
        miBanDatTruoc.addActionListener(ev -> Ban.hienThiBanTheoTrangThai(this, "Đặt trước"));
        miSoDoBan.addActionListener(ev -> Ban.hienThiBanGui(this));

        // Ca làm
        miHienCa.addActionListener(ev -> showCaList());
        miThemCa.addActionListener(ev -> {
            if (!checkAdminPermission()) return;
            String ten = JOptionPane.showInputDialog(this, "Tên ca:");
            String gb = JOptionPane.showInputDialog(this, "Giờ bắt đầu (HH:MM:SS):");
            String gk = JOptionPane.showInputDialog(this, "Giờ kết thúc (HH:MM:SS):");
            String tien = JOptionPane.showInputDialog(this, "Tiền ca:");
            if (ten!=null) addCa(ten, gb, gk, tien);
        });
        miXoaCa.addActionListener(ev -> {
            if (!checkAdminPermission()) return;
            String id = JOptionPane.showInputDialog(this, "Mã ca cần xóa:");
            try { 
                if (id!=null) deleteCa(Integer.parseInt(id)); 
            } catch (Exception ex){ 
                JOptionPane.showMessageDialog(this,"Mã không hợp lệ"); 
            }
        });

        // Doanh thu
        miHienDT.addActionListener(ev -> {
            if (!checkAdminPermission()) return;
            DoanhThu.hienThiDoanhThuGui(this);
        });
        miThemDT.addActionListener(ev -> {
            if (!checkAdminPermission()) return;
            String ngay = JOptionPane.showInputDialog(this, "Ngày (YYYY-MM-DD):");
            String tongHD = JOptionPane.showInputDialog(this, "Tổng Hóa Đơn:");
            String tongDoanh = JOptionPane.showInputDialog(this, "Tổng doanh thu (số):");
            if (ngay!=null) {
                int tongHoaDon = 0;
                try {
                    tongHoaDon = Integer.parseInt(tongHD==null?"0":tongHD);
                } catch (NumberFormatException ex) {
                    tongHoaDon = 0;
                }
                DoanhThu.themDoanhThu(ngay, tongHoaDon, tongDoanh==null?"0":tongDoanh);
            }
            if (currentRole.equals("admin")) loadDashboardStats();
        });
        miXoaDT.addActionListener(ev -> {
            if (!checkAdminPermission()) return;
            String id = JOptionPane.showInputDialog(this, "Mã doanh thu cần xóa:");
            try { 
                if (id!=null) DoanhThu.xoaDoanhThu(Integer.parseInt(id)); 
            } catch (Exception ex){ 
                JOptionPane.showMessageDialog(this,"Mã không hợp lệ"); 
            }
            if (currentRole.equals("admin")) loadDashboardStats();
        });

        // Hóa đơn
        miHienHD.addActionListener(ev -> HoaDon.hienThiHoaDonGui(this));
        miThemHD.addActionListener(ev -> {
            try {
                int maNV;
                if ("employee".equals(currentRole)) {
                    maNV = currentMaNV;
                    if (maNV == -1) {
                        JOptionPane.showMessageDialog(this, "Không tìm thấy mã nhân viên!");
                        return;
                    }
                } else {
                    String maNVStr = JOptionPane.showInputDialog(this, "Mã nhân viên:");
                    if (maNVStr == null) return;
                    maNV = Integer.parseInt(maNVStr);
                }
                
                String maKH = JOptionPane.showInputDialog(this, "Mã KH (enter nếu null):");
                String maBan = JOptionPane.showInputDialog(this, "Mã bàn:");
                String tong = JOptionPane.showInputDialog(this, "Tổng tiền:");
                
                if (maBan!=null) {
                    Integer maKHValue = null;
                    if (maKH != null && !maKH.isEmpty()) {
                        maKHValue = Integer.valueOf(maKH);
                    }
                    HoaDon.themHoaDon(maNV, maKHValue, Integer.parseInt(maBan), new BigDecimal(tong));
                }
                if (currentRole.equals("admin")) loadDashboardStats();
            } catch (Exception ex) { 
                JOptionPane.showMessageDialog(this, "Dữ liệu không hợp lệ: " + ex.getMessage()); 
            }
        });
        
        miThemSPvaoHD.addActionListener(ev -> {
            try {
                String hd = JOptionPane.showInputDialog(this, "Mã HĐ:");
                String sp = JOptionPane.showInputDialog(this, "Mã SP:");
                String sl = JOptionPane.showInputDialog(this, "Số lượng:");
                String dg = JOptionPane.showInputDialog(this, "Đơn giá:");
                if (hd!=null) {
                    ChiTietHoaDon.themChiTiet(Integer.parseInt(hd), Integer.parseInt(sp), Integer.parseInt(sl), new BigDecimal(dg));
                }
            } catch (Exception ex) { 
                JOptionPane.showMessageDialog(this, "Dữ liệu không hợp lệ"); 
            }
        });

        // Chấm công
        miChamCong.addActionListener(ev -> {
            try {
                int maNV;
                if ("employee".equals(currentRole)) {
                    maNV = currentMaNV;
                    if (maNV == -1) {
                        JOptionPane.showMessageDialog(this, "Không tìm thấy mã nhân viên!");
                        return;
                    }
                } else {
                    String maNVStr = JOptionPane.showInputDialog(this, "Mã nhân viên:");
                    if (maNVStr == null) return;
                    maNV = Integer.parseInt(maNVStr);
                }
                
                JTextField tfMaCa = new JTextField();
                JTextField tfNgay = new JTextField(LocalDate.now().toString());
                JTextField tfGioVao = new JTextField("08:00:00");
                JTextField tfGioRa = new JTextField("17:00:00");
                
                Object[] form;
                if ("employee".equals(currentRole)) {
                    form = new Object[] {
                        "Mã nhân viên (tự động):", new JLabel(String.valueOf(maNV)),
                        "Mã ca:", tfMaCa,
                        "Ngày làm (YYYY-MM-DD):", tfNgay,
                        "Giờ vào (HH:MM:SS):", tfGioVao,
                        "Giờ ra (HH:MM:SS, để trống nếu chưa ra):", tfGioRa
                    };
                } else {
                    form = new Object[] {
                        "Mã nhân viên:", new JLabel(String.valueOf(maNV)),
                        "Mã ca:", tfMaCa,
                        "Ngày làm (YYYY-MM-DD):", tfNgay,
                        "Giờ vào (HH:MM:SS):", tfGioVao,
                        "Giờ ra (HH:MM:SS, để trống nếu chưa ra):", tfGioRa
                    };
                }
                
                int r = JOptionPane.showConfirmDialog(this, form, "Chấm công", JOptionPane.OK_CANCEL_OPTION);
                if (r == JOptionPane.OK_OPTION) {
                    int maCa = Integer.parseInt(tfMaCa.getText());
                    String ngay = tfNgay.getText();
                    String gioVao = tfGioVao.getText();
                    String gioRa = tfGioRa.getText().trim().isEmpty() ? null : tfGioRa.getText();
                    
                    Attendance.themChamCong(maNV, maCa, ngay, gioVao, gioRa);
                }
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Lỗi khi chấm công: " + ex.getMessage());
            }
        });
        
        miHienChamCong.addActionListener(ev -> {
            try {
                String ngay = JOptionPane.showInputDialog(this, "Nhập ngày (YYYY-MM-DD):", LocalDate.now().toString());
                if (ngay != null && !ngay.trim().isEmpty()) {
                    Attendance.hienThiChamCongGui(this, ngay);
                }
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Lỗi khi hiển thị chấm công: " + ex.getMessage());
            }
        });
        
        // Tổng hợp doanh thu
        miTongHopDoanhThu.addActionListener(ev -> {
            if (!checkAdminPermission()) return;
            String thang = JOptionPane.showInputDialog(this, "Nhập tháng (YYYY-MM):", 
                LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy-MM")));
            if (thang != null && !thang.trim().isEmpty()) {
                try {
                    tongHopDoanhThu(thang.trim());
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(this, "Lỗi: " + ex.getMessage());
                }
            }
        });
    }
    

    // ==================== HỆ THỐNG TÍCH ĐIỂM ====================
    
    private void xemVaDoiDiem() {
        try {
            String maKHs = JOptionPane.showInputDialog(this, "Nhập mã khách hàng:");
            if (maKHs == null || maKHs.trim().isEmpty()) return;
            
            int maKH = Integer.parseInt(maKHs.trim());
            
            try (Connection conn = DBConnection.getConnection();
                 PreparedStatement pstmt = conn.prepareStatement(
                     "SELECT TenKH, DiemTich FROM KhachHang WHERE MaKH = ?")) {
                
                pstmt.setInt(1, maKH);
                try (ResultSet rs = pstmt.executeQuery()) {
                    if (rs.next()) {
                        String tenKH = rs.getString("TenKH");
                        int diemHienCo = rs.getInt("DiemTich");
                        
                        String[] options = {"Xem điểm", "Đổi điểm", "Hủy"};
                        int choice = JOptionPane.showOptionDialog(this,
                            "Khách hàng: " + tenKH + "\n" +
                            "Mã KH: " + maKH + "\n" +
                            "Điểm hiện có: " + diemHienCo + " điểm\n\n" +
                            "Quy đổi điểm:\n" +
                            "• 10 điểm = 5.000đ giảm giá\n" +
                            "• 50 điểm = 30.000đ giảm giá\n" +
                            "• 100 điểm = 70.000đ giảm giá",
                            "Quản lý điểm tích lũy",
                            JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE,
                            null, options, options[0]);
                        
                        if (choice == 1) {
                            doiDiemKhachHang(maKH, tenKH, diemHienCo);
                        }
                    } else {
                        JOptionPane.showMessageDialog(this, "Không tìm thấy khách hàng!");
                    }
                }
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Lỗi: " + ex.getMessage());
            ex.printStackTrace();
        }
    }
    
    private void doiDiemKhachHang() {
        try {
            String maKHs = JOptionPane.showInputDialog(this, "Nhập mã khách hàng:");
            if (maKHs == null || maKHs.trim().isEmpty()) return;
            
            int maKH = Integer.parseInt(maKHs.trim());
            
            try (Connection conn = DBConnection.getConnection();
                 PreparedStatement pstmt = conn.prepareStatement(
                     "SELECT TenKH, DiemTich FROM KhachHang WHERE MaKH = ?")) {
                
                pstmt.setInt(1, maKH);
                try (ResultSet rs = pstmt.executeQuery()) {
                    if (rs.next()) {
                        String tenKH = rs.getString("TenKH");
                        int diemHienCo = rs.getInt("DiemTich");
                        doiDiemKhachHang(maKH, tenKH, diemHienCo);
                    } else {
                        JOptionPane.showMessageDialog(this, "Không tìm thấy khách hàng!");
                    }
                }
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Lỗi: " + ex.getMessage());
            ex.printStackTrace();
        }
    }
    
    private void doiDiemKhachHang(int maKH, String tenKH, int diemHienCo) {
        if (diemHienCo <= 0) {
            JOptionPane.showMessageDialog(this, 
                "Khách hàng " + tenKH + " không có điểm để đổi!\n" +
                "Điểm hiện có: " + diemHienCo + " điểm");
            return;
        }
        
        String diemDoiStr = JOptionPane.showInputDialog(this, 
            "Khách hàng: " + tenKH + "\n" +
            "Điểm hiện có: " + diemHienCo + " điểm\n\n" +
            "Nhập số điểm muốn đổi (tối thiểu 10 điểm):");
        
        if (diemDoiStr == null || diemDoiStr.trim().isEmpty()) return;
        
        try {
            int diemDoi = Integer.parseInt(diemDoiStr.trim());
            
            if (diemDoi < 10) {
                JOptionPane.showMessageDialog(this, "Số điểm đổi tối thiểu là 10 điểm!");
                return;
            }
            
            if (diemDoi > diemHienCo) {
                JOptionPane.showMessageDialog(this, 
                    "Khách hàng không đủ điểm!\n" +
                    "Điểm hiện có: " + diemHienCo + " điểm\n" +
                    "Điểm muốn đổi: " + diemDoi + " điểm");
                return;
            }
            
            BigDecimal tienGiamGia = new BigDecimal(diemDoi * 500);
            
            int confirm = JOptionPane.showConfirmDialog(this,
                "Xác nhận đổi " + diemDoi + " điểm\n" +
                "Thành " + String.format("%,.0f", tienGiamGia) + "đ giảm giá?\n\n" +
                "Sau khi đổi còn lại: " + (diemHienCo - diemDoi) + " điểm",
                "Xác nhận đổi điểm", JOptionPane.YES_NO_OPTION);
            
            if (confirm == JOptionPane.YES_OPTION) {
                try (Connection conn = DBConnection.getConnection();
                     PreparedStatement pstmt = conn.prepareStatement(
                         "UPDATE KhachHang SET DiemTich = DiemTich - ? WHERE MaKH = ?")) {
                    pstmt.setInt(1, diemDoi);
                    pstmt.setInt(2, maKH);
                    int updated = pstmt.executeUpdate();
                    
                    if (updated > 0) {
                        if (total.compareTo(tienGiamGia) >= 0) {
                            total = total.subtract(tienGiamGia);
                            recalcTotal();
                            JOptionPane.showMessageDialog(this,
                                "Đã áp dụng giảm giá " + String.format("%,.0f", tienGiamGia) + "đ\n" +
                                "Tổng tiền mới: " + String.format("%,.0f", total) + "đ\n\n" +
                                "Điểm còn lại: " + (diemHienCo - diemDoi) + " điểm");
                        } else {
                            JOptionPane.showMessageDialog(this,
                                "Tổng tiền nhỏ hơn số tiền giảm giá!\n" +
                                "Vui lòng chọn ít điểm hơn.");
                            try (PreparedStatement pstmt2 = conn.prepareStatement(
                                "UPDATE KhachHang SET DiemTich = DiemTich + ? WHERE MaKH = ?")) {
                                pstmt2.setInt(1, diemDoi);
                                pstmt2.setInt(2, maKH);
                                pstmt2.executeUpdate();
                            }
                        }
                    }
                }
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Vui lòng nhập số điểm hợp lệ!");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Lỗi: " + ex.getMessage());
            ex.printStackTrace();
        }
    }
    
    private void tichDiemKhiThanhToan(int maKH, BigDecimal tongTien, Connection conn) throws SQLException {
        if (maKH == 0) return;
        
        int diemTichLuy = tongTien.divide(new BigDecimal("1000"), 0, java.math.RoundingMode.DOWN).intValue();
        
        if (diemTichLuy > 0) {
            try (PreparedStatement pstmt = conn.prepareStatement(
                "UPDATE KhachHang SET DiemTich = DiemTich + ? WHERE MaKH = ?")) {
                pstmt.setInt(1, diemTichLuy);
                pstmt.setInt(2, maKH);
                pstmt.executeUpdate();
            }
            
            String finalMessage = "Khách hàng đã tích lũy được " + diemTichLuy + " điểm!\n" +
                                 "Cảm ơn quý khách!";
            
            SwingUtilities.invokeLater(() -> {
                JOptionPane.showMessageDialog(this,
                    finalMessage,
                    "Tích điểm thành công", JOptionPane.INFORMATION_MESSAGE);
            });
        }
    }
    
    private boolean checkAdminPermission() {
        if (!"admin".equals(currentRole)) {
            JOptionPane.showMessageDialog(this, "Chỉ Admin mới có quyền thực hiện chức năng này!", 
                "Không có quyền", JOptionPane.WARNING_MESSAGE);
            return false;
        }
        return true;
    }

    private void registerUser() {
        JTextField tfUser = new JTextField();
        JPasswordField pf = new JPasswordField();
        
        if ("admin".equals(currentRole)) {
            JComboBox<String> cb = new JComboBox<>(new String[]{"employee","admin"});
            Object[] form = {"Username:", tfUser, "Password:", pf, "Role:", cb};
            int r = JOptionPane.showConfirmDialog(this, form, "Đăng ký user", JOptionPane.OK_CANCEL_OPTION);
            if (r == JOptionPane.OK_OPTION) {
                try (Connection con = DBConnection.getConnection();
                     PreparedStatement ps = con.prepareStatement("INSERT INTO USERS(Username,Password,Role) VALUES(?,?,?)")) {
                    ps.setString(1, tfUser.getText());
                    ps.setString(2, new String(pf.getPassword()));
                    ps.setString(3, (String)cb.getSelectedItem());
                    ps.executeUpdate();
                    JOptionPane.showMessageDialog(this, "Đăng ký thành công!");
                } catch (SQLException ex) { 
                    if (ex.getMessage().contains("duplicate")) {
                        JOptionPane.showMessageDialog(this, "Username đã tồn tại!");
                    } else {
                        JOptionPane.showMessageDialog(this, "Lỗi đăng ký: "+ex.getMessage()); 
                    }
                }
            }
        } else {
            Object[] form = {"Username:", tfUser, "Password:", pf};
            int r = JOptionPane.showConfirmDialog(this, form, "Đăng ký user (employee)", JOptionPane.OK_CANCEL_OPTION);
            if (r == JOptionPane.OK_OPTION) {
                try (Connection con = DBConnection.getConnection();
                     PreparedStatement ps = con.prepareStatement("INSERT INTO USERS(Username,Password,Role) VALUES(?,?,'employee')")) {
                    ps.setString(1, tfUser.getText());
                    ps.setString(2, new String(pf.getPassword()));
                    ps.executeUpdate();
                    JOptionPane.showMessageDialog(this, "Đăng ký thành công!");
                } catch (SQLException ex) { 
                    if (ex.getMessage().contains("duplicate")) {
                        JOptionPane.showMessageDialog(this, "Username đã tồn tại!");
                    } else {
                        JOptionPane.showMessageDialog(this, "Lỗi đăng ký: "+ex.getMessage()); 
                    }
                }
            }
        }
    }

    private void changePassword() {
        JPasswordField pfOld = new JPasswordField();
        JPasswordField pfNew = new JPasswordField();
        JPasswordField pfConfirm = new JPasswordField();
        
        Object[] form = {
            "Mật khẩu cũ:", pfOld,
            "Mật khẩu mới:", pfNew,
            "Xác nhận mật khẩu mới:", pfConfirm
        };
        
        int r = JOptionPane.showConfirmDialog(this, form, "Đổi mật khẩu", JOptionPane.OK_CANCEL_OPTION);
        if (r == JOptionPane.OK_OPTION) {
            String oldPass = new String(pfOld.getPassword());
            String newPass = new String(pfNew.getPassword());
            String confirmPass = new String(pfConfirm.getPassword());
            
            if (!newPass.equals(confirmPass)) {
                JOptionPane.showMessageDialog(this, "Mật khẩu mới không khớp!");
                return;
            }
            
            try (Connection con = DBConnection.getConnection();
                 PreparedStatement ps = con.prepareStatement("UPDATE USERS SET Password = ? WHERE Username = ? AND Password = ?")) {
                ps.setString(1, newPass);
                ps.setString(2, currentUser);
                ps.setString(3, oldPass);
                int updated = ps.executeUpdate();
                if (updated > 0) {
                    JOptionPane.showMessageDialog(this, "Đổi mật khẩu thành công!");
                } else {
                    JOptionPane.showMessageDialog(this, "Mật khẩu cũ không đúng!");
                }
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(this, "Lỗi: " + ex.getMessage());
            }
        }
    }

    // ==================== CÁC PHƯƠNG THỨC CHO iPOS ====================
    private void loadCategories() {
        catModel.setRowCount(0);
        catModel.addRow(new Object[] {"Tất cả"});
        String sql = "SELECT DISTINCT Loai FROM SanPham WHERE Loai IS NOT NULL ORDER BY Loai";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement p = c.prepareStatement(sql);
             ResultSet r = p.executeQuery()) {
            while (r.next()) {
                String loai = r.getString(1);
                if (loai.equals("Ca phe")) loai = "Cà phê";
                else if (loai.equals("Sinh to")) loai = "Sinh tố";
                else if (loai.equals("Tra")) loai = "Trà";
                catModel.addRow(new Object[] { loai });
            }
        } catch (Exception ex) { 
            ex.printStackTrace(); 
            JOptionPane.showMessageDialog(this, "Lỗi load danh mục: "+ex.getMessage()); 
        }
    }

    private void loadProducts(String loaiFilter) {
        List<ProductItem> list = new ArrayList<>();
        
        String loaiFilterDB = loaiFilter;
        if (loaiFilterDB != null) {
            if (loaiFilterDB.equals("Cà phê")) loaiFilterDB = "Ca phe";
            else if (loaiFilterDB.equals("Sinh tố")) loaiFilterDB = "Sinh to";
            else if (loaiFilterDB.equals("Trà")) loaiFilterDB = "Tra";
        }
        
        String sql = loaiFilterDB==null ? 
            "SELECT MaSP, TenSP, Gia, Loai FROM SanPham ORDER BY MaSP" : 
            "SELECT MaSP, TenSP, Gia, Loai FROM SanPham WHERE Loai = ? ORDER BY MaSP";
        
        try (Connection c = DBConnection.getConnection();
             PreparedStatement p = c.prepareStatement(sql)) {
            if (loaiFilterDB!=null) p.setString(1, loaiFilterDB);
            try (ResultSet r = p.executeQuery()) { 
                while (r.next()) {
                    int maSP = r.getInt("MaSP");
                    String tenSP = r.getString("TenSP");
                    BigDecimal gia = r.getBigDecimal("Gia");
                    String loai = r.getString("Loai");
                    
                    String tenHienThi = tenSP;
                    if (tenSP.equals("Sinh to bo")) tenHienThi = "Sinh tố bơ";
                    else if (tenSP.equals("Tra đao")) tenHienThi = "Trà đào";
                    else if (tenSP.equals("Ca phe den")) tenHienThi = "Cà phê đen";
                    else if (tenSP.equals("Ca phe sua")) tenHienThi = "Cà phê sữa";
                    
                    list.add(new ProductItem(maSP, tenHienThi, gia, loai)); 
                }
            }
        } catch (Exception ex) { 
            ex.printStackTrace(); 
            JOptionPane.showMessageDialog(this, "Lỗi load sản phẩm: "+ex.getMessage()); 
        }

        productsPanel.removeAll();
        if (list.isEmpty()) {
            productsPanel.setLayout(new BorderLayout());
            JLabel lbl = new JLabel("Không có sản phẩm", SwingConstants.CENTER);
            lbl.setForeground(Color.BLACK);
            productsPanel.add(lbl, BorderLayout.CENTER);
        } else {
            int cols = 2;
            int rows = (int) Math.ceil(list.size()/(double)cols);
            productsPanel.setLayout(new GridLayout(rows, cols, 12, 12));
            
            for (ProductItem pi : list) {
                productsPanel.add(createProductButton(pi));
            }
        }
        productsPanel.revalidate(); 
        productsPanel.repaint();
    }

    private JButton createProductButton(ProductItem pi) {
        JButton b = new JButton("<html><center><b>" + pi.ten + "</b><br/><small>" + 
                              String.format("%,.0f", pi.gia) + " đ</small></center></html>");
        b.setPreferredSize(new Dimension(320,90));
        b.setFont(new Font("Arial", Font.PLAIN, 14));
        b.setBackground(new Color(255, 255, 255, 200));
        b.setOpaque(true);
        b.setBorder(BorderFactory.createLineBorder(new Color(200, 200, 200), 1));
        
        b.addActionListener(e -> {
            String s = JOptionPane.showInputDialog(this, "Số lượng:", "1");
            if (s==null) return;
            try { 
                int qty = Integer.parseInt(s.trim()); 
                addToCart(pi, qty); 
            } catch (Exception ex) { 
                JOptionPane.showMessageDialog(this, "Số lượng không hợp lệ"); 
            }
        });
        return b;
    }

    private void addToCart(ProductItem pi, int qty) {
        for (int i=0; i<cartModel.getRowCount(); i++) {
            int ma = (Integer) cartModel.getValueAt(i,0);
            if (ma == pi.ma) {
                int old = (Integer) cartModel.getValueAt(i,2);
                int neu = old + qty;
                cartModel.setValueAt(neu, i, 2);
                BigDecimal dg = (BigDecimal) cartModel.getValueAt(i,3);
                cartModel.setValueAt(dg.multiply(BigDecimal.valueOf(neu)), i, 4);
                recalcTotal();
                return;
            }
        }
        BigDecimal thanh = pi.gia.multiply(BigDecimal.valueOf(qty));
        cartModel.addRow(new Object[] { pi.ma, pi.ten, qty, pi.gia, thanh });
        recalcTotal();
    }

    private void recalcTotal() {
        total = BigDecimal.ZERO;
        for (int i=0; i<cartModel.getRowCount(); i++) {
            Object obj = cartModel.getValueAt(i,4);
            if (obj instanceof BigDecimal) {
                total = total.add((BigDecimal)obj);
            } else {
                try {
                    total = total.add(new BigDecimal(String.valueOf(obj)));
                } catch (Exception e) {
                    // ignore
                }
            }
        }
        lblTotal.setText(String.format("%,.0f đ", total));
    }

    private void doCheckout() {
        if (cartModel.getRowCount()==0) { 
            JOptionPane.showMessageDialog(this,"Giỏ hàng rỗng"); 
            return; 
        }
        try {
            int maNV;
            if ("employee".equals(currentRole)) {
                maNV = currentMaNV;
                if (maNV == -1) {
                    JOptionPane.showMessageDialog(this, "Không tìm thấy mã nhân viên!");
                    return;
                }
            } else {
                String maNVs = JOptionPane.showInputDialog(this, "Mã nhân viên (bắt buộc):");
                if (maNVs==null || maNVs.trim().isEmpty()) return;
                maNV = Integer.parseInt(maNVs.trim());
            }
            
            String maKHs = JOptionPane.showInputDialog(this, 
                "Mã KH (enter nếu khách vãng lai, nhập mã để tích điểm):\n" +
                "Để trống nếu không tích điểm");
            Integer maKH = null;
            if (maKHs != null && !maKHs.trim().isEmpty()) {
                try {
                    maKH = Integer.valueOf(maKHs.trim());
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(this, "Mã KH phải là số!");
                    return;
                }
            }
            
            String maBans = JOptionPane.showInputDialog(this, "Mã bàn (bắt buộc):");
            if (maBans==null || maBans.trim().isEmpty()) return;
            int maBan = Integer.parseInt(maBans.trim());

            Connection c = DBConnection.getConnection();
            try {
                c.setAutoCommit(false);
                String insHD = "INSERT INTO HoaDon(MaNV,MaKH,MaBan,NgayLap,TongTien,MaCa) VALUES(?, ?, ?, GETDATE(), ?, NULL)";
                try (PreparedStatement p = c.prepareStatement(insHD, Statement.RETURN_GENERATED_KEYS)) {
                    p.setInt(1, maNV);
                    if (maKH==null) p.setNull(2, Types.INTEGER); else p.setInt(2, maKH);
                    p.setInt(3, maBan);
                    p.setBigDecimal(4, total);
                    p.executeUpdate();
                    try (ResultSet keys = p.getGeneratedKeys()) {
                        if (!keys.next()) throw new SQLException("Không lấy được Mã HĐ");
                        int maHD = keys.getInt(1);
                        String insCT = "INSERT INTO ChiTietHoaDon(MaHD,MaSP,SoLuong,DonGia) VALUES(?,?,?,?)";
                        try (PreparedStatement p2 = c.prepareStatement(insCT)) {
                            for (int i=0;i<cartModel.getRowCount();i++) {
                                int maSP = (Integer) cartModel.getValueAt(i,0);
                                int sl = (Integer) cartModel.getValueAt(i,2);
                                BigDecimal dg = (BigDecimal) cartModel.getValueAt(i,3);
                                p2.setInt(1, maHD); 
                                p2.setInt(2, maSP); 
                                p2.setInt(3, sl); 
                                p2.setBigDecimal(4, dg);
                                p2.addBatch();
                            }
                            p2.executeBatch();
                        }
                        
                        if (maKH != null) {
                            tichDiemKhiThanhToan(maKH, total, c);
                        }
                        
                        c.commit();
                        
                        String message = "Thanh toán thành công!\n" +
                                        "Mã HĐ: " + maHD + "\n" +
                                        "Tổng tiền: " + String.format("%,.0f", total) + "đ";
                        
                        if (maKH != null) {
                            message += "\n\nĐã tích điểm cho khách hàng!";
                        }
                        
                        JOptionPane.showMessageDialog(this, message, "Thành công", JOptionPane.INFORMATION_MESSAGE);
                        
                        cartModel.setRowCount(0); 
                        recalcTotal();
                    }
                }
            } catch (Exception ex) { 
                try {
                    c.rollback(); 
                } catch (SQLException e) {
                    e.printStackTrace();
                }
                throw ex; 
            } finally { 
                try {
                    c.setAutoCommit(true); 
                    c.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        } catch (Exception ex) { 
            ex.printStackTrace(); 
            JOptionPane.showMessageDialog(this,"Lỗi khi thanh toán: " + ex.getMessage()); 
        }
    }

    private void showCaList() {
        try (Connection c = DBConnection.getConnection();
             PreparedStatement p = c.prepareStatement("SELECT MaCa,TenCa,GioBatDau,GioKetThuc,TienCa FROM CaLam ORDER BY MaCa");
             ResultSet r = p.executeQuery()) {
            DefaultTableModel m = new DefaultTableModel(new Object[] {"Mã ca","Tên ca","Giờ bắt đầu","Giờ kết thúc","Tiền ca"},0);
            while (r.next()) m.addRow(new Object[] { 
                r.getInt(1), r.getString(2), r.getTime(3), r.getTime(4), r.getBigDecimal(5) 
            });
            JTable t = new JTable(m);
            JOptionPane.showMessageDialog(this, new JScrollPane(t), "Danh sách Ca", JOptionPane.INFORMATION_MESSAGE);
        } catch (Exception ex) { 
            ex.printStackTrace(); 
            JOptionPane.showMessageDialog(this, "Lỗi: "+ex.getMessage()); 
        }
    }
    
    private void addCa(String ten, String gb, String gk, String tienStr) {
        try (Connection c = DBConnection.getConnection();
             PreparedStatement p = c.prepareStatement("INSERT INTO CaLam(TenCa,GioBatDau,GioKetThuc,TienCa) VALUES(?,?,?,?)")) {
            p.setString(1, ten);
            p.setTime(2, Time.valueOf(gb));
            p.setTime(3, Time.valueOf(gk));
            p.setBigDecimal(4, new BigDecimal(tienStr));
            p.executeUpdate();
            JOptionPane.showMessageDialog(this, "Thêm ca thành công");
        } catch (Exception ex) { 
            ex.printStackTrace(); 
            JOptionPane.showMessageDialog(this, "Lỗi thêm ca: "+ex.getMessage()); 
        }
    }
    
    private void deleteCa(int id) {
        try (Connection c = DBConnection.getConnection();
             PreparedStatement p = c.prepareStatement("DELETE FROM CaLam WHERE MaCa=?")) {
            p.setInt(1, id); 
            int n = p.executeUpdate();
            JOptionPane.showMessageDialog(this, n>0 ? "Xóa thành công" : "Không tìm thấy");
        } catch (Exception ex) { 
            ex.printStackTrace(); 
            JOptionPane.showMessageDialog(this, "Lỗi xóa ca: "+ex.getMessage()); 
        }
    }
    
    private void tongHopDoanhThu(String thang) {
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(
                 "SELECT NgayLap, SUM(TongTien) as DoanhThu, COUNT(*) as SoHD " +
                 "FROM HoaDon " +
                 "WHERE CONVERT(varchar(7), NgayLap, 126) = ? " +
                 "GROUP BY NgayLap " +
                 "ORDER BY NgayLap")) {
            
            pstmt.setString(1, thang);
            try (ResultSet rs = pstmt.executeQuery()) {
                DefaultTableModel model = new DefaultTableModel();
                model.addColumn("Ngày");
                model.addColumn("Số hóa đơn");
                model.addColumn("Doanh thu");
                
                BigDecimal tongDoanhThu = BigDecimal.ZERO;
                int tongHoaDon = 0;
                
                while (rs.next()) {
                    Date ngay = rs.getDate("NgayLap");
                    int soHD = rs.getInt("SoHD");
                    BigDecimal doanhThu = rs.getBigDecimal("DoanhThu");
                    
                    model.addRow(new Object[] {
                        ngay,
                        soHD,
                        String.format("%,.0f đ", doanhThu)
                    });
                    
                    tongDoanhThu = tongDoanhThu.add(doanhThu);
                    tongHoaDon += soHD;
                }
                
                JTable table = new JTable(model);
                JScrollPane scrollPane = new JScrollPane(table);
                
                String tongHop = String.format(
                    "Tổng hợp doanh thu tháng %s:\n" +
                    "• Tổng số hóa đơn: %,d\n" +
                    "• Tổng doanh thu: %,.0f đ",
                    thang, tongHoaDon, tongDoanhThu);
                
                JOptionPane.showMessageDialog(this, 
                    new Object[]{tongHop, scrollPane},
                    "Tổng hợp doanh thu tháng " + thang,
                    JOptionPane.INFORMATION_MESSAGE);
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Lỗi: " + ex.getMessage());
            ex.printStackTrace();
        }
    }

    
    // ==================== STYLED BUTTON HELPER ====================
    private JButton createStyledButton(String text, Color bgColor) {
        JButton btn = new JButton(text);
        btn.setFont(new Font("Arial", Font.BOLD, 12));
        btn.setBackground(bgColor);
        btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false);
        btn.setBorderPainted(false);
        btn.setOpaque(true);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.setPreferredSize(new Dimension(80, 35));
        
        btn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btn.setBackground(darkerColor(bgColor));
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btn.setBackground(bgColor);
            }
        });
        
        return btn;
    }
    
    private Color darkerColor(Color color) {
        return new Color(
            Math.max(color.getRed() - 30, 0),
            Math.max(color.getGreen() - 30, 0),
            Math.max(color.getBlue() - 30, 0)
        );
    }

    static class ProductItem { 
        int ma; 
        String ten; 
        BigDecimal gia; 
        String loai;
        
        ProductItem(int ma, String ten, BigDecimal gia, String loai){ 
            this.ma=ma; 
            this.ten=ten; 
            this.gia=gia; 
            this.loai=loai; 
        }
    }

    public static void main(String[] args) {
        try { 
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName()); 
        } catch (Exception ignored) {}
        
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new MainCafeSwing();
            }
        });
    }
}
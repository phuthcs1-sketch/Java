package CoffeeShop;
import java.sql.Connection;
import java.sql.DriverManager;

public class DBConnection {
    // Thông tin kết nối SQL Server
    private static final String URL =
        "jdbc:sqlserver://localhost:1433;databaseName=COFFEESHOP;encrypt=false;" +
        "loginTimeout=5;connectRetryCount=0;";
    private static final String USER = "sa";
    private static final String PASS = "Admin123!";

    // Phương thức tạo kết nối
    public static Connection getConnection() {
        try {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            
            // 2. Tạo và trả về kết nối đến database
            return DriverManager.getConnection(URL, USER, PASS);
        } catch (Exception e) {
            System.out.println("Connection failed!");
            e.printStackTrace();
            return null;
        }
    }
}
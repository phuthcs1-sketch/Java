package CoffeeShop.util;

import CoffeeShop.DBConnection;
import java.sql.Connection;
import java.sql.Statement;
import java.util.logging.Logger;

/**
 * Utility để thêm dữ liệu mẫu vào database
 */
public class SampleDataLoader {

    private static final Logger logger = LoggerUtil.getLogger(SampleDataLoader.class.getName());

    public static void loadSampleData() {
        try (Connection conn = DBConnection.getConnection()) {
            if (conn == null) {
                logger.warning("⚠️ Không kết nối được DB, bỏ qua tải dữ liệu mẫu");
                return;
            }
            try (Statement stmt = conn.createStatement()) {
                logger.info("📥 Đang kiểm tra và tải dữ liệu mẫu...");
                loadSanPham(stmt);
                loadNhanVien(stmt);
                loadKhachHang(stmt);
                loadBan(stmt);
                logger.info("✅ Dữ liệu mẫu đã được kiểm tra/tải xong!");
            }
        } catch (Exception e) {
            logger.severe("❌ Lỗi tải dữ liệu mẫu: " + e.getMessage());
        }
    }

    private static void loadSanPham(Statement stmt) {
        try {
            java.sql.ResultSet rs = stmt.executeQuery("SELECT COUNT(*) as cnt FROM SanPham");
            rs.next();
            if (rs.getInt("cnt") > 0) {
                logger.info("✅ SanPham đã có dữ liệu, bỏ qua");
                return;
            }
            stmt.execute("INSERT INTO SanPham (TenSP, Loai, Gia) VALUES (N'Cà phê Đen', N'Ca phe', 25000)");
            stmt.execute("INSERT INTO SanPham (TenSP, Loai, Gia) VALUES (N'Cà phê Sữa', N'Ca phe', 30000)");
            stmt.execute("INSERT INTO SanPham (TenSP, Loai, Gia) VALUES (N'Cappuccino', N'Ca phe', 35000)");
            stmt.execute("INSERT INTO SanPham (TenSP, Loai, Gia) VALUES (N'Trà Đen', N'Tra', 20000)");
            stmt.execute("INSERT INTO SanPham (TenSP, Loai, Gia) VALUES (N'Trà Xanh', N'Tra', 20000)");
            stmt.execute("INSERT INTO SanPham (TenSP, Loai, Gia) VALUES (N'Coca Cola', N'Nuoc ngot', 15000)");
            stmt.execute("INSERT INTO SanPham (TenSP, Loai, Gia) VALUES (N'Sprite', N'Nuoc ngot', 15000)");
            stmt.execute("INSERT INTO SanPham (TenSP, Loai, Gia) VALUES (N'Nước Cam', N'Nuoc lanh', 18000)");
            stmt.execute("INSERT INTO SanPham (TenSP, Loai, Gia) VALUES (N'Bánh Mì', N'Do an nhe', 12000)");
            stmt.execute("INSERT INTO SanPham (TenSP, Loai, Gia) VALUES (N'Croissant', N'Do an nhe', 15000)");
            logger.info("✅ Thêm 10 sản phẩm mẫu");
        } catch (Exception e) {
            logger.severe("⚠️ Lỗi thêm sản phẩm mẫu: " + e.getMessage());
        }
    }

    private static void loadNhanVien(Statement stmt) {
        try {
            java.sql.ResultSet rs = stmt.executeQuery("SELECT COUNT(*) as cnt FROM NhanVien");
            rs.next();
            if (rs.getInt("cnt") > 0) {
                logger.info("✅ NhanVien đã có dữ liệu, bỏ qua");
                return;
            }
            // TrangThai dùng 'Dang lam' để khớp với UserDAO.getTotalUsers()
            stmt.execute("INSERT INTO NhanVien (TenNV, ChucVu, DienThoai, Luong, TrangThai) VALUES (N'Nguyễn Văn A', N'Quản lý',  N'0912345678', 10000000, N'Dang lam')");
            stmt.execute("INSERT INTO NhanVien (TenNV, ChucVu, DienThoai, Luong, TrangThai) VALUES (N'Trần Thị B',   N'Pha chế', N'0912345679',  5000000, N'Dang lam')");
            stmt.execute("INSERT INTO NhanVien (TenNV, ChucVu, DienThoai, Luong, TrangThai) VALUES (N'Phạm Văn C',   N'Pha chế', N'0912345680',  5000000, N'Dang lam')");
            stmt.execute("INSERT INTO NhanVien (TenNV, ChucVu, DienThoai, Luong, TrangThai) VALUES (N'Lê Thị D',     N'Phục vụ', N'0912345681',  3000000, N'Dang lam')");
            stmt.execute("INSERT INTO NhanVien (TenNV, ChucVu, DienThoai, Luong, TrangThai) VALUES (N'Vũ Văn E',     N'Phục vụ', N'0912345682',  3000000, N'Nghi')");
            logger.info("✅ Thêm 5 nhân viên mẫu");
        } catch (Exception e) {
            logger.severe("⚠️ Lỗi thêm nhân viên mẫu: " + e.getMessage());
        }
    }

    private static void loadKhachHang(Statement stmt) {
        try {
            java.sql.ResultSet rs = stmt.executeQuery("SELECT COUNT(*) as cnt FROM KhachHang");
            rs.next();
            if (rs.getInt("cnt") > 0) {
                logger.info("✅ KhachHang đã có dữ liệu, bỏ qua");
                return;
            }
            stmt.execute("INSERT INTO KhachHang (TenKH, DienThoai, Email, DiaChi, DiemTich) VALUES (N'Khách hàng 1', N'0912111111', N'kh1@gmail.com', N'123 Nguyễn Huệ', 100)");
            stmt.execute("INSERT INTO KhachHang (TenKH, DienThoai, Email, DiaChi, DiemTich) VALUES (N'Khách hàng 2', N'0912222222', N'kh2@gmail.com', N'456 Lê Lợi',     50)");
            stmt.execute("INSERT INTO KhachHang (TenKH, DienThoai, Email, DiaChi, DiemTich) VALUES (N'Khách hàng 3', N'0912333333', N'kh3@gmail.com', N'789 Trần Hưng Đạo', 75)");
            stmt.execute("INSERT INTO KhachHang (TenKH, DienThoai, Email, DiaChi, DiemTich) VALUES (N'Khách hàng 4', N'0912444444', N'kh4@gmail.com', N'321 Phan Bội Châu', 150)");
            logger.info("✅ Thêm 4 khách hàng mẫu");
        } catch (Exception e) {
            logger.severe("⚠️ Lỗi thêm khách hàng mẫu: " + e.getMessage());
        }
    }

    private static void loadBan(Statement stmt) {
        try {
            java.sql.ResultSet rs = stmt.executeQuery("SELECT COUNT(*) as cnt FROM Ban");
            rs.next();
            if (rs.getInt("cnt") > 0) {
                logger.info("✅ Ban đã có dữ liệu, bỏ qua");
                return;
            }
            stmt.execute("INSERT INTO Ban (TenBan, KhuVuc, TrangThai, SoCho) VALUES (N'Bàn 1', N'Tầng 1',     N'Trống', 4)");
            stmt.execute("INSERT INTO Ban (TenBan, KhuVuc, TrangThai, SoCho) VALUES (N'Bàn 2', N'Tầng 1',     N'Trống', 4)");
            stmt.execute("INSERT INTO Ban (TenBan, KhuVuc, TrangThai, SoCho) VALUES (N'Bàn 3', N'Tầng 1',     N'Trống', 4)");
            stmt.execute("INSERT INTO Ban (TenBan, KhuVuc, TrangThai, SoCho) VALUES (N'Bàn 4', N'Ngoài Trời', N'Trống', 2)");
            stmt.execute("INSERT INTO Ban (TenBan, KhuVuc, TrangThai, SoCho) VALUES (N'Bàn 5', N'Ngoài Trời', N'Trống', 2)");
            logger.info("✅ Thêm 5 bàn mẫu");
        } catch (Exception e) {
            logger.severe("⚠️ Lỗi thêm bàn mẫu: " + e.getMessage());
        }
    }
}

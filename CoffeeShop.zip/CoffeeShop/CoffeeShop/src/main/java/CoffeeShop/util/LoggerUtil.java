package CoffeeShop.util;

import java.util.logging.Logger;
import java.util.logging.FileHandler;
import java.util.logging.SimpleFormatter;
import java.io.File;
import java.io.IOException;

public class LoggerUtil {

    private static final String LOG_FILE = "logs/coffeeshop.log";
    private static FileHandler sharedHandler;

    static {
        try {
            new File("logs").mkdirs();
            sharedHandler = new FileHandler(LOG_FILE, true);
            sharedHandler.setFormatter(new SimpleFormatter());
        } catch (IOException e) {
            System.err.println("Không thể tạo file log: " + e.getMessage());
        }
    }

    public static Logger getLogger(String className) {
        Logger logger = Logger.getLogger(className);
        // Chỉ thêm handler nếu chưa có (tránh duplicate log mỗi lần getLogger)
        if (sharedHandler != null && logger.getHandlers().length == 0) {
            logger.addHandler(sharedHandler);
        }
        return logger;
    }
}

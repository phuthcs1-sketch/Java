package CoffeeShop.util;

/**
 * Tiện ích kiểm tra dữ liệu nhập vào
 */
public class ValidationUtil {
    
    /**
     * Kiểm tra chuỗi có trống hay không
     */
    public static boolean isEmpty(String text) {
        return text == null || text.trim().isEmpty();
    }
    
    /**
     * Kiểm tra chuỗi không trống
     */
    public static boolean isNotEmpty(String text) {
        return !isEmpty(text);
    }
    
    /**
     * Kiểm tra email hợp lệ
     */
    public static boolean isValidEmail(String email) {
        return email.matches("^[A-Za-z0-9+_.-]+@(.+)$");
    }
    
    /**
     * Kiểm tra số điện thoại hợp lệ (Việt Nam)
     */
    public static boolean isValidPhoneNumber(String phone) {
        return phone.matches("^0\\d{9}$");
    }
    
    /**
     * Kiểm tra giá tiền hợp lệ
     */
    public static boolean isValidPrice(String price) {
        try {
            double p = Double.parseDouble(price);
            return p > 0;
        } catch (NumberFormatException e) {
            return false;
        }
    }
}

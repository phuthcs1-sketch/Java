package CoffeeShop.util;

import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import java.io.IOException;
import java.util.logging.Logger;

/**
 * Quản lý chuyển đổi giữa các màn hình trong ứng dụng
 * Giúp code dễ đọc và tránh lặp lại code
 */
public class SceneManager {
    
    private static final Logger logger = LoggerUtil.getLogger(SceneManager.class.getName());
    private static Stage primaryStage;
    
    public static void setPrimaryStage(Stage stage) {
        primaryStage = stage;
    }
    
    /**
     * Chuyển đến một scene mới
     * @param fxmlFile Đường dẫn file FXML
     * @param title Tiêu đề cửa sổ
     * @param width Chiều rộng
     * @param height Chiều cao
     */
    public static void switchScene(String fxmlFile, String title, double width, double height) {
        try {
            logger.info("🔄 Chuyển sang scene: " + fxmlFile);
            
            FXMLLoader loader = new FXMLLoader(
                SceneManager.class.getResource(fxmlFile)
            );
            
            Parent root = loader.load();
            Scene scene = new Scene(root, width, height);
            
            // Thêm CSS
            String css = SceneManager.class.getResource("/CoffeeShop/style/style.css").toExternalForm();
            scene.getStylesheets().add(css);
            
            primaryStage.setScene(scene);
            primaryStage.setTitle(title);
            primaryStage.show();
            
            logger.info("✅ Chuyển scene thành công");
            
        } catch (IOException e) {
            logger.severe("❌ Lỗi chuyển scene: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    /**
     * Chuyển scene với kích thước mặc định
     */
    public static void switchScene(String fxmlFile, String title) {
        switchScene(fxmlFile, title, 950, 600);
    }
}
